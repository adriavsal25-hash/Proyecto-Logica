$reader = [System.IO.File]::OpenText('C:\Users\Usuario\.gemini\antigravity\brain\36f7e51b-3d8b-4435-9457-ac16b50b4cb8\.system_generated\logs\transcript_full.jsonl')
try {
    while ($null -ne ($line = $reader.ReadLine())) {
        if ($line.Contains('"step_index":4892')) {
            $json = ConvertFrom-Json $line
            [System.IO.File]::WriteAllText('C:\Users\Adrian\UNC\Logica y Algoritmo\Proyecto\scratch\prompt_master.txt', $json.content, [System.Text.Encoding]::UTF8)
            Write-Host "Success! Length: $((Get-Item 'C:\Users\Adrian\UNC\Logica y Algoritmo\Proyecto\scratch\prompt_master.txt').Length)"
            break
        }
    }
} finally {
    $reader.Close()
}
