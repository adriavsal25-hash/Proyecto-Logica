import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import dotenv from 'dotenv';
import apiRoutes from './routes/api.routes';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware de seguridad y serialización
app.use(helmet());
app.use(cors({
    origin: '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Logging básico de auditoría
app.use((req, res, next) => {
    const timestamp = new Date().toISOString();
    console.log(`[${timestamp}] ${req.method} ${req.url} - IP: ${req.ip}`);
    next();
});

// Enrutador de la API v2.0
app.use('/api/v2', apiRoutes);

// Endpoint raíz informativo
app.get('/', (req, res) => {
    res.json({
        plataforma: 'SICOP-VE 2.0',
        descripcion: 'Plataforma Institucional Inteligente, Financiera y Administrativa de Nivel Empresarial',
        version: '2.0.0',
        estado: 'OPERATIVO',
        documentacion: '/api/v2/docs'
    });
});

// Manejo centralizado de errores 404
app.use((req, res) => {
    res.status(404).json({
        ok: false,
        mensaje: `Recurso no encontrado: ${req.method} ${req.url}`
    });
});

// Inicio del servidor
if (process.env.NODE_ENV !== 'test') {
    app.listen(PORT, () => {
        console.log(`=======================================================`);
        console.log(`SICOP-VE 2.0 Backend Empresarial iniciado exitosamente`);
        console.log(`Puerto: ${PORT} | Entorno: ${process.env.NODE_ENV || 'development'}`);
        console.log(`Base de datos PostgreSQL: Configurada y activa`);
        console.log(`=======================================================`);
    });
}

export default app;

