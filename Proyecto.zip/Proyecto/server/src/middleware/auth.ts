import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'sicop_ve_enterprise_jwt_secret_2026';

export interface UsuarioAutenticado {
    id: number;
    institucion_id: number;
    usuario: string;
    nombre_completo: string;
    email: string;
    rol: 'SUPERADMIN' | 'GOBERNACION' | 'ALCALDIA' | 'EMPRESA' | 'CONSTRUCTOR';
    nivel: number;
}

declare global {
    namespace Express {
        interface Request {
            usuario?: UsuarioAutenticado;
        }
    }
}

/**
 * Middleware para validar el token JWT y adjuntar la identidad del usuario a la petición.
 */
export function autenticarJWT(req: Request, res: Response, next: NextFunction) {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({
            ok: false,
            mensaje: 'No autorizado: Token de autenticación requerido.'
        });
    }

    const token = authHeader.split(' ')[1];
    try {
        const decoded = jwt.verify(token, JWT_SECRET) as UsuarioAutenticado;
        req.usuario = decoded;
        next();
    } catch (err) {
        return res.status(401).json({
            ok: false,
            mensaje: 'Token inválido o expirado. Debe iniciar sesión nuevamente.'
        });
    }
}

/**
 * Middleware de control de acceso basado en roles (RBAC).
 */
export function autorizarRoles(...rolesPermitidos: string[]) {
    return (req: Request, res: Response, next: NextFunction) => {
        if (!req.usuario) {
            return res.status(401).json({ ok: false, mensaje: 'Usuario no autenticado.' });
        }

        if (req.usuario.rol === 'SUPERADMIN' || req.usuario.rol === 'GOBERNACION') {
            return next(); // Rol directivo y fiscalizador con acceso total
        }

        if (rolesPermitidos.includes(req.usuario.rol)) {
            return next();
        }

        return res.status(403).json({
            ok: false,
            mensaje: `Acceso denegado: Su rol (${req.usuario.rol}) no tiene autorización para esta operación.`
        });
    };
}

