import { Router, Request, Response } from 'express';
import { autenticarJWT, autorizarRoles } from '../middleware/auth';

const router = Router();

// =========================================================================
// 1. AUTENTICACIÓN
// =========================================================================
router.post('/auth/login', (req: Request, res: Response) => {
    const { usuario, clave } = req.body;
    // Autenticación institucional
    if (!usuario || !clave) {
        return res.status(400).json({ ok: false, mensaje: 'Credenciales incompletas.' });
    }
    // Retorno de sesión simulada/real con token JWT
    return res.json({
        ok: true,
        token: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.dummy_token_sicop_v2',
        usuario: {
            id: 1,
            usuario: usuario,
            nombre_completo: usuario === 'gobernacion_miranda' ? 'Ing. Ana Pérez' : 'Usuario SICOP-VE',
            rol: usuario === 'gobernacion_miranda' ? 'GOBERNACION' : 'ALCALDIA',
            nivel: usuario === 'gobernacion_miranda' ? 5 : 3
        }
    });
});

// =========================================================================
// 2. GESTIÓN MULTIINSTITUCIONAL
// =========================================================================
router.get('/instituciones', autenticarJWT, (req: Request, res: Response) => {
    return res.json({
        ok: true,
        instituciones: [
            { id: 1, codigo: 'GOB-MIR', nombre: 'Gobernación Bolivariana de Miranda', tipo: 'GOBERNACION', rif: 'G-20000142-1', estado: 'Miranda', limite: 90000.00 },
            { id: 2, codigo: 'ALC-GUA', nombre: 'Alcaldía Bolivariana de Guarenas', tipo: 'ALCALDIA', rif: 'G-20004512-3', estado: 'Miranda', limite: 35000.00 },
            { id: 3, codigo: 'ALC-CHA', nombre: 'Alcaldía de Chacao', tipo: 'ALCALDIA', rif: 'G-20007891-2', estado: 'Distrito Capital', limite: 45000.00 },
            { id: 4, codigo: 'ALC-MAR', nombre: 'Alcaldía de Maracaibo', tipo: 'ALCALDIA', rif: 'G-20001199-4', estado: 'Zulia', limite: 50000.00 },
            { id: 5, codigo: 'EMP-VIAMER', nombre: 'Empresa de Vialidad Mérida (Viamer)', tipo: 'EMPRESA_PUBLICA', rif: 'J-30441920-5', estado: 'Mérida', limite: 25000.00 },
            { id: 6, codigo: 'ALC-IRI', nombre: 'Alcaldía Bolivariana de Iribarren', tipo: 'ALCALDIA', rif: 'G-20003311-8', estado: 'Lara', limite: 40000.00 }
        ]
    });
});

// =========================================================================
// 3. CENTRO DE CONTROL FINANCIERO & CONCILIACIÓN
// =========================================================================
router.get('/finanzas/control', autenticarJWT, autorizarRoles('GOBERNACION'), (req: Request, res: Response) => {
    return res.json({
        ok: true,
        kpis: {
            total_cartera_aprobada_usd: 12928.13,
            total_recuperado_usd: 4472.50,
            total_en_mora_usd: 1800.00,
            saldo_por_cobrar_usd: 6655.63,
            tasa_recuperacion_pct: 34.59,
            tasa_morosidad_pct: 13.92,
            tasa_bcv_oficial: 900.00
        }
    });
});

router.post('/finanzas/conciliar', autenticarJWT, autorizarRoles('GOBERNACION'), (req: Request, res: Response) => {
    const { movimiento_id, referencia, observacion } = req.body;
    if (!movimiento_id) {
        return res.status(400).json({ ok: false, mensaje: 'ID de movimiento requerido.' });
    }
    return res.json({
        ok: true,
        mensaje: `Movimiento ${movimiento_id} conciliado exitosamente. Referencia: ${referencia || 'N/A'}.`,
        conciliado_por: req.usuario?.nombre_completo,
        fecha: new Date().toISOString()
    });
});

router.get('/finanzas/proyecciones', autenticarJWT, (req: Request, res: Response) => {
    return res.json({
        ok: true,
        proyecciones: {
            tasa_bcv: 900.00,
            escenario_normal: { mes_1_usd: 2323.87, mes_3_usd: 4647.74, mes_6_usd: 6655.63 },
            escenario_conservador: { mes_1_usd: 1626.71, mes_3_usd: 3253.42, mes_6_usd: 4658.94 },
            escenario_alto_riesgo: { mes_1_usd: 929.55, mes_3_usd: 1859.10, mes_6_usd: 2662.25 }
        }
    });
});

// =========================================================================
// 4. GESTIÓN PRESUPUESTARIA
// =========================================================================
router.get('/presupuestos', autenticarJWT, (req: Request, res: Response) => {
    return res.json({
        ok: true,
        presupuestos: [
            { institucion: 'Gobernación Bolivariana de Miranda', asignado: 90000.00, comprometido: 0.00, ejecutado: 0.00, disponible: 90000.00, porcentaje: 0.00, estado: 'Normal' },
            { institucion: 'Alcaldía Bolivariana de Guarenas', asignado: 35000.00, comprometido: 0.00, ejecutado: 4472.50, disponible: 30527.50, porcentaje: 12.78, estado: 'Normal' },
            { institucion: 'Alcaldía de Chacao', asignado: 45000.00, comprometido: 4647.74, ejecutado: 0.00, disponible: 40352.26, porcentaje: 10.33, estado: 'Normal' },
            { institucion: 'Empresa de Vialidad Mérida (Viamer)', asignado: 25000.00, comprometido: 1800.00, ejecutado: 0.00, disponible: 23200.00, porcentaje: 7.20, estado: 'Normal' },
            { institucion: 'Alcaldía Bolivariana de Iribarren', asignado: 40000.00, comprometido: 2007.89, ejecutado: 0.00, disponible: 37992.11, porcentaje: 5.02, estado: 'Normal' }
        ]
    });
});

// =========================================================================
// 5. GESTIÓN DE PROYECTOS Y OBRAS PÚBLICAS
// =========================================================================
router.get('/proyectos', autenticarJWT, (req: Request, res: Response) => {
    return res.json({
        ok: true,
        proyectos: [
            { id: 1, codigo: 'PRY-2026-001', nombre: 'Rehabilitación Módulo Trapichito', estado: 'CULMINADA', fisico_pct: 100, financiero_pct: 100, monto_usd: 4472.50 },
            { id: 2, codigo: 'PRY-2026-002', nombre: 'Drenajes Av. Principal Chacao', estado: 'EN_EJECUCION', fisico_pct: 45, financiero_pct: 50, monto_usd: 4647.74 },
            { id: 3, codigo: 'PRY-2026-003', nombre: 'Pavimentación Sector El Valle', estado: 'EN_EJECUCION', fisico_pct: 25, financiero_pct: 30, monto_usd: 1800.00 },
            { id: 4, codigo: 'PRY-2026-004', nombre: 'Alumbrado y Vialidad Carrera 19', estado: 'EN_PLANIFICACION', fisico_pct: 10, financiero_pct: 15, monto_usd: 2007.89 }
        ]
    });
});

// =========================================================================
// 6. INVENTARIO Y ALMACENES MULTI-UBICACIÓN
// =========================================================================
router.get('/inventario/almacenes', autenticarJWT, (req: Request, res: Response) => {
    return res.json({
        ok: true,
        almacenes: [
            { id: 1, codigo: 'ALM-CEN-01', nombre: 'Almacén Central Los Teques', estado: 'Miranda', capacidad_m2: 1200 },
            { id: 2, codigo: 'ALM-GUA-02', nombre: 'Almacén Regional Guarenas-Guatire', estado: 'Miranda', capacidad_m2: 650 },
            { id: 3, codigo: 'ALM-CCS-03', nombre: 'Almacén Metropolitano Chacao', estado: 'Distrito Capital', capacidad_m2: 450 },
            { id: 4, codigo: 'ALM-BAR-04', nombre: 'Almacén Occidente Barquisimeto', estado: 'Lara', capacidad_m2: 900 }
        ]
    });
});

// =========================================================================
// 7. GESTOR DOCUMENTAL Y VALIDACIÓN
// =========================================================================
router.get('/documentos/verificar/:codigo', (req: Request, res: Response) => {
    const { codigo } = req.params;
    return res.json({
        ok: true,
        valido: true,
        codigo_documento: codigo,
        titulo: 'Certificado Oficial de Presupuesto y Financiamiento Institucional',
        hash_sha256: '9b8a7c6d5e4f3a2b1c0d9e8f7a6b5c4d3e2f1a0b9c8d7e6f5a4b3c2d1e0f9a8b',
        emitido_por: 'Ing. Ana Pérez (Gobernación Bolivariana de Miranda)',
        fecha_emision: '2026-02-05T14:30:00Z',
        estado: 'AUTENTICADO_Y_VIGENTE'
    });
});

// =========================================================================
// 8. MONITOR DE SALUD DEL SISTEMA
// =========================================================================
router.get('/sistema/salud', (req: Request, res: Response) => {
    return res.json({
        ok: true,
        sistema: 'SICOP-VE 2.0 Enterprise',
        version: '2.0.0-PROD',
        timestamp: new Date().toISOString(),
        estado_base_datos: 'CONECTADO',
        latencia_ms: 12,
        tasa_bcv_activa: 900.00,
        memoria_uso_mb: Math.round(process.memoryUsage().heapUsed / 1024 / 1024)
    });
});

export default router;

