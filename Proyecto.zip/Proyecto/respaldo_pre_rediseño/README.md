# SICOP-VE: Sistema de Cotización y Control de Presupuesto para Obras en Venezuela

**Proyecto Final — Cátedra de Lógica y Programación I**  
*Universidad Nacional de Córdoba (UNC)*  
*Desarrollado en HTML5, CSS3 y JavaScript puro (Vanilla JS).*

---

## 📑 Tabla de Contenidos
1. [Descripción General y Problema que Resuelve](#1-descripción-general-y-problema-que-resuelve)
2. [Instrucciones de Ejecución](#2-instrucciones-de-ejecución)
3. [Credenciales y Usuarios de Demostración](#3-credenciales-y-usuarios-de-demostración)
4. [Estructura del Proyecto y Arquitectura](#4-estructura-del-proyecto-y-arquitectura)
5. [Decisiones de Diseño y Mejoras de Experiencia de Usuario (UX)](#5-decisiones-de-diseño-y-mejoras-de-experiencia-de-usuario-ux)
6. [Explicación Detallada de Módulos y Reglas de Negocio](#6-explicación-detallada-de-módulos-y-reglas-de-negocio)
7. [Ejemplo Numérico Paso a Paso](#7-ejemplo-numérico-paso-a-paso)
8. [Ciclo de Vida de una Cotización (Diagrama Mermaid)](#8-ciclo-de-vida-de-una-cotización-diagrama-mermaid)
9. [Casos de Uso por Rol Institucional](#9-casos-de-uso-por-rol-institucional)
10. [Batería de Pruebas Automáticas (30 Casos)](#10-batería-de-pruebas-automáticas-30-casos)
11. [Guía para la Exposición en Clase](#11-guía-para-la-exposición-en-clase)
12. [Limitaciones y Trabajo Futuro](#12-limitaciones-y-trabajo-futuro)
13. [Guía de Publicación en GitHub Pages](#13-guía-de-publicación-en-github-pages)

---

## 1. Descripción General y Problema que Resuelve

En el sector de obras públicas e infraestructura en Venezuela, la estimación de costos y la asignación presupuestaria enfrentan desafíos particulares:
- **Dispersión geográfica de precios:** La adquisición de materiales (cemento, cabilla, asfalto) varía de precio según la región industrial proveedora (por ejemplo, Puerto Ordaz vs. Caracas).
- **Costos de flete terrestre:** La distancia y logística hacia estados fronterizos o andinos (como Amazonas o Mérida) encarecen el traslado respecto a la región central.
- **Doble denominación monetaria:** Necesidad de presupuestar en divisas (USD) como valor de referencia estable y convertir a Bolívares (Bs.) con la tasa cambiaria del día.
- **Riesgo de sobregiro presupuestario:** Falta de control estricto entre lo presupuestado, lo comprometido temporalmente y lo ejecutado/gastado de forma definitiva.

**SICOP-VE** resuelve esta problemática mediante una herramienta centralizada y liviana que:
1. Estima consumos de materiales por dimensiones físicas (paredes, losas, tuberías).
2. Cotiza aplicando automáticamente la ciudad más económica mediante el **algoritmo de ordenamiento burbuja**.
3. Aplica fletes regionales, descuentos institucionales, contingencias e IVA.
4. Gestiona un **flujo formal de aprobación** con semáforo presupuestario, impidiendo la aprobación de solicitudes si superan el saldo disponible del solicitante.

---

## 2. Instrucciones de Ejecución

Esta aplicación fue construida **sin frameworks, sin Node.js, sin backend y sin librerías externas**, por lo que no requiere terminal ni servidores web para funcionar:

1. **Abrir la Aplicación Principal:**
   - Haga doble clic sobre el archivo `index.html` en su explorador de archivos. Se abrirá en cualquier navegador moderno (Google Chrome, Mozilla Firefox, Microsoft Edge, Safari).
2. **Abrir la Suite de Pruebas Automáticas:**
   - Haga doble clic sobre `pruebas.html` o haga clic en el enlace *"🧪 Pruebas Automáticas ↗"* dentro de la barra de navegación del sistema.
3. **Restablecer Datos de Fábrica:**
   - Si desea reiniciar las cotizaciones o usuarios a su estado original de entrega, ingrese a la pestaña **"💾 Exportar / Importar"** y presione el botón rojo **"⚠️ Restablecer Valores de Fábrica"**.

---

## 3. Credenciales y Usuarios de Demostración

El sistema cuenta con 6 usuarios precargados para evaluar todos los roles y casos límite:

| N° | Nombre Completo | Usuario | Clave | Perfil Institucional | Estado Destino | Límite / Cupo (USD) | Estado Presupuestario |
|:--:|:----------------|:--------|:------|:---------------------|:---------------|:--------------------|:----------------------|
| 1 | **María González** | `alcaldia_libertador` | `1234` | Alcaldía | Distrito Capital | $35,000.00 | Saludable (36.3% usado) |
| 2 | **Carlos Rodríguez** | `constructora_valencia` | `1234` | Empresa (Nivel 4) | Carabobo | $36,000.00 | Alerta (59.2% usado) |
| 3 | **José Martínez** | `maestro_martinez` | `1234` | Constructor (Nivel 2) | Zulia | $5,500.00 | Saludable (21.8% usado) |
| 4 | **Ing. Ana Pérez** | `gobernacion_miranda` | `admin123` | **Gobernación (Supervisor)** | Miranda | $90,000.00 | Saludable (Aprobador general) |
| 5 | **Luis Hernández** | `vialidad_merida` | `1234` | Empresa (Nivel 1) | Mérida | $6,750.00 | **Crítico (91.9% usado)** |
| 6 | **Pedro Castillo** | `alcaldia_iribarren` | `1234` | Alcaldía | Lara | $20,000.00 | Cotización ENVIADA pendiente |

> 📌 **Aclaratoria Didáctica:** En un entorno de producción, las contraseñas nunca se guardan en texto plano en el cliente; se gestionan mediante tokens JWT, hashing con salting (bcrypt/argon2) y canales cifrados HTTPS. En este proyecto académico, las credenciales residen en `js/datos.js` con fines de evaluación docente.

---

## 4. Estructura del Proyecto y Arquitectura

El proyecto implementa una **separación estricta de responsabilidades**:

```text
c:\Users\Adrian\UNC\Logica y Algoritmo\Proyecto\
│
├── index.html          # Interfaz visual principal y contenedor de módulos
├── estilos.css         # Diseño moderno tipo dashboard, fondo blanco y @media print
├── pruebas.html        # Ejecutor y reporte visual de pruebas automáticas
├── README.md           # Memoria técnica y guía de exposición
│
├── img\
│   ├── logo-blanco.png # Logo oficial SICOP para fondos oscuros (barra superior)
│   └── logo-negro.png  # Logo oficial SICOP para fondos claros (login, documentos, favicon)
│
└── js\
    ├── iconos.js       # Catálogo vectorial de iconos SVG limpios (trazo uniforme de 1.75px, sin emojis)
    ├── datos.js        # Constantes de negocio, persistencia en localStorage y datos iniciales
    ├── logica.js       # Reglas puras, algoritmos de cálculo y burbuja (SIN manipular el DOM)
    ├── interfaz.js     # Enlace DOM, eventos, renderizado dinámico, modales e impresión
    └── pruebas.js      # Suite de aserciones automáticas para pruebas unitarias
```

---

## 5. Decisiones de Diseño y Rediseño Visual SaaS

Para la entrega y defensa de este proyecto, la interfaz fue completamente rediseñada bajo la estética de plataformas SaaS modernas (como Linear, Stripe Dashboard y Notion):

1. **Diseño Visual SaaS Minimalista y Sobrio:**
   - **Tipografía de sistema:** Pila tipográfica nativa (`Inter`, `"Segoe UI"`, `system-ui`, `-apple-system`, `sans-serif`) de alta legibilidad, con números tabulares (`tabular-nums`) para montos y tablas contables alineadas a la derecha.
   - **Paleta monocromática refinada:** Escala neutra pizarra/zinc con un único color de acento principal (`#4F46E5` Índigo), tintes suaves para estados semánticos (verde esmeralda, ámbar y rojo coral) y bordes sutiles de 1px.
   - **Fondo blanco limpio y modo oscuro integral:** Soporte de tema claro u oscuro con alternador manual en la barra superior guardado en `localStorage` y detección de `prefers-color-scheme`.

2. **Arquitectura de Navegación Tipo Dashboard:**
   - **Sidebar izquierdo colapsable:** Navegación organizada en tres grupos conceptuales: *Operación* (Dashboard, Cotizar, Calculadora, Dónde Comprar), *Gestión* (Historial, Catálogo, Aprobaciones, Supervisión, Bitácora) y *Sistema* (Exportar/Importar, Pruebas Automáticas).
   - **Topbar esbelto y contextual:** Muestra el título de la sección activa, selector global de divisa (USD/Bs), botón de tema, indicador de presupuesto y cápsula de usuario con avatar de iniciales y rol.
   - **Barra inferior móvil (< 768px):** Acceso rápido con un pulgar a los módulos clave en smartphones.

3. **Catálogo Unificado de Iconos SVG Vectoriales (`js/iconos.js`):**
   - **Prohibición estricta de emojis como iconos:** Sustitución total de iconos informales por vectores SVG escritos a mano con trazo uniforme de 1.75 px, terminaciones redondeadas y función helper `icono(nombre, tamano)`.

4. **Corrección de Problemas Visuales de Auditoría:**
   - **Gráfico de barras sin cortes:** En el gráfico "Inversión por Sector", los montos se ubican en una columna fija exterior derecha con números tabulares, impidiendo que barras con baja inversión corten el texto o muestren solo "$".
   - **KPI contextualizado:** El indicador de alerta presupuestaria muestra el estado de la organización para usuarios particulares, y para Gobernación desglosa el número de entidades en alerta y el usuario en riesgo (Luis Hernández, Constructora Andina).
   - **Semáforo presupuestario balanceado:** Vista de 4 cuadrantes ejecutivos (Límite, Gastado, Comprometido y Saldo Disponible) que aprovecha el espacio de la tarjeta sin huecos vacíos.
   - **Eliminación de textos técnicos en pantalla:** La interfaz luce como un software institucional comercial listo para producción.

5. **Asistente de Cotización por Pasos (4 Pasos):**
   - En lugar de una pantalla única densa y saturada, el proceso se dividió en 4 etapas lógicas:
     - **Paso 1 (Obra):** Identificación del proyecto y selección del estado destino para cálculo de flete.
     - **Paso 2 (Materiales):** Selección de partidas, cantidades, calculadora de obra y plantillas.
     - **Paso 3 (Revisión):** Resumen integral con desglose financiero, fiscal y botón pedagógico.
     - **Paso 4 (Envío):** Confirmación, emisión formal, descarga imprimible o envío a supervisión.
   - El estado del borrador se conserva de forma segura si el usuario decide regresar a pasos anteriores.

6. **Plantillas de Obra Típicas Precargadas:**
   - 5 plantillas con valores referenciales editables: *Casa pequeña*, *Cerca perimetral*, *Rehabilitar una calle*, *Alumbrado público* y *Sistema de agua*.
   - Al seleccionarlas, el sistema detecta si ya existen cantidades y pregunta mediante un diálogo modal accesible si desea **reemplazar** o **sumar**.

7. **Cálculo Reactivo "Total en Vivo":**
   - El desglose y los totales en USD y Bs se actualizan automáticamente en un panel lateral flotante mientras el usuario escribe (`evento input`), eliminando la necesidad de pulsar repetidamente botones de "Calcular".

4. **Validación Pedagógica y Mensajes de Error Accionables:**
   - En lugar de alertas genéricas ("Error en formulario"), cada campo defectuoso se resalta en rojo con un mensaje exacto y sugerencias concretas (ej: *"La cantidad debe ser mayor que cero. Prueba con 10."* o *"Escribe solo números, sin letras."*).
   - El error desaparece inmediatamente al corregir la entrada.

5. **Avisos de Bloqueo con Solución Directa:**
   - Si un usuario tiene una cotización en `BORRADOR` o `ENVIADA`, el sistema explica la regla de negocio y le presenta dos botones inmediatos: *"Ir a mi cotización abierta"* o *"Descartar y empezar una nueva"*.
   - Si la Gobernación no puede aprobar por déficit presupuestario, el sistema desglosa cuánto dinero falta con precisión y qué usuario debe reajustar.

6. **Modo Demostración para Exposición:**
   - En la pestaña de Respaldo, dos botones permiten preparar la defensa en clase en segundos:
     - **"✨ Cargar Datos de Demostración":** Precarga 6 usuarios, catálogo completo, cotizaciones de ejemplo y bitácora.
     - **"🗑️ Borrar Todo y Empezar de Cero":** Limpia la base local y restablece los correlativos a cero para demostraciones en vivo.

7. **Formato Numérico Venezolano y Selector de Moneda:**
   - Formato oficial con separador de miles con punto (`.`) y decimales con coma (`,`), por ejemplo: `1.234,56`.
   - Selector global en el encabezado para alternar entre **USD ($)** y **Bolívares (Bs.)** calculados con la tasa BCV oficial.

8. **Duplicación de Cotizaciones y Explicación Didáctica "¿Cómo se calculó esto?":**
   - Botón *"📋 Duplicar"* en el historial que carga una cotización pasada en el asistente (respetando la regla de no tener otra abierta).
   - Modal interactivo didáctico que desglosa las 6 fórmulas matemáticas aplicadas con números reales para explicar al profesor durante la exposición.

9. **Guardado Automático y Recuperación de Borradores:**
   - Cada cambio en el asistente se almacena en `localStorage`. Si el usuario recarga accidentalmente la página, un banner le permite continuar exactamente donde lo dejó.

---

## 6. Explicación Detallada de Módulos y Reglas de Negocio

### Módulo 1: Calculadora de Materiales por Unidad de Obra
- **Pared de bloques:**
  - $\text{Área (m}^2) = \text{Largo} \times \text{Alto}$
  - $\text{Bloques} = \lceil (\text{Área} \times 12.5) \times (1 + \text{Desperdicio}/100) \rceil$
  - $\text{Cemento} = \lceil (\text{Área} \times 0.20) \times (1 + \text{Desperdicio}/100) \rceil$
- **Losa de concreto:**
  - $\text{Volumen (m}^3) = \text{Largo} \times \text{Ancho} \times \text{Espesor}$
  - $\text{Cemento} = \lceil (\text{Volumen} \times 7.0) \times (1 + \text{Desperdicio}/100) \rceil$
  - $\text{Cabillas} = \lceil (\text{Área} \times \text{Cabillas/m}^2) \times (1 + \text{Desperdicio}/100) \rceil$
- **Tubería:**
  - Cada tubo comercial mide 6 metros.
  - $\text{Tubos de 6m} = \lceil (\text{Metros} / 6.0) \times (1 + \text{Desperdicio}/100) \rceil$
- Botón **"➕ Agregar a la Cotización"**: inyecta las cantidades estimadas directamente en el cotizador.

### Módulo 2: Motor de Cotización Financiera
1. **Subtotal:**
   $$\text{Subtotal} = \sum (\text{Cantidad} \times \text{Precio Base} \times \text{Factor Ciudad})$$
   *(Siempre toma por defecto la ciudad más barata del país, ordenada por burbuja).*
2. **Flete Terrestre:**
   $$\text{Flete} = \text{Subtotal} \times (\text{Factor Flete Estado} - 1.00)$$
   *Factores:* Distrito Capital (1.00), Miranda (1.03), Carabobo (1.04), Lara (1.06), Zulia (1.08), Mérida (1.12), Amazonas (1.25).
3. **Descuento Institucional:**
   $$\text{Descuento} = (\text{Subtotal} + \text{Flete}) \times \text{Porcentaje Descuento}$$
   *Descuentos:* Alcaldía (4%), Gobernación (4%), Empresa (2%), Constructor (0%).
4. **Monto Neto:**
   $$\text{Neto} = (\text{Subtotal} + \text{Flete}) - \text{Descuento}$$
5. **Contingencia Técnica:**
   $$\text{Contingencia} = \text{Neto} \times 0.05$$
6. **Impuesto al Valor Agregado (IVA):**
   $$\text{IVA} = (\text{Neto} + \text{Contingencia}) \times 0.16$$
7. **Total General:**
   $$\text{Total USD} = \text{Neto} + \text{Contingencia} + \text{IVA}$$
   $$\text{Total Bs.} = \text{Total USD} \times \text{Tasa BCV}$$

### Módulo 3: Dónde Conviene Comprar (Burbuja Manual)
Ordena 6 ciudades comerciales sin utilizar el método nativo `.sort()`, empleando el algoritmo clásico de ordenamiento por intercambio:
- Caracas (1.05)
- Valencia (0.95)
- Maracay (0.97)
- Barquisimeto (1.00)
- Maracaibo (1.04)
- Puerto Ordaz (0.90) $\rightarrow$ **Mejor opción nacional (Factor 0.90)**

### Módulo 4: Catálogo Editable (Gobernación)
Permite a los supervisores añadir y actualizar materiales, modificar precios base y llevar una bitácora histórica de cada cambio (fecha, usuario y variación).

### Módulo 5: Flujo de Aprobación y Control de Presupuesto
- **Regla Estricta:** Un usuario **no puede crear** una nueva cotización si posee alguna en estado `BORRADOR` o `ENVIADA`.
- **Condición de Aprobación:**
  $$\text{Saldo Disponible} = \text{Límite} - (\text{Gastado} + \text{Comprometido})$$
  Si $\text{Total Requerido} \le \text{Saldo Disponible}$, la Gobernación puede aprobar; el monto pasa a **Comprometido**. Si falta saldo, el sistema bloquea la aprobación y calcula el déficit exacto.
- **Entrega de Obra:** Al marcar la cotización como `ENTREGADA`, el monto se resta de comprometido y se suma a **Gastado definitivo**.
- **Semáforo Financiero:**
  - Consumo $< 60\%$: Normal (Verde)
  - Consumo entre $60\%$ y $89.9\%$: Alerta (Ámbar)
  - Consumo $\ge 90\%$: Crítico (Rojo)

### Módulo 6: Documento Imprimible Formal
Genera una cotización membretada oficial con correlativo (`COT-XXXX`), fecha de emisión, vigencia de 15 días hábiles, tabla de materiales, cuadro fiscal y renglón de firmas del solicitante y la Gobernación. Compatible con `window.print()` y estilos `@media print` que suprimen menús y botones.

---

## 7. Ejemplo Numérico Paso a Paso

Supongamos que el usuario **Carlos Rodríguez** (Empresa, Carabobo) cotiza:
- **100 sacos de cemento** (Precio base: \$8.50)
- Se compra en **Puerto Ordaz** (Factor: 0.90)
- Tasa BCV: **36.50 Bs./USD**

1. **Precio Unitario Ajustado:**
   $$\$8.50 \times 0.90 = \$7.65\text{ USD por saco}$$
2. **Subtotal:**
   $$100 \times \$7.65 = \$765.00\text{ USD}$$
3. **Flete hacia Carabobo (Factor 1.04):**
   $$\text{Flete} = \$765.00 \times (1.04 - 1.00) = \$765.00 \times 0.04 = \$30.60\text{ USD}$$
4. **Base antes de descuento:**
   $$\$765.00 + \$30.60 = \$795.60\text{ USD}$$
5. **Descuento Empresa (2%):**
   $$\text{Descuento} = \$795.60 \times 0.02 = \$15.91\text{ USD}$$
6. **Monto Neto:**
   $$\text{Neto} = \$795.60 - \$15.91 = \$779.69\text{ USD}$$
7. **Contingencia (5%):**
   $$\text{Contingencia} = \$779.69 \times 0.05 = \$38.98\text{ USD}$$
8. **Base Imponible del IVA:**
   $$\$779.69 + \$38.98 = \$818.67\text{ USD}$$
9. **IVA (16%):**
   $$\text{IVA} = \$818.67 \times 0.16 = \$130.99\text{ USD}$$
10. **Total Final en USD:**
    $$\text{Total USD} = \$818.67 + \$130.99 = \$949.66\text{ USD}$$
11. **Total en Bolívares:**
    $$\text{Total Bs.} = \$949.66 \times 36.50 = \text{Bs. } 34.662,59$$

---

## 8. Ciclo de Vida de una Cotización (Diagrama Mermaid)

```mermaid
stateDiagram-v2
    [*] --> BORRADOR: Usuario genera cálculo en el Asistente
    BORRADOR --> CANCELADA: Usuario descarta cotización
    BORRADOR --> ENVIADA: Usuario envía a Gobernación
    
    state ENVIADA {
        [*] --> EnRevision
        EnRevision --> EvaluacionPresupuesto: Gobernación audita fondos
    }
    
    ENVIADA --> RECHAZADA: Fondos insuficientes o motivo técnico justificado
    ENVIADA --> APROBADA: Fondos suficientes (se suma a Comprometido)
    
    APROBADA --> ENTREGADA: Materiales recibidos en obra (Comprometido pasa a Gastado)
    
    RECHAZADA --> [*]
    ENTREGADA --> [*]
    CANCELADA --> [*]
```

---

## 9. Casos de Uso por Rol Institucional

```
+--------------------------------------------------------------------------+
|                        MATRIZ DE PERMISOS POR ROL                        |
+------------------------------+-----------+---------+-------------+-------+
| Módulo / Capacidad           | Alcaldía  | Empresa | Constructor | Gob.  |
+------------------------------+-----------+---------+-------------+-------+
| Iniciar Sesión con Clave     |    SI     |   SI    |     SI      |  SI   |
| Dashboard Personal           |    SI     |   SI    |     SI      |  NO   |
| Dashboard Global             |    NO     |   NO    |     NO      |  SI   |
| Calculadora de Materiales    |    SI     |   SI    |     SI      |  SI   |
| Asistente de 4 Pasos         |    SI     |   SI    |     SI      |  SI   |
| Plantillas de Obra Típicas   |    SI     |   SI    |     SI      |  SI   |
| Total en Vivo Reactivo       |    SI     |   SI    |     SI      |  SI   |
| Ver Dónde Conviene Comprar   |    SI     |   SI    |     SI      |  SI   |
| Consultar Historial Propio   |    SI     |   SI    |     SI      |  SI   |
| Duplicar Cotización Previa   |    SI     |   SI    |     SI      |  SI   |
| Consultar Historial Global   |    NO     |   NO    |     NO      |  SI   |
| Editar Catálogo y Precios    |    NO     |   NO    |     NO      |  SI   |
| Aprobar / Rechazar Solicitud |    NO     |   NO    |     NO      |  SI   |
| Marcar Obra Entregada        |    NO     |   NO    |     NO      |  SI   |
| Ver Ranking y Supervisión    |    NO     |   NO    |     NO      |  SI   |
| Ver Bitácora y Alertas       |    NO     |   NO    |     NO      |  SI   |
| Exportar / Importar Datos    |    SI     |   SI    |     SI      |  SI   |
| Modo Demostración de Clase   |    SI     |   SI    |     SI      |  SI   |
+------------------------------+-----------+---------+-------------+-------+
```

---

## 10. Batería de Pruebas Automáticas (30 Casos)

Al abrir `pruebas.html`, el sistema ejecuta automáticamente **30 casos de prueba unitaria e integración**:

1. **Cálculo de Cotización con IVA y Contingencia:** Comprueba la exactitud de los decimales fiscales.
2. **Rechazo de Cantidades Negativas:** Verifica que no se admitan entradas numéricas menores a cero.
3. **Bloqueo de Cotización Abierta:** Valida la regla de una sola cotización en curso por solicitante.
4. **Algoritmo Burbuja Ascendente:** Comprueba el orden de ciudades de menor a mayor factor.
5. **Algoritmo Burbuja Descendente:** Comprueba el ranking de supervisión de mayor a menor monto.
6. **Rechazo por Déficit de Fondos:** Impide aprobar cotizaciones que sobrepasen el saldo disponible.
7. **Aprobación Exitosa:** Verifica que el saldo comprometido aumente correctamente.
8. **Transición a ENTREGADA:** Comprueba el traspaso de comprometido a gastado.
9. **Cálculo de Pared de Bloques:** Verifica el cómputo de bloques y cemento con margen de desperdicio.
10. **Cálculo de Losa de Concreto:** Verifica volumen en m³ y sacos de cemento requeridos.
11. **Redondeo hacia arriba en Tubería:** Comprueba el uso de `Math.ceil()` en tramos de 6m.
12. **Descuento por Perfil:** Valida el 4% para Alcaldías y 0% para Constructor.
13. **Semáforo Presupuestario:** Comprueba los límites `<60%`, `60%-89%` y `≥90%`.
14. **Validación de Catálogo:** Comprueba el rechazo de precios `<= 0` y nombres repetidos.
15. **Mensajes de Error Claros y Didácticos:** Valida que el rechazo de negativos incluya consejos de acción.
16. **Asistente Paso 1 (Obra):** Valida longitud del nombre ($\ge 4$ caracteres) y estado geográfico válido.
17. **Plantillas de Obra:** Verifica la precarga correcta de materiales en *"Casa pequeña"*.
18. **Consistencia de Total en Vivo:** Valida que el cálculo reactivo coincida con el presupuesto formal.
19. **Formato Monetario Venezolano:** Comprueba separador de miles con punto (`.`) y decimales con coma (`,`).
20. **Formato de Bolívares con Tasa BCV:** Valida la conversión con tasa y prefijo `Bs.`.
21. **Duplicación de Cotización:** Bloquea la acción si el solicitante ya posee una cotización abierta.
22. **Modo Demostración:** Verifica que `vaciarDatosSistema()` reinicie el correlativo y limpie cotizaciones.
23. **Sanitización XSS con `escaparHtml()`:** Comprueba el escape riguroso de caracteres peligrosos (`<`, `>`, `&`, `"`, `'`).
24. **Formato Monetario de Cifras Negativas:** Verifica la posición correcta del signo negativo antes del símbolo (`-$1.234,56` y `-Bs. 1.234,56`).
25. **Helpers de Moneda `usd()` y `bs()`:** Comprueba el formateo consistente con símbolos y dos decimales.
26. **Conversión Cambiaria `bsDesdeUSD()`:** Verifica el cálculo de equivalencia cambiaria en Bolívares según tasa oficial BCV.
27. **Validación Estricta de Respaldo JSON:** Rechaza archivos con esquema incorrecto o arreglos ausentes/inválidos.
28. **Detección de Anomalías Presupuestarias con Alertas:** Comprueba que la alerta de consumo crítico identifique correctamente al usuario en riesgo.
29. **Persistencia Aislada de Borradores por Usuario:** Valida que cada usuario conserve su propio borrador sin colisiones ni sobreescrituras.
30. **Desglose de Pasos Pedagógicos:** Comprueba que el cálculo se descomponga en 5 pasos matemáticos detallados con fórmulas y resultados.

---

## 11. Guía para la Exposición en Clase

Para una presentación exitosa y fluida ante el docente y compañeros de cátedra:

1. **Apertura (1 minuto):**
   - Abrir `index.html` con doble clic. Explicar el propósito del sistema: cotizador transparente para obras públicas en Venezuela sin frameworks ni backend.
   - Mostrar el logotipo institucional y el fondo blanco limpio.
2. **Autenticación y Roles (1 minuto):**
   - Usar el selector de usuario de prueba para ingresar como **María González (Alcaldía Libertador)**.
   - Señalar en el encabezado cómo se calculan el presupuesto disponible y el semáforo presupuestario en tiempo real.
3. **Asistente de Cotización y Total en Vivo (2 minutos):**
   - Ir al módulo **Cotizador**.
   - En **Paso 1**, escribir el nombre de una obra y seleccionar el estado de destino (explicar que el flete depende de la distancia).
   - En **Paso 2**, pulsar la plantilla **"Casa pequeña"** y mostrar cómo se cargan las cantidades automáticamente.
   - Modificar una cantidad y señalar cómo el panel lateral de **Total en Vivo** reacciona de inmediato sin recargar la página.
   - En **Paso 3**, presionar el botón **"¿Cómo se calculó esto?"** para mostrar el desglose pedagógico paso a paso.
   - En **Paso 4**, presionar **"Enviar para Aprobación a Gobernación"**.
4. **Regla de Bloqueo Estricto y Duplicación (1 minuto):**
   - Intentar iniciar una nueva cotización: mostrar el aviso de advertencia con los botones a la solución (*"Ir a mi cotización abierta"* o *"Descartar"*).
   - Ir al **Historial** y mostrar el botón *"Duplicar"*.
5. **Aprobación como Supervisor (Gobernación) (2 minutos):**
   - Cerrar sesión e ingresar como **Ing. Ana Pérez (Gobernación)**.
   - Ir al módulo **Aprobaciones**.
   - Mostrar cómo el sistema audita si el solicitante tiene fondos suficientes antes de permitir presionar **"Aprobar"**.
   - Si se rechaza, el sistema despliega un modal formal de justificación técnica para asentar en la bitácora sin diálogos nativos `prompt()`.
   - Aprobar la cotización y mostrar cómo los fondos pasan a **Comprometidos**.
   - Luego marcarla como **"Entregada"** y verificar en el Dashboard que pasaron a **Gastados definitivos**.
6. **Algoritmo Burbuja y Verificación de Pruebas (1 minuto):**
   - Mostrar el módulo **Dónde Comprar**, explicando cómo el algoritmo de ordenamiento burbuja escrito en `js/logica.js` determina que Puerto Ordaz es la ciudad más barata (factor 0.90).
   - Abrir `pruebas.html` y mostrar la batería de **30 pruebas automáticas en verde (100% aprobadas)**.

---

## 12. Limitaciones y Trabajo Futuro

Para fines de evaluación y defensa académica, se destacan las siguientes limitaciones técnicas y oportunidades de evolución:

- **Almacenamiento en `localStorage`:** Los datos residen exclusivamente en el navegador del equipo donde se ejecuta. Si se abre en otra computadora, los datos no estarán sincronizados a menos que se use la función de exportar e importar JSON.
- **Autenticación en el Cliente:** La validación de credenciales se realiza en JavaScript local. Para un producto comercial, se requiere un servidor backend (Node.js, Python o Java) con base de datos relacional (PostgreSQL) y hashing de contraseñas.
- **Precios Referenciales:** Los precios de materiales, factores de flete y multiplicadores de nivel son valores de prueba representativos para fines didácticos; en producción se conectarían a un servicio web de precios del sector construcción.

---

## 13. Guía de Publicación en GitHub Pages

Para publicar este proyecto de forma gratuita en la web y compartir el enlace con profesores y compañeros:

1. Cree un repositorio público en [GitHub](https://github.com) llamado `sicop-ve`.
2. Suba los archivos del proyecto manteniendo la estructura:
   - `index.html` (en la raíz)
   - `estilos.css` (en la raíz)
   - `pruebas.html` (en la raíz)
   - `README.md` (en la raíz)
   - Carpeta `img/` con los logos.
   - Carpeta `js/` con sus 5 archivos (`iconos.js`, `datos.js`, `logica.js`, `interfaz.js`, `pruebas.js`).
3. En GitHub, ingrese a **Settings** $\rightarrow$ **Pages**.
4. En **Build and deployment** $\rightarrow$ **Branch**, elija la rama `main` (o `master`) y la carpeta `/ (root)`.
5. Presione **Save**. En un par de minutos, GitHub generará una URL pública tipo:
   `https://tu-usuario.github.io/sicop-ve/`
6. ¡Listo! Puede compartir ese enlace directo para la evaluación en clase.
