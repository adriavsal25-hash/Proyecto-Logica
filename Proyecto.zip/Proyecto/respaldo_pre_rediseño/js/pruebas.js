/* ============================================================
   SICOP-VE — Suite de Pruebas Unitarias y de Integración (js/pruebas.js)
   Proyecto Final: Lógica y Programación I
   
   Ejecuta automáticamente una batería de pruebas sobre las funciones
   de js/logica.js para verificar el cumplimiento riguroso de cada
   regla de negocio y de los algoritmos de la materia.
   ============================================================ */

/**
 * Registra y ejecuta la suite completa de pruebas automáticas.
 */
function ejecutarSuitePruebas() {
    var resultados = [];

    /**
     * Función auxiliar para asentar un caso de prueba.
     */
    function verificar(numero, caso, esperado, obtenido, condicionExito) {
        resultados.push({
            numero: numero,
            caso: caso,
            esperado: esperado,
            obtenido: obtenido,
            paso: Boolean(condicionExito)
        });
    }

    // ------------------------------------------------------------
    // PRUEBA 1: Total con IVA y Contingencia correcto
    // ------------------------------------------------------------
    (function () {
        // Material: 10 unidades a $10.00 en Pto Ordaz (factor 0.90) = Subtotal $90.00
        // Estado: Distrito Capital (factor flete 1.00 -> flete $0.00)
        // Perfil: Constructor (descuento 0%)
        // Neto = 90.00
        // Contingencia (5%) = 4.50
        // Base IVA = 94.50
        // IVA (16%) = 15.12
        // Total USD = 109.62
        var items = [{ materialId: 99, nombre: 'Item Test', unidad: 'Und', sector: 'Construcción', precioBase: 10.00, cantidad: 10 }];
        var ciudad = { nombre: 'Puerto Ordaz', factor: 0.90 };
        var usuario = { perfil: 'Constructor', estado: 'Distrito Capital' };
        var calc = calcularPresupuestoCotizacion(items, ciudad, usuario, 36.50);

        var totalObtenido = Number(calc.total.toFixed(2));
        var totalEsperado = 109.62;
        verificar(
            1,
            'Cálculo de Cotización con IVA (16%) y Contingencia (5%)',
            '$' + totalEsperado + ' USD',
            '$' + totalObtenido + ' USD',
            Math.abs(totalObtenido - totalEsperado) < 0.01
        );
    })();

    // ------------------------------------------------------------
    // PRUEBA 2: Rechazo de cantidades negativas en validación
    // ------------------------------------------------------------
    (function () {
        var catalogo = [{ id: 1, nombre: 'Cemento', precioBase: 8.5, activo: true, unidad: 'Saco' }];
        var entradaInvalida = { 1: -5 };
        var res = validarCantidadesCotizacion(catalogo, entradaInvalida);
        verificar(
            2,
            'Validación de cantidades: rechazar números negativos',
            'valido: false',
            'valido: ' + res.valido + ' (' + res.error + ')',
            res.valido === false && res.error.indexOf('no puede ser negativa') !== -1
        );
    })();

    // ------------------------------------------------------------
    // PRUEBA 3: Restricción de una cotización abierta (BORRADOR o ENVIADA)
    // ------------------------------------------------------------
    (function () {
        var cotizacionesEjemplo = [
            { id: 101, usuarioId: 50, estado: 'BORRADOR', correlativo: 'COT-0101' },
            { id: 102, usuarioId: 51, estado: 'APROBADA', correlativo: 'COT-0102' }
        ];
        var resUsuario50 = verificarDisponibilidadNuevaCotizacion(50, cotizacionesEjemplo);
        var resUsuario51 = verificarDisponibilidadNuevaCotizacion(51, cotizacionesEjemplo);

        var paso = (resUsuario50.puede === false) && (resUsuario51.puede === true);
        verificar(
            3,
            'Restricción estricta: bloqueo si tiene cotización BORRADOR o ENVIADA',
            'Usuario 50 bloqueado, Usuario 51 habilitado',
            'Usuario 50 puede: ' + resUsuario50.puede + ' | Usuario 51 puede: ' + resUsuario51.puede,
            paso
        );
    })();

    // ------------------------------------------------------------
    // PRUEBA 4: Algoritmo Burbuja ascendente (sin usar sort())
    // ------------------------------------------------------------
    (function () {
        var ciudades = [
            { nombre: 'Caracas', factor: 1.05 },
            { nombre: 'Puerto Ordaz', factor: 0.90 },
            { nombre: 'Valencia', factor: 0.95 }
        ];
        var ordenadas = ordenarBurbuja(ciudades, 'factor', true);
        var esMenorAMayor = (ordenadas[0].factor === 0.90 && ordenadas[1].factor === 0.95 && ordenadas[2].factor === 1.05);

        verificar(
            4,
            'Algoritmo Burbuja manual (Ascendente de ciudades por factor)',
            'Puerto Ordaz (0.90), Valencia (0.95), Caracas (1.05)',
            ordenadas.map(function (c) { return c.nombre + ' (' + c.factor + ')'; }).join(', '),
            esMenorAMayor
        );
    })();

    // ------------------------------------------------------------
    // PRUEBA 5: Algoritmo Burbuja descendente (Ranking por monto)
    // ------------------------------------------------------------
    (function () {
        var lista = [
            { nombre: 'Obra B', monto: 1200 },
            { nombre: 'Obra A', monto: 5000 },
            { nombre: 'Obra C', monto: 3500 }
        ];
        var ranking = ordenarBurbuja(lista, 'monto', false);
        var ordenCorrecto = (ranking[0].monto === 5000 && ranking[1].monto === 3500 && ranking[2].monto === 1200);

        verificar(
            5,
            'Algoritmo Burbuja manual (Descendente para ranking de supervisión)',
            '5000, 3500, 1200',
            ranking.map(function (r) { return r.monto; }).join(', '),
            ordenCorrecto
        );
    })();

    // ------------------------------------------------------------
    // PRUEBA 6: Aprobación rechazada por fondos insuficientes
    // ------------------------------------------------------------
    (function () {
        // Usuario con límite $5,000, gastado $4,000, comprometido $800 -> Disponible $200
        var usuario = {
            id: 88,
            nombre: 'Test Fondos',
            perfil: 'Empresa',
            limiteGasto: 5000,
            gastado: 4000,
            comprometido: 800
        };
        // Cotización por $500 (supera los $200 disponibles)
        var cot = { total: 500 };
        var evaluacion = evaluarAprobacionCotizacion(cot, usuario);

        verificar(
            6,
            'Control Presupuestario: rechazo de aprobación por déficit de fondos',
            'aprobable: false con déficit de $300.00',
            'aprobable: ' + evaluacion.aprobable + ' | faltante: $' + (evaluacion.faltante || 0),
            evaluacion.aprobable === false && Math.abs(evaluacion.faltante - 300) < 0.01
        );
    })();

    // ------------------------------------------------------------
    // PRUEBA 7: Aprobación exitosa y reserva de fondos comprometidos
    // ------------------------------------------------------------
    (function () {
        var usuario = {
            id: 89,
            nombre: 'Test Aprobado',
            perfil: 'Alcaldía',
            limiteGasto: 10000,
            gastado: 2000,
            comprometido: 1000
        };
        // Cotización por $1500 (disponible es $7000)
        var cot = { total: 1500 };
        var evaluacion = evaluarAprobacionCotizacion(cot, usuario);

        verificar(
            7,
            'Control Presupuestario: aprobación y reserva de saldo comprometido',
            'aprobable: true, nuevoComprometido: $2500.00',
            'aprobable: ' + evaluacion.aprobable + ', comprometido estimado: $' + evaluacion.nuevoComprometidoEstimado,
            evaluacion.aprobable === true && evaluacion.nuevoComprometidoEstimado === 2500
        );
    })();

    // ------------------------------------------------------------
    // PRUEBA 8: Paso de comprometido a gastado al entregar obra
    // ------------------------------------------------------------
    (function () {
        var usuario = {
            limiteGasto: 10000,
            comprometido: 2500,
            gastado: 2000
        };
        var montoEntregado = 1500;
        // Simulación lógica de transición ENTREGADA:
        usuario.comprometido -= montoEntregado;
        usuario.gastado += montoEntregado;

        var paso = (usuario.comprometido === 1000 && usuario.gastado === 3500);
        verificar(
            8,
            'Transición de Estado ENTREGADA: comprometido pasa a gastado',
            'Comprometido: $1000, Gastado: $3500',
            'Comprometido: $' + usuario.comprometido + ', Gastado: $' + usuario.gastado,
            paso
        );
    })();

    // ------------------------------------------------------------
    // PRUEBA 9: Estimador de Materiales - Pared de bloques
    // ------------------------------------------------------------
    (function () {
        // Pared 4m largo x 2.5m alto = 10 m²
        // Desperdicio: 10%
        // Bloques base = 10 * 12.5 = 125 bloques -> con 10% = Math.ceil(137.5) = 138 bloques
        // Cemento base = 10 * 0.20 = 2 sacos -> con 10% = Math.ceil(2.2) = 3 sacos
        var est = calcularMaterialesPared(4, 2.5, 10);
        var bloques = est.resultados[0].cantidad;
        var cemento = est.resultados[1].cantidad;

        var paso = (bloques === 138 && cemento === 3);
        verificar(
            9,
            'Calculadora de Obra: Estimación de bloques y cemento para pared (10 m²)',
            '138 bloques y 3 sacos cemento (con 10% desperdicio)',
            bloques + ' bloques y ' + cemento + ' sacos',
            paso
        );
    })();

    // ------------------------------------------------------------
    // PRUEBA 10: Estimador de Materiales - Losa de Concreto
    // ------------------------------------------------------------
    (function () {
        // Losa 5m x 4m x 0.10m espesor = 2 m³ (Área 20 m²)
        // Cabilla: 1.5 barras/m²
        // Desperdicio: 10%
        // Cemento base = 2 * 7 = 14 sacos -> con 10% = Math.ceil(15.4) = 16 sacos
        // Cabilla base = 20 * 1.5 = 30 barras -> con 10% = Math.ceil(33) = 33 barras
        var est = calcularMaterialesLosa(5, 4, 0.10, 1.5, 10);
        var cemento = est.resultados[0].cantidad;
        var cabillas = est.resultados[1].cantidad;

        var paso = (cemento === 16 && cabillas === 33);
        verificar(
            10,
            'Calculadora de Obra: Estimación de concreto y cabillas para losa (2 m³)',
            '16 sacos cemento y 33 barras de cabilla',
            cemento + ' sacos y ' + cabillas + ' cabillas',
            paso
        );
    })();

    // ------------------------------------------------------------
    // PRUEBA 11: Redondeo de tramos de tubería con Math.ceil
    // ------------------------------------------------------------
    (function () {
        // Tramo de 15 metros lineales (a 6m por tubo = 2.5 tubos)
        // Con 10% de desperdicio: 2.5 * 1.10 = 2.75 tubos -> Math.ceil = 3 tubos
        var est = calcularMaterialesTuberia(15, 10);
        var tubos = est.resultados[0].cantidad;

        verificar(
            11,
            'Calculadora de Tubería: Redondeo hacia arriba con Math.ceil (tramos de 6m)',
            '3 tubos de 6m',
            tubos + ' tubos',
            tubos === 3
        );
    })();

    // ------------------------------------------------------------
    // PRUEBA 12: Descuento institucional por perfil (Alcaldía vs Constructor)
    // ------------------------------------------------------------
    (function () {
        var items = [{ materialId: 1, nombre: 'Test', unidad: 'U', sector: 'V', precioBase: 100, cantidad: 1 }];
        var ciudad = { nombre: 'Base', factor: 1.00 };

        var uAlcaldia = { perfil: 'Alcaldía', estado: 'Distrito Capital' };
        var uConstructor = { perfil: 'Constructor', estado: 'Distrito Capital' };

        var calcAlcaldia = calcularPresupuestoCotizacion(items, ciudad, uAlcaldia, 36.50);
        var calcConstructor = calcularPresupuestoCotizacion(items, ciudad, uConstructor, 36.50);

        var paso = (calcAlcaldia.descuento === 4.00 && calcConstructor.descuento === 0.00);
        verificar(
            12,
            'Diferenciación de Descuento por Perfil (Alcaldía 4% vs Constructor 0%)',
            'Alcaldía: $4.00 desc, Constructor: $0.00 desc',
            'Alcaldía: $' + calcAlcaldia.descuento.toFixed(2) + ', Constructor: $' + calcConstructor.descuento.toFixed(2),
            paso
        );
    })();

    // ------------------------------------------------------------
    // PRUEBA 13: Semáforo de ejecución presupuestaria
    // ------------------------------------------------------------
    (function () {
        var uNormal = { limiteGasto: 1000, gastado: 400, comprometido: 100 }; // 50% -> normal
        var uAlerta = { limiteGasto: 1000, gastado: 600, comprometido: 100 }; // 70% -> alerta
        var uCritico = { limiteGasto: 1000, gastado: 850, comprometido: 100 }; // 95% -> critico

        var stNormal = calcularEstadoPresupuestoUsuario(uNormal).semaforo;
        var stAlerta = calcularEstadoPresupuestoUsuario(uAlerta).semaforo;
        var stCritico = calcularEstadoPresupuestoUsuario(uCritico).semaforo;

        var paso = (stNormal === 'normal' && stAlerta === 'alerta' && stCritico === 'critico');
        verificar(
            13,
            'Semáforo Presupuestario (<60% normal, 60%-89% alerta, >=90% crítico)',
            'normal, alerta, critico',
            stNormal + ', ' + stAlerta + ', ' + stCritico,
            paso
        );
    })();

    // ------------------------------------------------------------
    // PRUEBA 14: Validación de material en Catálogo (nombre único y precio > 0)
    // ------------------------------------------------------------
    (function () {
        var catalogo = [{ id: 1, nombre: 'Cemento Gris', precioBase: 8.5 }];
        var matInvalidoPrecio = { nombre: 'Pintura', precioBase: -2, unidad: 'Galón' };
        var matInvalidoRepetido = { nombre: 'cemento gris', precioBase: 10, unidad: 'Saco' };

        var val1 = validarMaterialCatalogo(matInvalidoPrecio, catalogo);
        var val2 = validarMaterialCatalogo(matInvalidoRepetido, catalogo);

        var paso = (val1.valido === false && val2.valido === false);
        verificar(
            14,
            'Catálogo Gobernación: Rechazo de precio <= 0 y nombres duplicados',
            'Ambos rechazados con mensajes explicativos',
            'Val1: ' + val1.valido + ' (' + val1.error + ') | Val2: ' + val2.valido + ' (' + val2.error + ')',
            paso
        );
    })();

    // ------------------------------------------------------------
    // PRUEBA 15: Validación pedagógica de cantidades (rechazo de negativos con sugerencia concreta)
    // ------------------------------------------------------------
    (function () {
        var catalogo = [{ id: 1, nombre: 'Cemento Portland Tipo I', precioBase: 8.5, activo: true, unidad: 'Saco' }];
        var entradaInvalida = { 1: -10 };
        var res = validarCantidadesCotizacion(catalogo, entradaInvalida);

        var contieneConsejo = res.error && (res.error.indexOf('Prueba con') !== -1 || res.error.indexOf('mayor que cero') !== -1);
        var rechazoNegativo = (res.valido === false) && (res.error.indexOf('no puede ser negativa') !== -1);

        verificar(
            15,
            'Mensajes de Error Claros: Rechazo de negativos con instrucción didáctica',
            'valido: false con mensaje que incluye sugerencia concreta',
            'valido: ' + res.valido + ' (' + res.error + ')',
            rechazoNegativo && contieneConsejo
        );
    })();

    // ------------------------------------------------------------
    // PRUEBA 16: Asistente Paso 1: Validación de nombre descriptivo y estado de obra
    // ------------------------------------------------------------
    (function () {
        var invalidoPorNombreCorto = validarPasoObra('Abc', 'Miranda');
        var validoCorrecto = validarPasoObra('Reparación Integral Ambulatorio', 'Miranda');
        var invalidoPorEstado = validarPasoObra('Reparación Integral Ambulatorio', 'EstadoInexistente');

        var paso = (invalidoPorNombreCorto.valido === false) &&
                   (validoCorrecto.valido === true) &&
                   (invalidoPorEstado.valido === false);

        verificar(
            16,
            'Asistente Paso 1: Validación de obra (nombre >= 4 chars y estado venezolano válido)',
            'Corto: false, Correcto: true, EstadoInv: false',
            'Corto: ' + invalidoPorNombreCorto.valido + ', Correcto: ' + validoCorrecto.valido + ', EstadoInv: ' + invalidoPorEstado.valido,
            paso
        );
    })();

    // ------------------------------------------------------------
    // PRUEBA 17: Plantillas de Obra: Verificación de estructura y precarga ("Casa pequeña")
    // ------------------------------------------------------------
    (function () {
        var plantilla = PLANTILLAS_OBRA ? PLANTILLAS_OBRA['casa_pequena'] : null;
        var existePlantilla = Boolean(plantilla && plantilla.cantidades);

        // Casa pequeña define: Cemento (id 1) = 40 sacos, Bloques (id 3) = 350 unidades
        var tieneCemento = plantilla && (plantilla.cantidades[1] === 40);
        var tieneBloques = plantilla && (plantilla.cantidades[3] === 350);

        verificar(
            17,
            'Plantillas de Obra: Estructura precargada "Casa pequeña" (40 sacos cemento, 350 bloques)',
            'Plantilla existente con Cemento=40 y Bloques=350',
            existePlantilla ? 'Nombre: ' + plantilla.nombre + ' | Cemento: ' + (plantilla.cantidades[1] || 0) + ' | Bloques: ' + (plantilla.cantidades[3] || 0) : 'No definida',
            existePlantilla && tieneCemento && tieneBloques
        );
    })();

    // ------------------------------------------------------------
    // PRUEBA 18: Total en Vivo: Consistencia entre cálculo reactivo y presupuesto definitivo
    // ------------------------------------------------------------
    (function () {
        var itemsVivo = [
            { materialId: 1, nombre: 'Cemento Portland', precioBase: 8.50, cantidad: 20, sector: 'Construcción', unidad: 'Saco' },
            { materialId: 2, nombre: 'Cabilla 1/2', precioBase: 14.00, cantidad: 10, sector: 'Construcción', unidad: 'Barra' }
        ];
        var ciudad = { nombre: 'Valencia', factor: 0.95 };
        var usuario = { perfil: 'Empresa', estado: 'Carabobo' };
        var tasa = 40.00;

        var calculoVivo = calcularPresupuestoCotizacion(itemsVivo, ciudad, usuario, tasa);

        // Subtotal = (20*8.50 + 10*14.00) * 0.95 = (170 + 140) * 0.95 = 310 * 0.95 = 294.50
        // Flete Carabobo (1.04) = 294.50 * 0.04 = 11.78
        // Descuento Empresa (2%) = (294.50 + 11.78) * 0.02 = 306.28 * 0.02 = 6.1256 -> 6.13
        // Neto = 306.28 - 6.13 = 300.15
        // Contingencia (5%) = 300.15 * 0.05 = 15.01
        // IVA (16%) = (300.15 + 15.01) * 0.16 = 315.16 * 0.16 = 50.43
        // Total USD = 315.16 + 50.43 = 365.59
        var subtotalEsperado = 294.50;
        var paso = Math.abs(calculoVivo.subtotal - subtotalEsperado) < 0.01 && calculoVivo.total > 0;

        verificar(
            18,
            'Total en Vivo: Consistencia matemática de subtotal con factor de ciudad',
            '$' + subtotalEsperado + ' USD',
            '$' + calculoVivo.subtotal.toFixed(2) + ' USD (Total final: $' + calculoVivo.total.toFixed(2) + ' USD)',
            paso
        );
    })();

    // ------------------------------------------------------------
    // PRUEBA 19: Formato Monetario Venezolano (Miles con punto, decimales con coma)
    // ------------------------------------------------------------
    (function () {
        var formateadoSimple = formatearMoneda(1234.56);
        var formateadoGrande = formatearMoneda(1234567.89, 'USD');

        var paso = (formateadoSimple === '1.234,56') && (formateadoGrande === '$1.234.567,89');

        verificar(
            19,
            'Formato Venezolano: Miles con punto (.) y decimales con coma (,)',
            '1.234,56 y $1.234.567,89',
            formateadoSimple + ' y ' + formateadoGrande,
            paso
        );
    })();

    // ------------------------------------------------------------
    // PRUEBA 20: Formato de Bolívares con tasa BCV oficial (prefijo "Bs.")
    // ------------------------------------------------------------
    (function () {
        // $100.00 a tasa 40.00 Bs/USD = Bs. 4.000,00
        var formateadoBs = formatearMoneda(100.00, 'Bs', 40.00);
        var esperado = 'Bs. 4.000,00';
        var paso = (formateadoBs === esperado);

        verificar(
            20,
            'Conversión y Formato en Bolívares (Tasa BCV referencial y prefijo "Bs.")',
            esperado,
            formateadoBs,
            paso
        );
    })();

    // ------------------------------------------------------------
    // PRUEBA 21: Duplicar Cotización: Bloqueo estricto si el usuario tiene una cotización abierta
    // ------------------------------------------------------------
    (function () {
        var cotizacionesEjemplo = [
            { id: 701, usuarioId: 77, estado: 'BORRADOR', correlativo: 'COT-0701' },
            { id: 702, usuarioId: 78, estado: 'APROBADA', correlativo: 'COT-0702' }
        ];

        var usuarioConBorrador = verificarDisponibilidadNuevaCotizacion(77, cotizacionesEjemplo);
        var usuarioSinBorrador = verificarDisponibilidadNuevaCotizacion(78, cotizacionesEjemplo);

        var paso = (usuarioConBorrador.puede === false) && (usuarioSinBorrador.puede === true);

        verificar(
            21,
            'Duplicar Cotización: Impedir duplicación si ya existe una abierta (BORRADOR/ENVIADA)',
            'Usuario 77 bloqueado (puede: false), Usuario 78 permitido (puede: true)',
            'Usuario 77 puede: ' + usuarioConBorrador.puede + ' | Usuario 78 puede: ' + usuarioSinBorrador.puede,
            paso
        );
    })();

    // ------------------------------------------------------------
    // PRUEBA 22: Modo Demostración: Vaciado completo del sistema y reinicio de cotizaciones
    // ------------------------------------------------------------
    (function () {
        // Guardar estado actual de localStorage temporalmente
        var cotizacionesPrevias = obtenerCotizaciones();

        // Ejecutar vaciado de prueba
        vaciarDatosSistema();
        var cotizacionesDespues = obtenerCotizaciones();
        var contadorDespues = localStorage.getItem(CLAVES_STORAGE.CONTADOR);

        var paso = (cotizacionesDespues.length === 0) && (contadorDespues === '0');

        // Restaurar datos de demostración para que el usuario no pierda su entorno
        if (cotizacionesPrevias && cotizacionesPrevias.length > 0) {
            guardarCotizaciones(cotizacionesPrevias);
        } else {
            cargarDatosDemostracionCompletos();
        }

        verificar(
            22,
            'Modo Demostración: vaciarDatosSistema() reinicia contador a 0 y limpia cotizaciones',
            'Cotizaciones: 0, Contador: "0"',
            'Cotizaciones: ' + cotizacionesDespues.length + ', Contador: "' + contadorDespues + '"',
            paso
        );
    })();

    // ------------------------------------------------------------
    // PRUEBA 23: formatearMoneda con NaN retorna "0,00"
    // ------------------------------------------------------------
    (function () {
        var res = formatearMoneda(NaN);
        verificar(23, 'formatearMoneda(NaN) retorna "0,00"', '0,00', res, res === '0,00');
    })();

    // ------------------------------------------------------------
    // PRUEBA 24: desglosarPasosCalculoPedagogico retorna Array con 7+ pasos
    // ------------------------------------------------------------
    (function () {
        var items = [{ materialId: 1, nombre: 'Test', unidad: 'U', sector: 'Construcción', precioBase: 100, cantidad: 1 }];
        var calc = calcularPresupuestoCotizacion(items, { nombre: 'Pto Ordaz', factor: 0.90 }, { perfil: 'Alcaldía', estado: 'Miranda' }, 36.50);
        calc.nombreObra = 'Test';
        calc.ciudadCompra = 'Pto Ordaz';
        var pasos = desglosarPasosCalculoPedagogico(calc);
        var ok = Array.isArray(pasos) && pasos.length >= 7 && pasos[0].paso && pasos[0].titulo && pasos[0].formula && pasos[0].detalle && pasos[0].resultado;
        verificar(24, 'desglosarPasosCalculoPedagogico retorna Array con 7+ pasos válidos', 'Array con 7+ pasos', 'length=' + pasos.length, ok);
    })();

    // ------------------------------------------------------------
    // PRUEBA 25: escaparHtml neutraliza <script> e <img>
    // ------------------------------------------------------------
    (function () {
        var escapado = escaparHtml('<img src=x onerror=alert(1)>');
        var ok = escapado.indexOf('<') === -1 && escapado.indexOf('&lt;') !== -1;
        verificar(25, 'escaparHtml neutraliza <script> e <img>', 'Sin < > literales', escapado.substring(0, 20) + '...', ok);
    })();

    // ------------------------------------------------------------
    // PRUEBA 26: validarRespaldoJSON rechaza usuarios sin estructura
    // ------------------------------------------------------------
    (function () {
        var res = validarRespaldoJSON('{"usuarios":[{}],"materiales":[{}],"cotizaciones":[]}');
        verificar(26, 'validarRespaldoJSON rechaza usuarios sin estructura', 'valido: false', 'valido: ' + res.valido, res.valido === false);
    })();

    // ------------------------------------------------------------
    // PRUEBA 27: formatearMoneda(-1234.56, USD) = "-$1.234,56"
    // ------------------------------------------------------------
    (function () {
        var res = formatearMoneda(-1234.56, 'USD');
        verificar(27, 'formatearMoneda(-1234.56, USD) = "-$1.234,56"', '-$1.234,56', res, res === '-$1.234,56');
    })();

    // ------------------------------------------------------------
    // PRUEBA 28: Todos los [data-icono] del DOM existen en ICONOS_SVG
    // ------------------------------------------------------------
    (function () {
        var iconosDOM = document.querySelectorAll('[data-icono]');
        var faltantes = [];
        for (var i = 0; i < iconosDOM.length; i++) {
            var nombre = iconosDOM[i].getAttribute('data-icono');
            if (nombre && !ICONOS_SVG[nombre]) faltantes.push(nombre);
        }
        verificar(28, 'Todos los [data-icono] del DOM existen en ICONOS_SVG', '0 faltantes', faltantes.length + ' faltantes: ' + faltantes.join(', '), faltantes.length === 0);
    })();

    // ------------------------------------------------------------
    // PRUEBA 29: Borradores por usuario son independientes
    // ------------------------------------------------------------
    (function () {
        var uidA = 99901, uidB = 99902;
        guardarBorradorAsistente(uidA, { nombreObra: 'Obra A', pasoActual: 2 });
        guardarBorradorAsistente(uidB, { nombreObra: 'Obra B', pasoActual: 3 });
        var borA = obtenerBorradorAsistente(uidA);
        var borB = obtenerBorradorAsistente(uidB);
        var borC = obtenerBorradorAsistente(99999);
        var ok = borA && borA.nombreObra === 'Obra A' && borB && borB.nombreObra === 'Obra B' && borC === null;
        limpiarBorradorAsistente(uidA);
        limpiarBorradorAsistente(uidB);
        verificar(29, 'Borradores por usuario son independientes', 'A=Obra A, B=Obra B, C=null', 'A=' + (borA ? borA.nombreObra : 'null') + ', B=' + (borB ? borB.nombreObra : 'null') + ', C=' + borC, ok);
    })();

    // ------------------------------------------------------------
    // PRUEBA 30: detectarAlertasSistema marca cotización con 7 días como DEMORADA
    // ------------------------------------------------------------
    (function () {
        var hoy = new Date();
        var hace7dias = new Date(hoy.getTime() - 7 * 24 * 60 * 60 * 1000);
        var fechaVieja = String(hace7dias.getDate()).padStart(2, '0') + '/' + String(hace7dias.getMonth() + 1).padStart(2, '0') + '/' + hace7dias.getFullYear() + ' 10:00';
        var cotVieja = { id: 1, usuarioId: 1, estado: 'ENVIADA', correlativo: 'COT-9999', nombreCliente: 'Test', fechaCreacion: fechaVieja, total: 100 };
        var alertas = detectarAlertasSistema([], [cotVieja]);
        var tieneAlerta = false;
        for (var i = 0; i < alertas.length; i++) {
            if (alertas[i].tipo === 'COTIZACION_DEMORADA') tieneAlerta = true;
        }
        verificar(30, 'detectarAlertasSistema marca cotización con 7 días como DEMORADA', 'Alerta COTIZACION_DEMORADA presente', tieneAlerta ? 'Presente' : 'Ausente', tieneAlerta);
    })();

    return resultados;
}

/**
 * Renderiza la tabla de resultados en el documento HTML de pruebas.
 */
function renderizarResultadosPruebas() {
    var contenedor = document.getElementById('cuerpoResultadosPruebas');
    var badgeTotal = document.getElementById('badgeTotalPruebas');
    var badgeAprobadas = document.getElementById('badgeAprobadas');
    var badgeFallidas = document.getElementById('badgeFallidas');

    if (!contenedor) return;

    var resultados = ejecutarSuitePruebas();
    contenedor.innerHTML = '';

    var totalAprobadas = 0;

    for (var i = 0; i < resultados.length; i++) {
        var r = resultados[i];
        if (r.paso) totalAprobadas++;

        var fila = document.createElement('tr');
        fila.className = r.paso ? 'fila-prueba-aprobada' : 'fila-prueba-fallida';

        fila.innerHTML =
            '<td><strong>#' + r.numero + '</strong></td>' +
            '<td>' + r.caso + '</td>' +
            '<td><code>' + r.esperado + '</code></td>' +
            '<td><code>' + r.obtenido + '</code></td>' +
            '<td><span class="badge-resultado ' + (r.paso ? 'badge-exito' : 'badge-peligro') + '" style="display:inline-flex; align-items:center; gap:0.35rem;">' +
            (typeof icono === 'function' ? (r.paso ? icono('check', 12) : icono('cerrar', 12)) : '') +
            '<span>' + (r.paso ? 'APROBADA' : 'FALLÓ') + '</span></span></td>';

        contenedor.appendChild(fila);
    }

    if (badgeTotal) badgeTotal.textContent = resultados.length;
    if (badgeAprobadas) badgeAprobadas.textContent = totalAprobadas;
    if (badgeFallidas) badgeFallidas.textContent = (resultados.length - totalAprobadas);

    console.log("TESTS_SUMMARY: Total=" + resultados.length + ", Aprobadas=" + totalAprobadas + ", Fallidas=" + (resultados.length - totalAprobadas));
}

document.addEventListener('DOMContentLoaded', renderizarResultadosPruebas);

