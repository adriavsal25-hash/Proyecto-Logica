/* ============================================================
   SICOP-VE — Capa de Interfaz de Usuario y Eventos (js/interfaz.js)
   Proyecto Final: Lógica y Programación I
   
   Responsabilidad:
   - Manipulación del DOM, eventos de click, change e input reactivo.
   - Orquestación del Asistente de Cotización de 4 pasos con cálculo en vivo.
   - Aplicación de plantillas de obra, duplicación de cotizaciones y recuperación de borradores.
   - Notificaciones emergentes (toasts), modales accesibles y formato monetario venezolano.
   - Enlace limpio entre datos.js, logica.js y el DOM sin romper ninguna regla de negocio.
   ============================================================ */

// ============================================================
// 1. ESTADO GLOBAL EN MEMORIA DE LA INTERFAZ
// ============================================================
var sesionUsuario = null;                // Usuario autenticado actualmente
var cotizacionEnEdicion = null;          // Objeto de cotización calculado o en revisión
var materialEnEdicionId = null;          // ID de material al editar en catálogo (Gobernación)
var pasoCotizadorActual = 1;             // Paso actual del asistente (1: Obra, 2: Materiales, 3: Revisión, 4: Envío)
var estimacionActualCalculadora = null;  // Último cálculo de la calculadora de obra
var accionConfirmacionModal = null;      // Callback a ejecutar al confirmar en el modal propio
var documentoActual = null;              // Cotización activa en vista de documento oficial
var _timerBorrador = null;               // Temporizador para guardado con debounce de borrador
var _cotizacionIdRechazo = null;         // ID de cotización pendiente de rechazo formal

/**
 * Programa el guardado del borrador con debounce de 800ms para evitar escrituras excesivas.
 */
function programarGuardadoBorrador() {
    if (_timerBorrador) clearTimeout(_timerBorrador);
    _timerBorrador = setTimeout(function () {
        guardarBorradorActualEnStorage();
    }, 800);
}

/**
 * Enfoca el primer elemento interactivo dentro de un modal para cumplir WCAG 2.1.
 */
function enfocarPrimerElementoModal(modal) {
    if (!modal) return;
    setTimeout(function () {
        var primero = modal.querySelector('input:not([type="hidden"]), select, textarea, button');
        if (primero) primero.focus();
    }, 60);
}

/**
 * Cierra todos los modales abiertos en la plataforma.
 */
function cerrarTodosLosModales() {
    var modales = document.querySelectorAll('.modal-fondo:not(.oculto)');
    for (var i = 0; i < modales.length; i++) {
        modales[i].classList.add('oculto');
    }
    ocultarVistaImprimible();
    _cotizacionIdRechazo = null;
    accionConfirmacionModal = null;
}

// ============================================================
// 2. SISTEMA DE NOTIFICACIONES TOASTS Y MODALES PROPIOS
// ============================================================

/**
 * Muestra una notificación emergente (Toast) flotante sin bloquear la ejecución.
 * @param {string} mensaje - Texto descriptivo para el usuario.
 * @param {string} tipo - 'exito', 'error', 'advertencia' o 'info'.
 * @param {number} [duracionMs=3500] - Tiempo de visualización en milisegundos.
 */
function mostrarNotificacion(mensaje, tipo, duracionMs) {
    var contenedor = document.getElementById('contenedorToasts');
    if (!contenedor) return;

    var duracion = duracionMs || 3500;
    var tipoClase = tipo || 'info';

    var iconoHtml = '';
    if (typeof icono === 'function') {
        if (tipoClase === 'exito') iconoHtml = icono('check', 16);
        else if (tipoClase === 'error') iconoHtml = icono('cerrar', 16);
        else if (tipoClase === 'advertencia') iconoHtml = icono('alerta', 16);
        else iconoHtml = icono('info', 16);
    }

    var toast = document.createElement('div');
    toast.className = 'toast toast--' + tipoClase;
    toast.innerHTML = '<span class="toast__icono">' + iconoHtml + '</span>' +
                      '<span class="toast__mensaje">' + mensaje + '</span>';

    contenedor.appendChild(toast);

    setTimeout(function () {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(10px)';
        setTimeout(function () {
            if (toast.parentNode) {
                toast.parentNode.removeChild(toast);
            }
        }, 300);
    }, duracion);
}

/**
 * Muestra el diálogo modal de confirmación propio de la aplicación (sustituye a window.confirm).
 * @param {string} titulo - Título del diálogo.
 * @param {string} mensaje - Pregunta o advertencia detallada.
 * @param {Function} onConfirmar - Función a ejecutar si el usuario pulsa "Confirmar".
 * @param {string} [textoConfirmar='Confirmar'] - Etiqueta del botón afirmativo.
 * @param {string} [textoCancelar='Cancelar'] - Etiqueta del botón de cancelación.
 */
function mostrarModalConfirmacion(titulo, mensaje, onConfirmar, textoConfirmar, textoCancelar, permitirHtml) {
    var modal = document.getElementById('modalConfirmacion');
    var titElem = document.getElementById('modalConfirmacionTitulo');
    var msgElem = document.getElementById('modalConfirmacionMensaje');
    var btnOk = document.getElementById('btnAceptarModalConfirmacion');
    var btnCancel = document.getElementById('btnCancelarModalConfirmacion');

    if (!modal) return;

    if (titElem) titElem.textContent = titulo || 'Confirmación Requerida';
    if (msgElem) {
        if (permitirHtml) {
            msgElem.innerHTML = mensaje;
        } else {
            var texto = mensaje || '¿Está seguro de continuar?';
            msgElem.innerHTML = escaparHtml(texto).replace(/\n/g, '<br>');
        }
    }
    if (btnOk) btnOk.textContent = textoConfirmar || 'Confirmar';
    if (btnCancel) btnCancel.textContent = textoCancelar || 'Cancelar';

    accionConfirmacionModal = onConfirmar;
    modal.classList.remove('oculto');
    enfocarPrimerElementoModal(modal);
}

/**
 * Cierra el modal de confirmación y limpia la acción pendiente.
 */
function cerrarModalConfirmacion() {
    var modal = document.getElementById('modalConfirmacion');
    if (modal) modal.classList.add('oculto');
    accionConfirmacionModal = null;
}

// ============================================================
// 3. GESTIÓN DE ERRORES CLAROS Y ACCIONABLES EN CAMPOS
// ============================================================

/**
 * Resalta un campo en rojo y coloca un mensaje pedagógico debajo explicando qué hacer.
 * @param {string} idCampo - ID del elemento input o select en el DOM.
 * @param {string} mensaje - Instrucción clara y sugerencia de solución.
 */
function mostrarErrorCampo(idCampo, mensaje) {
    var campo = document.getElementById(idCampo);
    if (!campo) return;

    campo.classList.add('input-error');

    // Buscar si ya tiene un contenedor de mensaje de error asignado
    var idError = 'error_' + idCampo;
    var elemError = document.getElementById(idError);

    if (!elemError) {
        elemError = document.createElement('div');
        elemError.id = idError;
        elemError.className = 'mensaje-error-campo';
        // Insertar después del campo o de su contenedor padre inmediato si es tabla
        if (campo.parentNode) {
            campo.parentNode.appendChild(elemError);
        }
    }

    elemError.textContent = mensaje;
    elemError.classList.remove('oculto');
    elemError.style.display = 'block';
}

/**
 * Limpia el estado de error de un campo específico.
 * @param {string} idCampo - ID del elemento input.
 */
function limpiarErrorCampo(idCampo) {
    var campo = document.getElementById(idCampo);
    if (campo) {
        campo.classList.remove('input-error');
    }
    var idError = 'error_' + idCampo;
    var elemError = document.getElementById(idError);
    if (elemError) {
        elemError.classList.add('oculto');
        elemError.style.display = 'none';
        elemError.textContent = '';
    }
}

/**
 * Limpia todos los errores visuales dentro de un contenedor o de toda la pantalla.
 * @param {HTMLElement|string} [contenedor] - Elemento o ID del contenedor.
 */
function limpiarErrores(contenedor) {
    var raiz = typeof contenedor === 'string' ? document.getElementById(contenedor) : (contenedor || document);
    if (!raiz) return;

    var inputsError = raiz.querySelectorAll('.input-error');
    for (var i = 0; i < inputsError.length; i++) {
        inputsError[i].classList.remove('input-error');
    }

    var msgsError = raiz.querySelectorAll('.mensaje-error-campo');
    for (var j = 0; j < msgsError.length; j++) {
        msgsError[j].classList.add('oculto');
        msgsError[j].style.display = 'none';
        msgsError[j].textContent = '';
    }
}

// ============================================================
// 4. GESTIÓN DE MONEDA GLOBAL (USD / Bs) Y TEMA CLARO / OSCURO
// ============================================================

/**
 * Inicializa el tema visual (claro u oscuro) respetando la preferencia guardada o del sistema.
 */
function inicializarTema() {
    var temaGuardado = localStorage.getItem('sicop_tema');
    var temaPref = temaGuardado;
    if (!temaPref) {
        temaPref = (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) ? 'oscuro' : 'claro';
    }
    aplicarTema(temaPref);
}

/**
 * Aplica el tema visual en el elemento raíz y actualiza el icono del botón.
 * @param {string} tema - 'claro' u 'oscuro'.
 */
function aplicarTema(tema) {
    document.documentElement.setAttribute('data-tema', tema);
    var spanIcono = document.getElementById('iconoTemaActual');
    if (spanIcono && typeof icono === 'function') {
        var nomIcono = (tema === 'oscuro') ? 'sol' : 'luna';
        spanIcono.setAttribute('data-icono', nomIcono);
        spanIcono.innerHTML = icono(nomIcono, 17);
    }
    var logoSide = document.getElementById('logoSidebar');
    if (logoSide) {
        logoSide.src = (tema === 'oscuro') ? 'img/logo-blanco.png' : 'img/logo-negro.png';
    }
}

/**
 * Alterna manualmente entre modo claro y oscuro.
 */
function alternarTema() {
    var temaActual = document.documentElement.getAttribute('data-tema') || 'claro';
    var nuevoTema = (temaActual === 'oscuro') ? 'claro' : 'oscuro';
    localStorage.setItem('sicop_tema', nuevoTema);
    aplicarTema(nuevoTema);
    mostrarNotificacion('Tema cambiado a modo ' + nuevoTema, 'info', 2000);
}

/**
 * Cambia la moneda activa en el sistema y refresca la visualización de datos.
 * @param {string} nuevaMoneda - 'USD' o 'Bs'.
 */
function cambiarMonedaGlobal(nuevaMoneda) {
    document.body.style.cursor = 'progress';
    guardarMonedaActiva(nuevaMoneda);
    actualizarCabeceraUsuario();
    actualizarTotalEnVivo();
    sincronizarSelectorMonedaUI();
    var pestanaActiva = document.querySelector('.nav-btn.activa');
    if (pestanaActiva) {
        var modulo = pestanaActiva.getAttribute('data-modulo');
        if (modulo === 'dashboard') renderizarDashboard();
        if (modulo === 'historial') renderizarModuloHistorial();
        if (modulo === 'supervision') renderizarModuloSupervision();
    }
    document.body.style.cursor = '';
    mostrarNotificacion('Moneda: ' + (nuevaMoneda === 'Bs' ? 'Bolívares (Bs.)' : 'Dólares (USD)'), 'info', 1800);
}

/**
 * Sincroniza el selector de moneda del encabezado con el valor almacenado y la tasa BCV.
 */
function sincronizarSelectorMonedaUI() {
    var selectMoneda = document.getElementById('selectorMonedaGlobal');
    if (!selectMoneda) return;
    selectMoneda.value = obtenerMonedaActiva();
    var tasa = obtenerTasaBCV();
    var optUsd = selectMoneda.querySelector('option[value="USD"]');
    var optBs = selectMoneda.querySelector('option[value="Bs"]');
    if (optUsd) optUsd.textContent = 'USD ($)';
    if (optBs) optBs.textContent = 'Bs. (BCV · ' + formatearMoneda(tasa) + ')';
}

// ============================================================
// 5. INICIALIZACIÓN Y GESTIÓN DE SESIÓN
// ============================================================

/**
 * Arranca la interfaz al cargar el DOM.
 */
function inicializarInterfaz() {
    inicializarTema();
    sesionUsuario = obtenerSesionActual();
    sincronizarSelectorMonedaUI();
    conectarEventosGenerales();

    // Actualizar año dinámico en el pie de página
    var elAnio = document.getElementById('anioFooter');
    if (elAnio) {
        elAnio.textContent = new Date().getFullYear();
    }

    if (sesionUsuario) {
        mostrarAplicacion();
    } else {
        mostrarPantallaLogin();
    }

    if (typeof hidratarIconos === 'function') {
        hidratarIconos();
    }
}

/**
 * Muestra la vista de autenticación.
 */
function mostrarPantallaLogin() {
    var contLogin = document.getElementById('pantallaLogin');
    var contApp = document.getElementById('aplicacionPrincipal');
    if (contLogin) contLogin.classList.remove('oculto');
    if (contApp) contApp.classList.add('oculto');

    poblarSelectorUsuariosLogin();
    if (typeof hidratarIconos === 'function') {
        hidratarIconos();
    }
}

/**
 * Llena el selector rápido de usuarios en la pantalla de login para facilitar la exposición.
 */
function poblarSelectorUsuariosLogin() {
    var select = document.getElementById('selectorUsuarioRapido');
    if (!select) return;

    var usuarios = obtenerUsuarios();
    select.innerHTML = '<option value="">-- Seleccionar usuario de demostración --</option>';

    for (var i = 0; i < usuarios.length; i++) {
        var u = usuarios[i];
        var opt = document.createElement('option');
        opt.value = u.usuario;
        opt.textContent = u.nombre + ' (' + u.perfil + ' - ' + u.estado + ')';
        select.appendChild(opt);
    }
}

/**
 * Rellena automáticamente las credenciales al seleccionar un usuario demo.
 * @param {string} nombreUsuario - Identificador del usuario (ej: 'alcaldia_libertador').
 */
function seleccionarUsuarioDemo(nombreUsuario) {
    var select = document.getElementById('selectorUsuarioRapido');
    if (select) {
        select.value = nombreUsuario;
    }
    var usuarios = obtenerUsuarios();
    for (var i = 0; i < usuarios.length; i++) {
        if (usuarios[i].usuario === nombreUsuario) {
            var inputU = document.getElementById('inputUsuarioLogin');
            var inputC = document.getElementById('inputClaveLogin');
            if (inputU) inputU.value = usuarios[i].usuario;
            if (inputC) inputC.value = usuarios[i].clave;
            mostrarNotificacion('Usuario seleccionado: ' + usuarios[i].nombre, 'info', 1800);
            break;
        }
    }
}

/**
 * Muestra la aplicación principal luego de iniciar sesión.
 */
function mostrarAplicacion() {
    var contLogin = document.getElementById('pantallaLogin');
    var contApp = document.getElementById('aplicacionPrincipal');
    if (contLogin) contLogin.classList.add('oculto');
    if (contApp) contApp.classList.remove('oculto');

    actualizarCabeceraUsuario();
    ajustarVisibilidadMenuPorRol();

    // Módulo inicial: Dashboard
    cambiarPestana('dashboard');

    if (typeof hidratarIconos === 'function') {
        hidratarIconos();
    }
}

/**
 * Actualiza la información del usuario en la barra superior.
 */
function actualizarCabeceraUsuario() {
    if (!sesionUsuario) return;

    // Recargar datos frescos del usuario desde storage
    var usuarios = obtenerUsuarios();
    for (var i = 0; i < usuarios.length; i++) {
        if (usuarios[i].id === sesionUsuario.id) {
            sesionUsuario = usuarios[i];
            guardarSesionActual(sesionUsuario);
            break;
        }
    }

    var estPto = calcularEstadoPresupuestoUsuario(sesionUsuario);
    var moneda = obtenerMonedaActiva();
    var tasa = obtenerTasaBCV();

    var nombreElem = document.getElementById('usuarioNombreHeader');
    var rolElem = document.getElementById('usuarioRolHeader');
    var semaforoElem = document.getElementById('usuarioSemaforoHeader');
    var avatarElem = document.getElementById('avatarInicialesHeader');

    if (nombreElem) nombreElem.textContent = sesionUsuario.nombre;
    if (rolElem) rolElem.textContent = sesionUsuario.perfil + ' | ' + sesionUsuario.estado;

    // Generar iniciales limpias para el avatar (ej: María González -> MG, Ing. Ana Pérez -> AP)
    if (avatarElem) {
        var limpio = sesionUsuario.nombre.replace(/^(Ing\.|Lic\.|Dr\.|Dra\.|Arq\.)\s*/i, '').trim();
        var partes = limpio.split(/\s+/);
        var iniciales = 'US';
        if (partes.length >= 2) {
            iniciales = (partes[0][0] + partes[1][0]).toUpperCase();
        } else if (partes.length === 1 && partes[0].length > 0) {
            iniciales = partes[0].substring(0, 2).toUpperCase();
        }
        avatarElem.textContent = iniciales;
    }

    if (semaforoElem) {
        semaforoElem.className = 'badge-semaforo badge-semaforo--' + estPto.colorSemaforo;
        var textoDisp = formatearMoneda(estPto.saldoDisponible, moneda, tasa);
        semaforoElem.textContent = estPto.textoSemaforo + ' (Disp: ' + textoDisp + ')';
    }

    sincronizarSelectorMonedaUI();
}

/**
 * Muestra u oculta módulos en la barra de navegación según el rol del usuario conectado.
 */
function ajustarVisibilidadMenuPorRol() {
    if (!sesionUsuario) return;
    var esGobernacion = (sesionUsuario.perfil === 'Gobernación');

    var itemsGobernacion = document.querySelectorAll('.solo-gobernacion');
    for (var i = 0; i < itemsGobernacion.length; i++) {
        if (esGobernacion) {
            itemsGobernacion[i].classList.remove('oculto');
        } else {
            itemsGobernacion[i].classList.add('oculto');
        }
    }
}

// ============================================================
// 6. NAVEGACIÓN POR PESTAÑAS / MÓDULOS
// ============================================================

/**
 * Diccionario de títulos formales para la barra superior SaaS.
 */
var TITULOS_MODULOS_SAAS = {
    dashboard: 'Dashboard',
    calculadora: 'Calculadora de Materiales',
    cotizador: 'Asistente de Cotización',
    ciudades: 'Dónde Conviene Comprar',
    historial: 'Historial de Cotizaciones',
    catalogo: 'Catálogo Maestro de Precios',
    aprobaciones: 'Aprobaciones y Control de Fondos',
    supervision: 'Supervisión Global de Inversión',
    bitacora: 'Bitácora de Auditoría y Alertas',
    respaldo: 'Exportar / Importar y Demostración'
};

/**
 * Cambia la pestaña activa y ejecuta el renderizado correspondiente.
 * @param {string} moduloId - Nombre clave del módulo.
 */
function cambiarPestana(moduloId) {
    ocultarVistaImprimible();

    // Actualizar título de la sección en la barra superior
    var titElem = document.getElementById('topbarTituloModulo');
    if (titElem) {
        titElem.textContent = TITULOS_MODULOS_SAAS[moduloId] || 'Plataforma SICOP-VE';
    }

    // Actualizar navegación de la barra lateral
    var botonesNav = document.querySelectorAll('.nav-btn');
    for (var i = 0; i < botonesNav.length; i++) {
        botonesNav[i].classList.remove('activa');
        if (botonesNav[i].getAttribute('data-modulo') === moduloId) {
            botonesNav[i].classList.add('activa');
        }
    }

    // Actualizar barra inferior móvil
    var bottomItems = document.querySelectorAll('.bottom-nav__item');
    for (var b = 0; b < bottomItems.length; b++) {
        bottomItems[b].classList.remove('activa');
        if (bottomItems[b].getAttribute('data-bottom-modulo') === moduloId) {
            bottomItems[b].classList.add('activa');
        }
    }

    // Cerrar cajón móvil si estaba abierto
    var sidebar = document.getElementById('sidebarApp');
    var overlay = document.getElementById('sidebarOverlay');
    if (sidebar && sidebar.classList.contains('abierta')) {
        sidebar.classList.remove('abierta');
    }
    if (overlay && overlay.classList.contains('activa')) {
        overlay.classList.remove('activa');
    }

    var secciones = document.querySelectorAll('.seccion-modulo');
    for (var j = 0; j < secciones.length; j++) {
        secciones[j].classList.remove('activa');
    }

    var seccionDestino = document.getElementById('modulo-' + moduloId);
    if (seccionDestino) {
        seccionDestino.classList.add('activa');
    }

    switch (moduloId) {
        case 'dashboard':
            renderizarDashboard();
            break;
        case 'calculadora':
            inicializarModuloCalculadora();
            break;
        case 'cotizador':
            renderizarModuloCotizador();
            break;
        case 'ciudades':
            renderizarModuloCiudades();
            break;
        case 'catalogo':
            renderizarModuloCatalogo();
            break;
        case 'aprobaciones':
            renderizarModuloAprobaciones();
            break;
        case 'historial':
            renderizarModuloHistorial();
            break;
        case 'supervision':
            renderizarModuloSupervision();
            break;
        case 'bitacora':
            renderizarModuloBitacora();
            break;
    }

    if (typeof hidratarIconos === 'function') {
        hidratarIconos();
    }
}

// ============================================================
// 7. MÓDULO: CALCULADORA DE MATERIALES POR UNIDAD DE OBRA
// ============================================================

function inicializarModuloCalculadora() {
    var selectTipo = document.getElementById('calcTipoObra');
    if (selectTipo) {
        cambiarCamposCalculadora(selectTipo.value);
    }
}

function cambiarCamposCalculadora(tipo) {
    var camposPared = document.getElementById('camposCalcPared');
    var camposLosa = document.getElementById('camposCalcLosa');
    var camposTuberia = document.getElementById('camposCalcTuberia');
    var contenedorRes = document.getElementById('resultadoCalculadora');

    if (camposPared) camposPared.classList.add('oculto');
    if (camposLosa) camposLosa.classList.add('oculto');
    if (camposTuberia) camposTuberia.classList.add('oculto');
    if (contenedorRes) contenedorRes.classList.add('oculto');

    if (tipo === 'pared' && camposPared) camposPared.classList.remove('oculto');
    if (tipo === 'losa' && camposLosa) camposLosa.classList.remove('oculto');
    if (tipo === 'tuberia' && camposTuberia) camposTuberia.classList.remove('oculto');
}

function ejecutarCalculoObra() {
    var tipo = document.getElementById('calcTipoObra').value;
    var desperdicio = parseFloat(document.getElementById('calcDesperdicio').value) || 10;
    var resultado = null;

    if (tipo === 'pared') {
        var largo = parseFloat(document.getElementById('calcParedLargo').value);
        var alto = parseFloat(document.getElementById('calcParedAlto').value);
        resultado = calcularMaterialesPared(largo, alto, desperdicio);
    } else if (tipo === 'losa') {
        var largoL = parseFloat(document.getElementById('calcLosaLargo').value);
        var anchoL = parseFloat(document.getElementById('calcLosaAncho').value);
        var espesorL = parseFloat(document.getElementById('calcLosaEspesor').value);
        var cabillasM2 = parseFloat(document.getElementById('calcLosaCabillasM2').value);
        resultado = calcularMaterialesLosa(largoL, anchoL, espesorL, cabillasM2, desperdicio);
    } else if (tipo === 'tuberia') {
        var metros = parseFloat(document.getElementById('calcTuberiaMetros').value);
        resultado = calcularMaterialesTuberia(metros, desperdicio);
    }

    if (!resultado || !resultado.valido) {
        mostrarNotificacion(resultado ? resultado.error : 'Por favor verifique las medidas ingresadas.', 'error');
        return;
    }

    estimacionActualCalculadora = resultado;
    renderizarResultadoCalculadora(resultado);
}

function renderizarResultadoCalculadora(est) {
    var contenedor = document.getElementById('resultadoCalculadora');
    var cuerpoTabla = document.getElementById('cuerpoResCalculadora');
    var tituloElem = document.getElementById('tituloResCalculadora');

    if (!contenedor || !cuerpoTabla) return;

    if (tituloElem) {
        tituloElem.textContent = 'Estimación de ' + est.tipo + ' (Desperdicio: ' + est.desperdicioPct + '%)';
    }

    cuerpoTabla.innerHTML = '';
    for (var i = 0; i < est.resultados.length; i++) {
        var item = est.resultados[i];
        var tr = document.createElement('tr');
        tr.innerHTML =
            '<td><strong>' + escaparHtml(item.nombreBusqueda) + '</strong></td>' +
            '<td>' + item.cantidad + '</td>' +
            '<td>' + escaparHtml(item.unidad) + '</td>' +
            '<td><span class="texto-secundario">' + escaparHtml(item.detalle) + '</span></td>';
        cuerpoTabla.appendChild(tr);
    }

    contenedor.classList.remove('oculto');
}

/**
 * Pasa las cantidades estimadas directamente al Asistente de Cotización (Paso 2).
 */
function transferirEstimacionACotizador() {
    if (!estimacionActualCalculadora) return;

    cambiarPestana('cotizador');
    irAPasoCotizador(2);

    var materiales = obtenerMateriales();
    for (var i = 0; i < estimacionActualCalculadora.resultados.length; i++) {
        var est = estimacionActualCalculadora.resultados[i];
        for (var j = 0; j < materiales.length; j++) {
            var m = materiales[j];
            if (m.nombre.toLowerCase().indexOf(est.nombreBusqueda.toLowerCase()) !== -1) {
                var input = document.getElementById('cant_mat_' + m.id);
                if (input && !input.disabled) {
                    var cantExistente = parseInt(input.value) || 0;
                    input.value = cantExistente + est.cantidad;
                }
            }
        }
    }

    actualizarTotalEnVivo();
    mostrarNotificacion('Cantidades agregadas al Asistente de Cotización con éxito.', 'exito');
}

// ============================================================
// 8. MÓDULO: ASISTENTE DE COTIZACIÓN POR PASOS (WIZARD)
// ============================================================

/**
 * Renderiza el módulo de cotización y evalúa bloqueos o borradores guardados.
 */
function renderizarModuloCotizador() {
    actualizarCabeceraUsuario();

    var cotizaciones = obtenerCotizaciones();
    var disp = verificarDisponibilidadNuevaCotizacion(sesionUsuario.id, cotizaciones);

    var avisoBloqueo = document.getElementById('avisoCotizacionBloqueada');
    var navPasos = document.querySelector('.asistente-pasos-nav');
    var layout = document.querySelector('.cotizador-layout');

    // 1. Manejo del bloqueo por cotización abierta
    if (!disp.puede) {
        if (avisoBloqueo) {
            var cotBloq = disp.cotizacionBloqueante;
            avisoBloqueo.innerHTML =
                '<div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:1rem;">' +
                '  <div>' +
                '    <div style="display:flex; align-items:center; gap:0.5rem; font-weight:700; font-size:1rem; color:var(--color-peligro);">' +
                '      ' + icono('alerta', 18) + ' Cotización Abierta en Curso Requerida' +
                '    </div>' +
                '    <p style="margin:0.35rem 0 0 0; line-height:1.4;">Posee la cotización <strong>' + cotBloq.correlativo +
                '    </strong> en estado <strong>' + cotBloq.estado +
                '    </strong> por <strong>$' + formatearMoneda(cotBloq.total) + ' USD</strong>.<br>' +
                '    La normativa del sistema requiere culminar, autorizar o anular el trámite activo antes de aperturar un nuevo proyecto.</p>' +
                '  </div>' +
                '  <div style="display:flex; gap:0.5rem; align-items:center; flex-wrap:wrap;">' +
                '    <button type="button" class="boton boton--primario boton--sm" id="btnIrACotBloqueante">' + icono('ojo', 14) + ' Ver cotización activa</button>' +
                '    <button type="button" class="boton boton--peligro boton--sm" id="btnDescartarCotBloqueante">' + icono('eliminar', 14) + ' Descartar e iniciar nueva</button>' +
                '  </div>' +
                '</div>';
            avisoBloqueo.classList.remove('oculto');

            // Conectar botones de solución del bloqueo
            var btnIr = document.getElementById('btnIrACotBloqueante');
            if (btnIr) {
                btnIr.onclick = function () {
                    verDocumentoCotizacion(cotBloq.id);
                };
            }
            var btnDesc = document.getElementById('btnDescartarCotBloqueante');
            if (btnDesc) {
                btnDesc.onclick = function () {
                    mostrarModalConfirmacion(
                        'Descartar Cotización Abierta',
                        '¿Está seguro de descartar la cotización ' + cotBloq.correlativo + '? Se cancelará formalmente para que pueda iniciar una nueva.',
                        function () {
                            cancelarCotizacionDirecta(cotBloq.id);
                        },
                        'Sí, descartar',
                        'Volver'
                    );
                };
            }
        }

        if (layout) layout.style.opacity = '0.45';
        if (navPasos) navPasos.style.pointerEvents = 'none';
        bloquearControlesCotizador(true);
        return;
    }

    // Si está habilitado, desbloquear y continuar
    if (avisoBloqueo) avisoBloqueo.classList.add('oculto');
    if (layout) layout.style.opacity = '1';
    if (navPasos) navPasos.style.pointerEvents = 'auto';
    bloquearControlesCotizador(false);

    // 2. Verificar si hay un borrador automático recuperable en storage
    verificarBorradorAsistenteGuardado();

    // 3. Renderizar catálogo en Paso 2 y controles
    renderizarCatalogoEnCotizador(true);
    poblarCiudadesCotizador();
    actualizarTasaEnCotizador();

    // 4. Renderizar el paso activo del asistente
    renderizarPasoCotizador(pasoCotizadorActual);

    // 5. Actualizar el panel de Total en Vivo
    actualizarTotalEnVivo();
}

/**
 * Bloquea o desbloquea los campos del formulario del cotizador.
 */
function bloquearControlesCotizador(bloquear) {
    var inputs = document.querySelectorAll('#modulo-cotizador input, #modulo-cotizador select, #modulo-cotizador button');
    for (var i = 0; i < inputs.length; i++) {
        // No bloquear los botones dentro del aviso de bloqueo
        if (inputs[i].closest('#avisoCotizacionBloqueada')) continue;
        inputs[i].disabled = bloquear;
    }
}

/**
 * Cancela directamente una cotización abierta para desbloquear al usuario.
 */
function cancelarCotizacionDirecta(id) {
    var cotizaciones = obtenerCotizaciones();
    for (var i = 0; i < cotizaciones.length; i++) {
        if (cotizaciones[i].id === id) {
            cotizaciones[i].estado = 'CANCELADA';
            registrarEnBitacora(sesionUsuario.nombre, 'COTIZACION_CANCELADA', 'Cancelación para iniciar nueva: ' + cotizaciones[i].correlativo);
            break;
        }
    }
    guardarCotizaciones(cotizaciones);
    limpiarBorradorAsistente(sesionUsuario.id);
    limpiarFormularioCotizador();
    pasoCotizadorActual = 1;
    mostrarNotificacion('Cotización anterior descartada. El asistente está disponible.', 'exito');
    renderizarModuloCotizador();
}

/**
 * Comprueba si existe un borrador guardado en localStorage y muestra el banner para restaurarlo.
 */
function verificarBorradorAsistenteGuardado() {
    var banner = document.getElementById('bannerBorradorGuardado');
    var spanNombre = document.getElementById('nombreBorradorRecuperado');
    if (!banner || !sesionUsuario) return;

    var borrador = obtenerBorradorAsistente(sesionUsuario.id);
    if (borrador && borrador.nombreObra && !cotizacionEnEdicion) {
        if (spanNombre) spanNombre.textContent = borrador.nombreObra;
        banner.classList.remove('oculto');
    } else {
        banner.classList.add('oculto');
    }
}

/**
 * Restaura los datos del borrador automático en el formulario del asistente.
 */
function continuarBorradorGuardado() {
    var borrador = obtenerBorradorAsistente(sesionUsuario.id);
    if (!borrador) return;

    var inputNombre = document.getElementById('inputNombreObra');
    var selectEstado = document.getElementById('selectEstadoObraCotizador');
    var inputNotas = document.getElementById('inputNotasObra');
    var selectCiudad = document.getElementById('selectCiudadCotizador');
    var inputTasa = document.getElementById('inputTasaBCVCotizador');

    if (inputNombre && borrador.nombreObra) inputNombre.value = borrador.nombreObra;
    if (selectEstado && borrador.estadoObra) selectEstado.value = borrador.estadoObra;
    if (inputNotas && borrador.notas) inputNotas.value = borrador.notas;
    if (selectCiudad && borrador.ciudadCompra) selectCiudad.value = borrador.ciudadCompra;
    if (inputTasa && borrador.tasaBCV) inputTasa.value = borrador.tasaBCV;

    if (borrador.cantidades) {
        for (var matId in borrador.cantidades) {
            var inp = document.getElementById('cant_mat_' + matId);
            if (inp) inp.value = borrador.cantidades[matId];
        }
    }

    var banner = document.getElementById('bannerBorradorGuardado');
    if (banner) banner.classList.add('oculto');

    pasoCotizadorActual = borrador.pasoActual || 2;
    renderizarPasoCotizador(pasoCotizadorActual);
    actualizarTotalEnVivo();
    mostrarNotificacion('Borrador restaurado con éxito.', 'exito');
}

/**
 * Descarta el borrador guardado y reinicia los campos.
 */
function descartarBorradorGuardado() {
    limpiarBorradorAsistente(sesionUsuario.id);
    var banner = document.getElementById('bannerBorradorGuardado');
    if (banner) banner.classList.add('oculto');
    limpiarFormularioCotizador();
    pasoCotizadorActual = 1;
    renderizarPasoCotizador(1);
    actualizarTotalEnVivo();
    mostrarNotificacion('Borrador descartado. Formulario reiniciado.', 'info');
}

/**
 * Guarda el progreso actual del asistente en localStorage.
 */
function guardarBorradorActualEnStorage() {
    if (!sesionUsuario) return;

    var nombreObra = document.getElementById('inputNombreObra') ? document.getElementById('inputNombreObra').value.trim() : '';
    var estadoObra = document.getElementById('selectEstadoObraCotizador') ? document.getElementById('selectEstadoObraCotizador').value : sesionUsuario.estado;
    var notas = document.getElementById('inputNotasObra') ? document.getElementById('inputNotasObra').value.trim() : '';
    var ciudadCompra = document.getElementById('selectCiudadCotizador') ? document.getElementById('selectCiudadCotizador').value : '';
    var tasaBCV = parseFloat(document.getElementById('inputTasaBCVCotizador') ? document.getElementById('inputTasaBCVCotizador').value : obtenerTasaBCV()) || obtenerTasaBCV();

    var mapaCant = {};
    var inputs = document.querySelectorAll('#cuerpoTablaCotizador input.input-cantidad');
    var hayCantidades = false;
    for (var i = 0; i < inputs.length; i++) {
        var idMat = inputs[i].id.replace('cant_mat_', '');
        var val = inputs[i].value;
        if (val !== '' && parseInt(val) > 0) {
            mapaCant[idMat] = val;
            hayCantidades = true;
        }
    }

    // Solo guardar si hay algún dato escrito
    if (nombreObra || hayCantidades) {
        var paqueteBorrador = {
            pasoActual: pasoCotizadorActual,
            nombreObra: nombreObra,
            estadoObra: estadoObra,
            notas: notas,
            ciudadCompra: ciudadCompra,
            tasaBCV: tasaBCV,
            cantidades: mapaCant,
            fechaGuardado: obtenerFechaActual()
        };
        guardarBorradorAsistente(sesionUsuario.id, paqueteBorrador);

        var indicator = document.getElementById('indicadorGuardadoBorrador');
        if (indicator) {
            indicator.textContent = '✓ Guardado';
            indicator.style.opacity = '1';
            setTimeout(function () { indicator.style.opacity = '0'; }, 2000);
        }
    }
}

/**
 * Renderiza la vista de un paso específico del asistente (1 a 4).
 * @param {number} paso - Número del paso a mostrar.
 */
function renderizarPasoCotizador(paso) {
    pasoCotizadorActual = paso;

    // Actualizar barra de progreso superior
    for (var i = 1; i <= 4; i++) {
        var navItem = document.getElementById('pasoNav' + i);
        var separador = document.getElementById('pasoSep' + i);
        var pantalla = document.getElementById('pasoCotizador' + i);

        if (navItem) {
            navItem.classList.remove('paso-item--activo', 'paso-item--completado');
            if (i === paso) {
                navItem.classList.add('paso-item--activo');
            } else if (i < paso) {
                navItem.classList.add('paso-item--completado');
            }
        }

        if (separador) {
            if (i < paso) {
                separador.classList.add('paso-separador--completado');
            } else {
                separador.classList.remove('paso-separador--completado');
            }
        }

        if (pantalla) {
            if (i === paso) {
                pantalla.classList.remove('oculto');
            } else {
                pantalla.classList.add('oculto');
            }
        }
    }

    // Botones de navegación inferior
    var btnAtras = document.getElementById('btnAtrasAsistente');
    var btnSiguiente = document.getElementById('btnSiguienteAsistente');

    if (btnAtras) {
        btnAtras.disabled = (paso === 1);
    }

    if (btnSiguiente) {
        if (paso === 4) {
            btnSiguiente.classList.add('oculto');
        } else {
            btnSiguiente.classList.remove('oculto');
            btnSiguiente.textContent = (paso === 3) ? 'Ir al Paso 4: Emitir ➡' : 'Siguiente ➡';
        }
    }

    // Acciones de renderizado específicas del paso
    if (paso === 3) {
        renderizarPaso3Revision();
    } else if (paso === 4) {
        renderizarPaso4Confirmacion();
    }
}

/**
 * Avanza al siguiente paso del asistente validando las reglas del paso actual.
 */
function avanzarPasoCotizador() {
    limpiarErrores('modulo-cotizador');

    if (pasoCotizadorActual === 1) {
        // Validar Paso 1: Nombre de la obra y estado
        var nombreObra = document.getElementById('inputNombreObra').value.trim();
        var estadoObra = document.getElementById('selectEstadoObraCotizador').value;
        var valPaso1 = validarPasoObra(nombreObra, estadoObra);

        if (!valPaso1.valido) {
            mostrarErrorCampo('inputNombreObra', valPaso1.error);
            mostrarNotificacion('Por favor complete el nombre de la obra antes de continuar.', 'advertencia');
            return;
        }

        guardarBorradorActualEnStorage();
        renderizarPasoCotizador(2);

    } else if (pasoCotizadorActual === 2) {
        // Validar Paso 2: Materiales y cantidades
        var materiales = obtenerMateriales();
        var mapaCant = {};
        for (var i = 0; i < materiales.length; i++) {
            var m = materiales[i];
            var input = document.getElementById('cant_mat_' + m.id);
            if (input) {
                mapaCant[m.id] = input.value;
            }
        }

        var valCant = validarCantidadesCotizacion(materiales, mapaCant);
        if (!valCant.valido) {
            if (valCant.materialId) {
                mostrarErrorCampo('cant_mat_' + valCant.materialId, valCant.error);
            } else {
                mostrarNotificacion(valCant.error, 'error');
            }
            return;
        }

        // Construir el cálculo oficial con la lógica matemática pura
        var nombreCiudad = document.getElementById('selectCiudadCotizador').value;
        var ciudadSel = null;
        for (var j = 0; j < CIUDADES_BASE.length; j++) {
            if (CIUDADES_BASE[j].nombre === nombreCiudad) {
                ciudadSel = CIUDADES_BASE[j];
                break;
            }
        }
        if (!ciudadSel) ciudadSel = obtenerCiudadMasBarata(CIUDADES_BASE);

        var tasa = parseFloat(document.getElementById('inputTasaBCVCotizador').value) || obtenerTasaBCV();
        guardarTasaBCV(tasa);

        // Crear objeto de usuario simulado con el estado de obra elegido en el paso 1
        var estadoDestino = document.getElementById('selectEstadoObraCotizador').value || sesionUsuario.estado;
        var usuarioCotizacion = {
            id: sesionUsuario.id,
            nombre: sesionUsuario.nombre,
            perfil: sesionUsuario.perfil,
            estado: estadoDestino,
            limiteGasto: sesionUsuario.limiteGasto,
            gastado: sesionUsuario.gastado,
            comprometido: sesionUsuario.comprometido
        };

        var calculo = calcularPresupuestoCotizacion(valCant.items, ciudadSel, usuarioCotizacion, tasa);

        cotizacionEnEdicion = {
            id: Date.now(),
            correlativo: '(por asignar)',
            usuarioId: sesionUsuario.id,
            nombreCliente: sesionUsuario.nombre,
            perfil: sesionUsuario.perfil,
            nombreObra: document.getElementById('inputNombreObra').value.trim(),
            estadoObra: estadoDestino,
            notas: document.getElementById('inputNotasObra').value.trim(),
            ciudadCompra: calculo.ciudadCompra,
            factorCiudad: calculo.factorCiudad,
            factorFlete: calculo.factorFlete,
            descuentoPct: calculo.descuentoPct,
            fechaCreacion: obtenerFechaActual(),
            validezDias: DIAS_VIGENCIA_COTIZACION,
            estado: 'BORRADOR',
            items: calculo.items,
            subtotal: calculo.subtotal,
            flete: calculo.flete,
            descuento: calculo.descuento,
            neto: calculo.neto,
            contingencia: calculo.contingencia,
            iva: calculo.iva,
            total: calculo.total,
            tasaBCV: calculo.tasaBCV,
            totalBs: calculo.totalBs,
            motivoRechazo: ''
        };

        guardarBorradorActualEnStorage();
        renderizarPasoCotizador(3);

    } else if (pasoCotizadorActual === 3) {
        guardarBorradorActualEnStorage();
        renderizarPasoCotizador(4);
    }
}

/**
 * Retrocede al paso anterior conservando todos los datos ingresados.
 */
function retrocederPasoCotizador() {
    if (pasoCotizadorActual > 1) {
        limpiarErrores('modulo-cotizador');
        renderizarPasoCotizador(pasoCotizadorActual - 1);
    }
}

/**
 * Salto directo a un paso haciendo clic en la barra superior.
 * @param {number} pasoDestino - Paso al que desea ir (1 a 4).
 */
function irAPasoCotizador(pasoDestino) {
    if (pasoDestino < pasoCotizadorActual) {
        // Hacia atrás siempre se permite
        renderizarPasoCotizador(pasoDestino);
    } else if (pasoDestino === pasoCotizadorActual + 1) {
        // Hacia adelante se valida
        avanzarPasoCotizador();
    }
}

/**
 * Renderiza el contenido del catálogo en la tabla del Paso 2.
 */
function renderizarCatalogoEnCotizador(habilitado) {
    var cuerpo = document.getElementById('cuerpoTablaCotizador');
    if (!cuerpo) return;

    var materiales = obtenerMateriales();
    cuerpo.innerHTML = '';

    for (var i = 0; i < materiales.length; i++) {
        var m = materiales[i];
        if (!m.activo) continue;

        var tr = document.createElement('tr');
        tr.innerHTML =
            '<td><strong>' + m.nombre + '</strong></td>' +
            '<td><span class="badge-sector badge-sector--' + m.sector.toLowerCase() + '">' + m.sector + '</span></td>' +
            '<td>' + m.unidad + '</td>' +
            '<td>$' + formatearMoneda(m.precioBase) + '</td>' +
            '<td>' +
            '  <input type="number" id="cant_mat_' + m.id + '" min="0" step="1" placeholder="0" class="control-formulario input-cantidad" ' +
            (!habilitado ? 'disabled' : '') + '>' +
            '</td>';
        cuerpo.appendChild(tr);

        // Conectar evento input para total en vivo y limpieza de error
        var inp = tr.querySelector('input');
        if (inp) {
            inp.addEventListener('input', function () {
                limpiarErrorCampo(this.id);
                actualizarTotalEnVivo();
                programarGuardadoBorrador();
            });
        }
    }
}

/**
 * Llena el selector de ciudades de compra destacando la más económica.
 */
function poblarCiudadesCotizador() {
    var select = document.getElementById('selectCiudadCotizador');
    if (!select) return;

    var ciudades = CIUDADES_BASE;
    var ciudadMasBarata = obtenerCiudadMasBarata(ciudades);

    select.innerHTML = '';
    for (var i = 0; i < ciudades.length; i++) {
        var c = ciudades[i];
        var opt = document.createElement('option');
        opt.value = c.nombre;
        opt.textContent = c.nombre + ' (Factor ' + c.factor.toFixed(2) + ')' + (c.nombre === ciudadMasBarata.nombre ? ' ⭐ Recomendada' : '');
        if (c.nombre === ciudadMasBarata.nombre) {
            opt.selected = true;
        }
        select.appendChild(opt);
    }
}

/**
 * Pone la tasa oficial BCV actual en el cotizador.
 */
function actualizarTasaEnCotizador() {
    var input = document.getElementById('inputTasaBCVCotizador');
    if (input) {
        input.value = obtenerTasaBCV().toFixed(2);
    }
}

/**
 * Total en Vivo: Calcula y actualiza el panel lateral en tiempo real ante cualquier cambio de entrada.
 */
function actualizarTotalEnVivo() {
    var panel = document.getElementById('asistentePanelEnVivo');
    if (!panel) return;

    var materiales = obtenerMateriales();
    var mapaCant = {};
    var totalItems = 0;

    for (var i = 0; i < materiales.length; i++) {
        var m = materiales[i];
        var inp = document.getElementById('cant_mat_' + m.id);
        if (inp && inp.value !== '') {
            var cantNum = parseInt(inp.value);
            if (!isNaN(cantNum) && cantNum > 0) {
                mapaCant[m.id] = cantNum;
                totalItems += cantNum;
            }
        }
    }

    var badgeItems = document.getElementById('badgeItemsEnVivo');
    if (badgeItems) {
        badgeItems.textContent = totalItems + (totalItems === 1 ? ' unidad' : ' unidades');
    }

    // Ciudad seleccionada
    var selectCiudad = document.getElementById('selectCiudadCotizador');
    var nombreCiudad = selectCiudad ? selectCiudad.value : 'Puerto Ordaz';
    var ciudadSel = null;
    for (var j = 0; j < CIUDADES_BASE.length; j++) {
        if (CIUDADES_BASE[j].nombre === nombreCiudad) {
            ciudadSel = CIUDADES_BASE[j];
            break;
        }
    }
    if (!ciudadSel) ciudadSel = obtenerCiudadMasBarata(CIUDADES_BASE);

    // Estado seleccionado
    var selectEstado = document.getElementById('selectEstadoObraCotizador');
    var estadoDestino = selectEstado ? selectEstado.value : (sesionUsuario ? sesionUsuario.estado : 'Distrito Capital');

    // Tasa BCV
    var inputTasa = document.getElementById('inputTasaBCVCotizador');
    var tasa = inputTasa ? (parseFloat(inputTasa.value) || obtenerTasaBCV()) : obtenerTasaBCV();

    var usuarioSim = {
        perfil: sesionUsuario ? sesionUsuario.perfil : 'Constructor',
        estado: estadoDestino
    };

    var itemsValidados = [];
    for (var matId in mapaCant) {
        for (var k = 0; k < materiales.length; k++) {
            if (materiales[k].id === parseInt(matId)) {
                itemsValidados.push({
                    materialId: materiales[k].id,
                    nombre: materiales[k].nombre,
                    sector: materiales[k].sector,
                    unidad: materiales[k].unidad,
                    precioBase: materiales[k].precioBase,
                    cantidad: mapaCant[matId]
                });
                break;
            }
        }
    }

    var calc = calcularPresupuestoCotizacion(itemsValidados, ciudadSel, usuarioSim, tasa);

    var elSubtotal = document.getElementById('vivoSubtotal');
    var elFlete = document.getElementById('vivoFlete');
    var elDescuento = document.getElementById('vivoDescuento');
    var elContingencia = document.getElementById('vivoContingencia');
    var elIVA = document.getElementById('vivoIVA');
    var elTotalUSD = document.getElementById('vivoTotalUSD');
    var elTotalBs = document.getElementById('vivoTotalBs');

    if (elSubtotal) elSubtotal.textContent = usd(calc.subtotal);
    if (elFlete) elFlete.textContent = usd(calc.flete);
    if (elDescuento) elDescuento.textContent = usd(-calc.descuento);
    if (elContingencia) elContingencia.textContent = usd(calc.contingencia);
    if (elIVA) elIVA.textContent = usd(calc.iva);
    if (elTotalUSD) elTotalUSD.textContent = usd(calc.total);
    if (elTotalBs) elTotalBs.textContent = bs(calc.totalBs);
}

/**
 * Aplica una plantilla de obra precargada al formulario de materiales.
 * @param {string} clavePlantilla - Clave en PLANTILLAS_OBRA (ej: 'casa_pequena').
 */
function aplicarPlantillaObra(clavePlantilla) {
    var plantilla = PLANTILLAS_OBRA[clavePlantilla];
    if (!plantilla) return;

    // Verificar si ya hay cantidades escritas
    var yaTieneCantidades = false;
    var inputs = document.querySelectorAll('#cuerpoTablaCotizador input.input-cantidad');
    for (var i = 0; i < inputs.length; i++) {
        if (inputs[i].value !== '' && parseInt(inputs[i].value) > 0) {
            yaTieneCantidades = true;
            break;
        }
    }

    function cargarValores(sumar) {
        for (var matId in plantilla.cantidades) {
            var input = document.getElementById('cant_mat_' + matId);
            if (input) {
                var cantActual = sumar ? (parseInt(input.value) || 0) : 0;
                input.value = cantActual + plantilla.cantidades[matId];
            }
        }

        // Si el paso 1 no tiene nombre de obra aún, sugerir el nombre de la plantilla
        var inpNombre = document.getElementById('inputNombreObra');
        if (inpNombre && !inpNombre.value.trim()) {
            inpNombre.value = plantilla.nombre + ' - ' + (sesionUsuario ? sesionUsuario.estado : '');
        }

        actualizarTotalEnVivo();
        guardarBorradorActualEnStorage();
        mostrarNotificacion('Plantilla cargada: ' + plantilla.nombre, 'exito');
    }

    if (yaTieneCantidades) {
        mostrarModalConfirmacion(
            'Plantilla: ' + plantilla.nombre,
            'Ya existen cantidades cargadas en la tabla. ¿Desea reemplazar las cantidades existentes o sumarlas a las actuales?',
            function () {
                cargarValores(false); // Reemplazar
            },
            'Reemplazar',
            'Cancelar'
        );
    } else {
        cargarValores(false);
    }
}

/**
 * Renderiza la pantalla del Paso 3 (Revisión Detallada).
 */
function renderizarPaso3Revision() {
    if (!cotizacionEnEdicion) return;

    var resumenObra = document.getElementById('resumenObraPaso3');
    var cuerpoTabla = document.getElementById('cuerpoTablaPaso3');
    var contenedorDesglose = document.getElementById('contenedorDesgloseCotizacionPaso3');

    // 1. Cabecera con datos de la obra
    if (resumenObra) {
        resumenObra.innerHTML =
            '<div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(200px, 1fr)); gap:0.75rem;">' +
            '  <div><strong>Proyecto:</strong> ' + escaparHtml(cotizacionEnEdicion.nombreObra) + '</div>' +
            '  <div><strong>Destino:</strong> Estado ' + escaparHtml(cotizacionEnEdicion.estadoObra) + '</div>' +
            '  <div><strong>Ciudad Proveedora:</strong> ' + escaparHtml(cotizacionEnEdicion.ciudadCompra) + ' (Factor ' + cotizacionEnEdicion.factorCiudad.toFixed(2) + ')</div>' +
            '  <div><strong>Solicitante:</strong> ' + escaparHtml(cotizacionEnEdicion.nombreCliente) + ' (' + escaparHtml(cotizacionEnEdicion.perfil) + ')</div>' +
            (cotizacionEnEdicion.notas ? '  <div style="grid-column:1/-1;"><strong>Notas:</strong> ' + escaparHtml(cotizacionEnEdicion.notas) + '</div>' : '') +
            '</div>';
    }

    // 2. Tabla de materiales calculados
    if (cuerpoTabla) {
        cuerpoTabla.innerHTML = '';
        for (var i = 0; i < cotizacionEnEdicion.items.length; i++) {
            var it = cotizacionEnEdicion.items[i];
            var tr = document.createElement('tr');
            tr.innerHTML =
                '<td><strong>' + escaparHtml(it.nombre) + '</strong></td>' +
                '<td>' + it.cantidad + '</td>' +
                '<td>' + escaparHtml(it.unidad) + '</td>' +
                '<td>' + usd(it.precioUnitario) + '</td>' +
                '<td>' + usd(it.total) + '</td>';
            cuerpoTabla.appendChild(tr);
        }
    }

    // 3. Desglose financiero
    if (contenedorDesglose) {
        var html = '<div class="desglose">';
        html += '<div class="desglose__linea desglose__linea--subtotal">' +
            '<span>Subtotal Materiales (Factor ' + cotizacionEnEdicion.factorCiudad.toFixed(2) + ')</span>' +
            '<span>' + usd(cotizacionEnEdicion.subtotal) + '</span>' +
            '</div>';

        html += '<div class="desglose__linea">' +
            '<span>Flete Terrestre (Factor Estado ' + cotizacionEnEdicion.factorFlete.toFixed(2) + ')</span>' +
            '<span>' + usd(cotizacionEnEdicion.flete) + '</span>' +
            '</div>';

        if (cotizacionEnEdicion.descuento > 0) {
            html += '<div class="desglose__linea">' +
                '<span>Descuento Perfil ' + escaparHtml(cotizacionEnEdicion.perfil) + ' (' + (cotizacionEnEdicion.descuentoPct * 100).toFixed(0) + '%)</span>' +
                '<span style="color:var(--color-exito);">' + usd(-cotizacionEnEdicion.descuento) + '</span>' +
                '</div>';
        }

        html += '<div class="desglose__linea desglose__linea--subtotal">' +
            '<span>Monto Neto Imponible</span>' +
            '<span>' + usd(cotizacionEnEdicion.neto) + '</span>' +
            '</div>';

        html += '<div class="desglose__linea">' +
            '<span>Fondo de Contingencia de Obra (5%)</span>' +
            '<span>' + usd(cotizacionEnEdicion.contingencia) + '</span>' +
            '</div>';

        html += '<div class="desglose__linea">' +
            '<span>I.V.A. Ley 16% sobre (Neto + Contingencia)</span>' +
            '<span>' + usd(cotizacionEnEdicion.iva) + '</span>' +
            '</div>';

        html += '<div class="desglose__linea desglose__linea--total">' +
            '<span>TOTAL GENERAL (USD)</span>' +
            '<span>' + usd(cotizacionEnEdicion.total) + '</span>' +
            '</div>';

        html += '<div class="desglose__linea desglose__linea--total" style="color:var(--color-exito); border-top:1px dashed var(--color-borde);">' +
            '<span>EQUIVALENTE EN BOLÍVARES (Tasa ' + cotizacionEnEdicion.tasaBCV.toFixed(2) + ')</span>' +
            '<span>' + bs(cotizacionEnEdicion.totalBs) + '</span>' +
            '</div>';

        html += '</div>';
        contenedorDesglose.innerHTML = html;
    }
}

/**
 * Renderiza la pantalla del Paso 4 (Envío y Acciones).
 */
function renderizarPaso4Confirmacion() {
    if (!cotizacionEnEdicion) return;

    var tarjeta = document.getElementById('tarjetaResumenEnvio');
    if (!tarjeta) return;

    var numMostrar = cotizacionEnEdicion.correlativo === '(por asignar)'
        ? 'COT-XXX (se asignará al guardar)'
        : cotizacionEnEdicion.correlativo;

    tarjeta.innerHTML =
        '<div style="background:var(--color-fondo); border:1px solid var(--color-borde); border-radius:var(--radio-md); padding:1.25rem; margin-bottom:1.5rem; text-align:left;">' +
        '  <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid var(--color-borde); padding-bottom:0.75rem; margin-bottom:0.75rem;">' +
        '    <span style="font-size:1.1rem; font-weight:700;">' + escaparHtml(numMostrar) + '</span>' +
        '    <span class="badge-semaforo badge-semaforo--verde">Lista para emitir</span>' +
        '  </div>' +
        '  <div><strong>Obra:</strong> ' + escaparHtml(cotizacionEnEdicion.nombreObra) + ' (' + escaparHtml(cotizacionEnEdicion.estadoObra) + ')</div>' +
        '  <div><strong>Partidas:</strong> ' + cotizacionEnEdicion.items.length + ' materiales requeridos</div>' +
        '  <div style="font-size:1.3rem; font-weight:800; color:var(--color-acento); margin-top:0.75rem;">Total: ' + usd(cotizacionEnEdicion.total) + '</div>' +
        '  <div style="font-size:1.1rem; font-weight:700; color:var(--color-exito);">' + bs(cotizacionEnEdicion.totalBs) + ' (Tasa ' + cotizacionEnEdicion.tasaBCV.toFixed(2) + ')</div>' +
        '</div>';
}

/**
 * Guarda formalmente la cotización como BORRADOR o ENVIADA y limpia el borrador automático.
 * @param {string} estadoDestino - 'BORRADOR' o 'ENVIADA'.
 */
function guardarCotizacionComo(estadoDestino) {
    if (!cotizacionEnEdicion) return;

    if (cotizacionEnEdicion.correlativo === '(por asignar)') {
        cotizacionEnEdicion.correlativo = generarSiguienteCorrelativo();
    }
    cotizacionEnEdicion.estado = estadoDestino;

    var cotizaciones = obtenerCotizaciones();
    cotizaciones.unshift(cotizacionEnEdicion);
    guardarCotizaciones(cotizaciones);

    // Limpiar el borrador temporal guardado en localStorage
    limpiarBorradorAsistente(sesionUsuario.id);

    registrarEnBitacora(
        sesionUsuario.nombre,
        estadoDestino === 'BORRADOR' ? 'COTIZACION_BORRADOR' : 'COTIZACION_ENVIADA',
        'Cotización ' + cotizacionEnEdicion.correlativo + ' guardada como ' + estadoDestino + ' por ' + usd(cotizacionEnEdicion.total)
    );

    mostrarNotificacion('Cotización ' + cotizacionEnEdicion.correlativo + ' registrada con estado "' + estadoDestino + '".', 'exito');

    limpiarFormularioCotizador();
    pasoCotizadorActual = 1;
    renderizarModuloCotizador();
}

/**
 * Descarta la cotización en curso con confirmación.
 */
function cancelarCotizacionEnEdicion() {
    mostrarModalConfirmacion(
        'Descartar Cotización',
        '¿Desea descartar la cotización actual? Se perderán las cantidades y datos ingresados.',
        function () {
            limpiarBorradorAsistente(sesionUsuario.id);
            cotizacionEnEdicion = null;
            limpiarFormularioCotizador();
            pasoCotizadorActual = 1;
            renderizarModuloCotizador();
            mostrarNotificacion('Cotización descartada.', 'info');
        },
        'Sí, descartar',
        'Volver'
    );
}

/**
 * Limpia los campos del formulario de cotizador.
 */
function limpiarFormularioCotizador() {
    var inputs = document.querySelectorAll('#cuerpoTablaCotizador input.input-cantidad');
    for (var i = 0; i < inputs.length; i++) {
        inputs[i].value = '';
    }
    var inpNombre = document.getElementById('inputNombreObra');
    var inpNotas = document.getElementById('inputNotasObra');
    if (inpNombre) inpNombre.value = '';
    if (inpNotas) inpNotas.value = '';

    cotizacionEnEdicion = null;
    actualizarTotalEnVivo();
}

// ============================================================
// 9. MODAL PEDAGÓGICO: ¿CÓMO SE CALCULÓ ESTO?
// ============================================================

/**
 * Abre el modal pedagógico explicando cada paso matemático con números reales.
 * @param {Object} [cot] - Objeto de cotización a explicar (por defecto la cotización en edición).
 */
function abrirModalComoSeCalculo(cot) {
    var objetivo = cot || cotizacionEnEdicion;
    if (!objetivo) return;

    var modal = document.getElementById('modalComoSeCalculo');
    var contenedor = document.getElementById('contenedorPasosPedagogicos');
    if (!modal || !contenedor) return;

    var pasos = desglosarPasosCalculoPedagogico(objetivo);
    if (!pasos || !pasos.length) return;

    var html = '';
    for (var i = 0; i < pasos.length; i++) {
        var p = pasos[i];
        html += '<div class="tarjeta-paso-pedagogico">' +
            '<div class="tarjeta-paso-pedagogico__encabezado">' +
                '<span class="tarjeta-paso-pedagogico__numero">' + p.paso + '</span>' +
                '<strong class="tarjeta-paso-pedagogico__titulo">' + escaparHtml(p.titulo) + '</strong>' +
            '</div>' +
            '<div class="tarjeta-paso-pedagogico__formula"><code>' + escaparHtml(p.formula) + '</code></div>' +
            '<div class="tarjeta-paso-pedagogico__detalle">' + escaparHtml(p.detalle) + '</div>' +
            '<div class="tarjeta-paso-pedagogico__resultado"><strong>Resultado:</strong> ' + escaparHtml(p.resultado) + '</div>' +
        '</div>';
    }

    contenedor.innerHTML = html;
    modal.classList.remove('oculto');
    enfocarPrimerElementoModal(modal);
}

/**
 * Cierra el modal pedagógico.
 */
function cerrarModalComoSeCalculo() {
    var modal = document.getElementById('modalComoSeCalculo');
    if (modal) modal.classList.add('oculto');
}

// ============================================================
// 10. MÓDULO: DÓNDE CONVIENE COMPRAR (ALGORITMO BURBUJA MANUAL)
// ============================================================

function renderizarModuloCiudades() {
    var cuerpo = document.getElementById('cuerpoTablaCiudades');
    if (!cuerpo) return;

    // Ordenar con algoritmo burbuja manual (sin usar sort)
    var ciudadesOrdenadas = ordenarBurbuja(CIUDADES_BASE, 'factor', true);

    cuerpo.innerHTML = '';
    for (var i = 0; i < ciudadesOrdenadas.length; i++) {
        var c = ciudadesOrdenadas[i];
        var esMejor = (i === 0);

        var tr = document.createElement('tr');
        if (esMejor) {
            tr.className = 'fila-mejor';
        }

        tr.innerHTML =
            '<td><strong>#' + (i + 1) + '</strong></td>' +
            '<td>' + c.nombre + '</td>' +
            '<td>' + c.factor.toFixed(2) + '</td>' +
            '<td>' + (esMejor ? '<span class="badge-exito">⭐ Más Económica (Opción recomendada)</span>' : 'Estándar') + '</td>';
        cuerpo.appendChild(tr);
    }
}

// ============================================================
// 11. MÓDULO: CATÁLOGO EDITABLE (SOLO GOBERNACIÓN)
// ============================================================

function renderizarModuloCatalogo() {
    var cuerpo = document.getElementById('cuerpoTablaCatalogo');
    if (!cuerpo) return;

    var materiales = obtenerMateriales();
    cuerpo.innerHTML = '';

    for (var i = 0; i < materiales.length; i++) {
        var m = materiales[i];
        var tr = document.createElement('tr');
        tr.innerHTML =
            '<td>' + m.id + '</td>' +
            '<td><strong>' + escaparHtml(m.nombre) + '</strong></td>' +
            '<td><span class="badge-sector badge-sector--' + m.sector.toLowerCase() + '">' + escaparHtml(m.sector) + '</span></td>' +
            '<td>' + escaparHtml(m.unidad) + '</td>' +
            '<td>' + usd(m.precioBase) + '</td>' +
            '<td>' + (m.activo ? '<span class="badge-exito">Activo</span>' : '<span class="badge-peligro">Inactivo</span>') + '</td>' +
            '<td>' +
            '<button class="boton boton--secundario boton--sm" onclick="abrirModalEditarMaterial(' + m.id + ')">' + icono('editar', 14) + ' Editar</button> ' +
            '<button class="boton boton--secundario boton--sm" onclick="verHistorialPreciosMaterial(' + m.id + ')">' + icono('historial', 14) + ' Historial</button> ' +
            '<button class="boton ' + (m.activo ? 'boton--peligro' : 'boton--exito') + ' boton--sm" onclick="alternarActivoMaterial(' + m.id + ')">' +
            (m.activo ? 'Desactivar' : 'Activar') + '</button>' +
            '</td>';
        cuerpo.appendChild(tr);
    }
}

function abrirModalNuevoMaterial() {
    materialEnEdicionId = null;
    limpiarErrores('modalMaterial');
    document.getElementById('modalMaterialTitulo').textContent = 'Registrar Nuevo Material';
    document.getElementById('matNombre').value = '';
    document.getElementById('matSector').value = 'Construcción';
    document.getElementById('matUnidad').value = '';
    document.getElementById('matPrecio').value = '';
    document.getElementById('matPeso').value = '';

    var modal = document.getElementById('modalMaterial');
    modal.classList.remove('oculto');
    enfocarPrimerElementoModal(modal);
}

function abrirModalEditarMaterial(id) {
    var materiales = obtenerMateriales();
    var mat = null;
    for (var i = 0; i < materiales.length; i++) {
        if (materiales[i].id === id) {
            mat = materiales[i];
            break;
        }
    }
    if (!mat) return;

    materialEnEdicionId = id;
    limpiarErrores('modalMaterial');
    document.getElementById('modalMaterialTitulo').textContent = 'Editar Material: ' + mat.nombre;
    document.getElementById('matNombre').value = mat.nombre;
    document.getElementById('matSector').value = mat.sector;
    document.getElementById('matUnidad').value = mat.unidad;
    document.getElementById('matPrecio').value = mat.precioBase;
    document.getElementById('matPeso').value = mat.pesoKg || '';

    var modal = document.getElementById('modalMaterial');
    modal.classList.remove('oculto');
    enfocarPrimerElementoModal(modal);
}

function cerrarModalMaterial() {
    document.getElementById('modalMaterial').classList.add('oculto');
}

function guardarMaterialDesdeModal() {
    limpiarErrores('modalMaterial');
    var nombre = document.getElementById('matNombre').value.trim();
    var sector = document.getElementById('matSector').value;
    var unidad = document.getElementById('matUnidad').value.trim();
    var precio = parseFloat(document.getElementById('matPrecio').value);
    var peso = parseFloat(document.getElementById('matPeso').value) || 0;

    var matObj = {
        nombre: nombre,
        sector: sector,
        unidad: unidad,
        precioBase: precio,
        pesoKg: peso
    };

    var materiales = obtenerMateriales();
    var validacion = validarMaterialCatalogo(matObj, materiales, materialEnEdicionId);
    if (!validacion.valido) {
        if (!nombre || nombre.length < 3 || validacion.error.indexOf('nombre') !== -1) {
            mostrarErrorCampo('matNombre', validacion.error);
        } else if (isNaN(precio) || precio <= 0 || validacion.error.indexOf('precio') !== -1) {
            mostrarErrorCampo('matPrecio', validacion.error);
        } else if (!unidad || validacion.error.indexOf('unidad') !== -1) {
            mostrarErrorCampo('matUnidad', validacion.error);
        }
        mostrarNotificacion(validacion.error, 'error');
        return;
    }

    if (materialEnEdicionId === null) {
        var nuevoId = 1;
        for (var i = 0; i < materiales.length; i++) {
            if (materiales[i].id >= nuevoId) nuevoId = materiales[i].id + 1;
        }
        matObj.id = nuevoId;
        matObj.activo = true;
        matObj.historialPrecios = [
            { fecha: obtenerFechaActual(), precioAnterior: 0, precioNuevo: precio, usuario: sesionUsuario.nombre }
        ];
        materiales.push(matObj);
        registrarEnBitacora(sesionUsuario.nombre, 'MATERIAL_CREADO', 'Nuevo material "' + nombre + '" a $' + formatearMoneda(precio));
    } else {
        for (var j = 0; j < materiales.length; j++) {
            if (materiales[j].id === materialEnEdicionId) {
                var precioViejo = materiales[j].precioBase;
                materiales[j].nombre = nombre;
                materiales[j].sector = sector;
                materiales[j].unidad = unidad;
                materiales[j].pesoKg = peso;

                if (precioViejo !== precio) {
                    if (!Array.isArray(materiales[j].historialPrecios)) {
                        materiales[j].historialPrecios = [];
                    }
                    materiales[j].historialPrecios.unshift({
                        fecha: obtenerFechaActual(),
                        precioAnterior: precioViejo,
                        precioNuevo: precio,
                        usuario: sesionUsuario.nombre
                    });
                    materiales[j].precioBase = precio;
                    registrarEnBitacora(sesionUsuario.nombre, 'PRECIO_MODIFICADO', 'Cambio de precio en "' + nombre + '" de $' + formatearMoneda(precioViejo) + ' a $' + formatearMoneda(precio));
                }
                break;
            }
        }
    }

    guardarMateriales(materiales);
    cerrarModalMaterial();
    renderizarModuloCatalogo();
    mostrarNotificacion('Material guardado con éxito.', 'exito');
}

function alternarActivoMaterial(id) {
    var materiales = obtenerMateriales();
    for (var i = 0; i < materiales.length; i++) {
        if (materiales[i].id === id) {
            materiales[i].activo = !materiales[i].activo;
            registrarEnBitacora(
                sesionUsuario.nombre,
                materiales[i].activo ? 'MATERIAL_ACTIVADO' : 'MATERIAL_DESACTIVADO',
                'Material "' + materiales[i].nombre + '" marcado como ' + (materiales[i].activo ? 'activo' : 'inactivo')
            );
            break;
        }
    }
    guardarMateriales(materiales);
    renderizarModuloCatalogo();
}

function verHistorialPreciosMaterial(id) {
    var materiales = obtenerMateriales();
    var mat = null;
    for (var i = 0; i < materiales.length; i++) {
        if (materiales[i].id === id) {
            mat = materiales[i];
            break;
        }
    }
    if (!mat) return;

    var html = '<div class="tabla-contenedor" style="margin-top:0.5rem;">';
    if (!mat.historialPrecios || mat.historialPrecios.length === 0) {
        html += '<p style="color:var(--color-texto-secundario); padding:1rem;">No existen cambios de precio registrados para este material.</p>';
    } else {
        html += '<table class="tabla-datos" style="width:100%;">' +
            '<thead>' +
                '<tr>' +
                    '<th>Fecha</th>' +
                    '<th>Precio Ant.</th>' +
                    '<th>Precio Nuevo</th>' +
                    '<th>Registrado Por</th>' +
                    '<th>Motivo</th>' +
                '</tr>' +
            '</thead>' +
            '<tbody>';
        for (var j = 0; j < mat.historialPrecios.length; j++) {
            var h = mat.historialPrecios[j];
            html += '<tr>' +
                '<td>' + escaparHtml(h.fecha || '-') + '</td>' +
                '<td>$' + formatearMoneda(h.precioAnterior || 0) + '</td>' +
                '<td><strong>$' + formatearMoneda(h.precioNuevo || 0) + '</strong></td>' +
                '<td>' + escaparHtml(h.usuario || '-') + '</td>' +
                '<td>' + escaparHtml(h.motivo || 'Ajuste de catálogo') + '</td>' +
            '</tr>';
        }
        html += '</tbody></table>';
    }
    html += '</div>';

    mostrarModalConfirmacion('Historial de Precios — ' + escaparHtml(mat.nombre), html, null, 'Cerrar', '', true);
}

// ============================================================
// 12. MÓDULO: APROBACIONES Y CONTROL DE FONDOS
// ============================================================

function renderizarModuloAprobaciones() {
    var cuerpoEnviadas = document.getElementById('cuerpoTablaAprobaciones');
    var cuerpoAprobadas = document.getElementById('cuerpoTablaParaEntrega');
    if (!cuerpoEnviadas) return;

    var cotizaciones = obtenerCotizaciones();
    var usuarios = obtenerUsuarios();

    cuerpoEnviadas.innerHTML = '';
    var contadorEnviadas = 0;

    for (var i = 0; i < cotizaciones.length; i++) {
        var c = cotizaciones[i];
        if (c.estado === 'ENVIADA') {
            contadorEnviadas++;

            var uSol = null;
            for (var u = 0; u < usuarios.length; u++) {
                if (usuarios[u].id === c.usuarioId) {
                    uSol = usuarios[u];
                    break;
                }
            }

            var evaluacion = uSol ? evaluarAprobacionCotizacion(c, uSol) : { aprobable: false, faltante: 0 };

            var tr = document.createElement('tr');
            tr.innerHTML =
                '<td><strong>' + escaparHtml(c.correlativo) + '</strong></td>' +
                '<td>' + escaparHtml(c.fechaCreacion) + '</td>' +
                '<td>' + escaparHtml(c.nombreCliente) + ' (' + escaparHtml(c.perfil) + ')</td>' +
                '<td>' + usd(c.total) + '</td>' +
                '<td>' + (evaluacion.aprobable ?
                    '<span class="badge-exito">Fondos Suficientes</span>' :
                    '<span class="badge-peligro">Déficit: ' + usd(evaluacion.faltante) + '</span>') +
                '</td>' +
                '<td>' +
                '<button class="boton boton--exito boton--sm" ' + (!evaluacion.aprobable ? 'disabled title="Fondos insuficientes"' : '') +
                ' onclick="procesarAprobacion(' + c.id + ', true)">' + icono('check', 14) + ' Aprobar</button> ' +
                '<button class="boton boton--peligro boton--sm" onclick="procesarAprobacion(' + c.id + ', false)">' + icono('cerrar', 14) + ' Rechazar</button> ' +
                '<button class="boton boton--secundario boton--sm" onclick="verDocumentoCotizacion(' + c.id + ')">' + icono('ojo', 14) + ' Ver</button>' +
                '</td>';
            cuerpoEnviadas.appendChild(tr);
        }
    }

    if (contadorEnviadas === 0) {
        cuerpoEnviadas.innerHTML =
            '<tr><td colspan="6">' +
            '  <div class="estado-vacio">' +
            '    <div class="estado-vacio__icono">' + icono('correo', 36) + '</div>' +
            '    <div class="estado-vacio__titulo">No hay cotizaciones pendientes</div>' +
            '    <div class="estado-vacio__descripcion">Todas las solicitudes recibidas han sido aprobadas o revisadas.</div>' +
            '  </div>' +
            '</td></tr>';
    }

    // Tabla de cotizaciones APROBADAS para entrega
    if (cuerpoAprobadas) {
        cuerpoAprobadas.innerHTML = '';
        var contadorAprobadas = 0;

        for (var j = 0; j < cotizaciones.length; j++) {
            var ca = cotizaciones[j];
            if (ca.estado === 'APROBADA') {
                contadorAprobadas++;
                var tra = document.createElement('tr');
                tra.innerHTML =
                    '<td><strong>' + escaparHtml(ca.correlativo) + '</strong></td>' +
                    '<td>' + escaparHtml(ca.nombreCliente) + ' (' + escaparHtml(ca.perfil) + ')</td>' +
                    '<td>' + usd(ca.total) + '</td>' +
                    '<td><span class="badge-exito">FONDOS COMPROMETIDOS</span></td>' +
                    '<td>' +
                    '<button class="boton boton--primario boton--sm" onclick="marcarComoEntregada(' + ca.id + ')">' + icono('camion', 14) + ' Marcar Entregada</button> ' +
                    '<button class="boton boton--secundario boton--sm" onclick="verDocumentoCotizacion(' + ca.id + ')">' + icono('ojo', 14) + ' Ver</button>' +
                    '</td>';
                cuerpoAprobadas.appendChild(tra);
            }
        }

        if (contadorAprobadas === 0) {
            cuerpoAprobadas.innerHTML =
                '<tr><td colspan="5">' +
                '  <div class="estado-vacio">' +
                '    <div class="estado-vacio__icono">' + icono('camion', 36) + '</div>' +
                '    <div class="estado-vacio__titulo">No hay obras en tránsito para entrega</div>' +
                '    <div class="estado-vacio__descripcion">Las órdenes aprobadas pendientes de despacho aparecerán aquí.</div>' +
                '  </div>' +
                '</td></tr>';
        }
    }
}

function procesarAprobacion(cotizacionId, esAprobada) {
    var cotizaciones = obtenerCotizaciones();
    var usuarios = obtenerUsuarios();
    var cot = null;

    for (var i = 0; i < cotizaciones.length; i++) {
        if (cotizaciones[i].id === cotizacionId) {
            cot = cotizaciones[i];
            break;
        }
    }
    if (!cot) return;

    var usuarioSolicitante = null;
    for (var j = 0; j < usuarios.length; j++) {
        if (usuarios[j].id === cot.usuarioId) {
            usuarioSolicitante = usuarios[j];
            break;
        }
    }

    if (esAprobada) {
        if (!usuarioSolicitante) {
            mostrarNotificacion('Error: usuario solicitante no encontrado.', 'error');
            return;
        }

        var evaluacion = evaluarAprobacionCotizacion(cot, usuarioSolicitante);
        if (!evaluacion.aprobable) {
            mostrarNotificacion('No se puede aprobar: ' + evaluacion.motivo + '. Faltan $' + formatearMoneda(evaluacion.faltante) + ' USD.', 'error');
            return;
        }

        usuarioSolicitante.comprometido += cot.total;
        cot.estado = 'APROBADA';

        guardarUsuarios(usuarios);
        guardarCotizaciones(cotizaciones);

        registrarEnBitacora(
            sesionUsuario.nombre,
            'COTIZACION_APROBADA',
            'Aprobación de ' + cot.correlativo + ' por $' + formatearMoneda(cot.total) + '. Monto comprometido reservado.'
        );

        mostrarNotificacion('Cotización ' + cot.correlativo + ' APROBADA exitosamente. Fondos reservados.', 'exito');
        renderizarModuloAprobaciones();
        actualizarCabeceraUsuario();
    } else {
        abrirModalRechazo(cotizacionId);
    }
}

/**
 * Abre el modal formal para indicar el motivo justificado de rechazo.
 * @param {number} cotizacionId - Identificador de la cotización.
 */
function abrirModalRechazo(cotizacionId) {
    _cotizacionIdRechazo = cotizacionId;
    var modal = document.getElementById('modalRechazo');
    var input = document.getElementById('motivoRechazoInput');
    if (!modal || !input) return;
    input.value = '';
    modal.classList.remove('oculto');
    enfocarPrimerElementoModal(modal);
}

/**
 * Procesa y asienta el rechazo formal desde el modal sin usar prompt().
 */
function confirmarRechazoDesdeModal() {
    if (!_cotizacionIdRechazo) return;
    var input = document.getElementById('motivoRechazoInput');
    var motivo = input ? input.value.trim() : '';
    if (!motivo) {
        mostrarNotificacion('El rechazo requiere un motivo justificado.', 'advertencia');
        return;
    }
    var cotizaciones = obtenerCotizaciones();
    var cot = null;
    for (var i = 0; i < cotizaciones.length; i++) {
        if (cotizaciones[i].id === _cotizacionIdRechazo) {
            cot = cotizaciones[i];
            break;
        }
    }
    if (!cot) return;
    cot.estado = 'RECHAZADA';
    cot.motivoRechazo = motivo;
    guardarCotizaciones(cotizaciones);
    registrarEnBitacora(
        sesionUsuario.nombre,
        'COTIZACION_RECHAZADA',
        'Rechazo de ' + cot.correlativo + '. Motivo: ' + motivo
    );
    cerrarTodosLosModales();
    mostrarNotificacion('Cotización ' + cot.correlativo + ' rechazada.', 'info');
    renderizarModuloAprobaciones();
    actualizarCabeceraUsuario();
}

function marcarComoEntregada(cotizacionId) {
    mostrarModalConfirmacion(
        'Confirmar Entrega de Obra',
        '¿Confirma que los materiales fueron despachados y recibidos en obra? Esta acción pasará los fondos de comprometidos a gastados definitivos.',
        function () {
            var cotizaciones = obtenerCotizaciones();
            var usuarios = obtenerUsuarios();
            var cot = null;

            for (var i = 0; i < cotizaciones.length; i++) {
                if (cotizaciones[i].id === cotizacionId) {
                    cot = cotizaciones[i];
                    break;
                }
            }
            if (!cot) return;

            var uSol = null;
            for (var j = 0; j < usuarios.length; j++) {
                if (usuarios[j].id === cot.usuarioId) {
                    uSol = usuarios[j];
                    break;
                }
            }

            if (uSol) {
                uSol.comprometido = Math.max(0, uSol.comprometido - cot.total);
                uSol.gastado += cot.total;
                guardarUsuarios(usuarios);
            }

            cot.estado = 'ENTREGADA';
            guardarCotizaciones(cotizaciones);

            registrarEnBitacora(
                sesionUsuario.nombre,
                'COTIZACION_ENTREGADA',
                'Entrega de obra ' + cot.correlativo + '. Fondos transferidos a gastado final ($' + formatearMoneda(cot.total) + ').'
            );

            mostrarNotificacion('Cotización ' + cot.correlativo + ' marcada como ENTREGADA.', 'exito');
            renderizarModuloAprobaciones();
            actualizarCabeceraUsuario();
        },
        'Confirmar Entrega',
        'Cancelar'
    );
}

// ============================================================
// 13. MÓDULO: DOCUMENTO IMPRIMIBLE CON LOGO
// ============================================================

function verDocumentoCotizacion(id) {
    var cotizaciones = obtenerCotizaciones();
    var cot = null;
    for (var i = 0; i < cotizaciones.length; i++) {
        if (cotizaciones[i].id === id) {
            cot = cotizaciones[i];
            break;
        }
    }
    if (!cot) return;

    documentoActual = cot;
    renderizarDocumentoImprimible(documentoActual);
}

function renderizarDocumentoImprimible(c) {
    var contDoc = document.getElementById('vistaDocumentoImprimible');
    var contenido = document.getElementById('contenidoDocumentoImprimible');
    if (!contDoc || !contenido) return;

    var html = '';
    html += '<div class="doc-encabezado">' +
        '<div>' +
        '<img src="img/logo-negro.png" alt="Logo SICOP" class="logo-impresion">' +
        '<h2>REPÚBLICA BOLIVARIANA DE VENEZUELA</h2>' +
        '<h3>SISTEMA INTEGRADO DE COTIZACIÓN DE OBRAS PÚBLICAS (SICOP-VE)</h3>' +
        '<p class="texto-secundario">Control Presupuestario y Suministro de Materiales</p>' +
        '</div>' +
        '<div style="text-align:right;">' +
        '<div class="doc-numero">' + escaparHtml(c.correlativo) + '</div>' +
        '<div><strong>Fecha Emisión:</strong> ' + escaparHtml(c.fechaCreacion) + '</div>' +
        '<div><strong>Validez:</strong> ' + c.validezDias + ' días hábiles</div>' +
        '<div><strong>Estado:</strong> <span class="badge-semaforo badge-semaforo--verde">' + escaparHtml(c.estado) + '</span></div>' +
        '</div>' +
        '</div>';

    html += '<div class="doc-datos-cliente">' +
        '<p><strong>Cliente / Solicitante:</strong> ' + escaparHtml(c.nombreCliente) + ' (' + escaparHtml(c.perfil) + ')</p>' +
        '<p><strong>Proyecto / Obra:</strong> ' + escaparHtml(c.nombreObra || 'Construcción y Mantenimiento') + '</p>' +
        '<p><strong>Destino de la Obra:</strong> Estado ' + escaparHtml(c.estadoObra) + ' (Flete: ' + c.factorFlete.toFixed(2) + ')</p>' +
        '<p><strong>Punto de Compra:</strong> ' + escaparHtml(c.ciudadCompra) + ' (Factor: ' + c.factorCiudad.toFixed(2) + ')</p>' +
        '</div>';

    html += '<table class="tabla" style="margin: 1.5rem 0;">' +
        '<thead>' +
        '<tr><th>Item</th><th>Descripción</th><th>Sector</th><th>Cantidad</th><th>Unidad</th><th>P. Unit ($)</th><th>Total ($)</th></tr>' +
        '</thead><tbody>';

    for (var i = 0; i < c.items.length; i++) {
        var it = c.items[i];
        html += '<tr>' +
            '<td>' + (i + 1) + '</td>' +
            '<td>' + escaparHtml(it.nombre) + '</td>' +
            '<td>' + escaparHtml(it.sector) + '</td>' +
            '<td>' + it.cantidad + '</td>' +
            '<td>' + escaparHtml(it.unidad) + '</td>' +
            '<td>' + usd(it.precioUnitario) + '</td>' +
            '<td>' + usd(it.total) + '</td>' +
            '</tr>';
    }
    html += '</tbody></table>';

    html += '<div class="doc-totales">' +
        '<div class="doc-linea-total"><span>Subtotal:</span><span>' + usd(c.subtotal) + '</span></div>' +
        '<div class="doc-linea-total"><span>Flete:</span><span>' + usd(c.flete) + '</span></div>' +
        '<div class="doc-linea-total"><span>Descuento (' + (c.descuentoPct * 100).toFixed(0) + '%):</span><span>' + usd(-c.descuento) + '</span></div>' +
        '<div class="doc-linea-total"><span>Monto Neto:</span><span>' + usd(c.neto) + '</span></div>' +
        '<div class="doc-linea-total"><span>Contingencia (5%):</span><span>' + usd(c.contingencia) + '</span></div>' +
        '<div class="doc-linea-total"><span>I.V.A. (16%):</span><span>' + usd(c.iva) + '</span></div>' +
        '<div class="doc-linea-total" style="font-weight:700; font-size:1.2rem; color:var(--color-acento); border-top:2px solid var(--color-acento);">' +
        '<span>TOTAL GENERAL (USD):</span><span>' + usd(c.total) + '</span>' +
        '</div>' +
        '<div class="doc-linea-total" style="font-weight:700; color:var(--color-exito);">' +
        '<span>TOTAL EN BOLÍVARES (Tasa ' + c.tasaBCV.toFixed(2) + '):</span><span>' + bs(c.totalBs) + '</span>' +
        '</div>' +
        '</div>';

    html += '<div class="doc-firmas">' +
        '<div class="doc-firma-bloque">' +
        '<div class="doc-firma-linea"></div>' +
        '<strong>' + escaparHtml(c.nombreCliente) + '</strong><br>' + escaparHtml(c.perfil) + ' (Solicitante)' +
        '</div>' +
        '<div class="doc-firma-bloque">' +
        '<div class="doc-firma-linea"></div>' +
        '<strong>Visto Bueno / Autorización</strong><br>Gobernación del Estado (Aprobador)' +
        '</div>' +
        '</div>';

    contenido.innerHTML = html;
    contDoc.classList.remove('oculto');
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function ocultarVistaImprimible() {
    var contDoc = document.getElementById('vistaDocumentoImprimible');
    if (contDoc) contDoc.classList.add('oculto');
}

function imprimirDocumentoActual() {
    window.print();
}

function compartirDocumentoWhatsApp() {
    var objetivo = documentoActual || cotizacionEnEdicion;
    if (!objetivo) return;
    var url = generarEnlaceWhatsApp(objetivo);
    window.open(url, '_blank');
}

// ============================================================
// 14. MÓDULO: DASHBOARD CON MÉTRICAS Y GRÁFICOS
// ============================================================

function renderizarDashboard() {
    actualizarCabeceraUsuario();

    var cotizaciones = obtenerCotizaciones();
    var usuarios = obtenerUsuarios();
    var esGobernacion = (sesionUsuario && sesionUsuario.perfil === 'Gobernación');

    var cotizacionesVisibles = [];
    for (var i = 0; i < cotizaciones.length; i++) {
        if (esGobernacion || cotizaciones[i].usuarioId === sesionUsuario.id) {
            cotizacionesVisibles.push(cotizaciones[i]);
        }
    }

    var totalMes = cotizacionesVisibles.length;
    var montoAprobado = 0;
    var montoEntregado = 0;

    for (var j = 0; j < cotizacionesVisibles.length; j++) {
        var c = cotizacionesVisibles[j];
        if (c.estado === 'APROBADA' || c.estado === 'ENTREGADA') {
            montoAprobado += c.total;
        }
        if (c.estado === 'ENTREGADA') {
            montoEntregado += c.total;
        }
    }

    var kpiTotal = document.getElementById('kpiCotizacionesMes');
    var kpiAprobado = document.getElementById('kpiMontoAprobado');
    var kpiEntregado = document.getElementById('kpiMontoEntregado');
    var kpiAlertas = document.getElementById('kpiUsuariosAlerta');
    var kpiTituloAlerta = document.getElementById('kpiTituloAlerta');
    var kpiDetalleAlerta = document.getElementById('kpiUsuariosAlertaDetalle');

    if (kpiTotal) kpiTotal.textContent = totalMes;
    if (kpiAprobado) kpiAprobado.textContent = '$' + formatearMoneda(montoAprobado);
    if (kpiEntregado) kpiEntregado.textContent = '$' + formatearMoneda(montoEntregado);

    if (esGobernacion) {
        var alertas = detectarAlertasSistema(usuarios, cotizaciones);
        var usuariosEnAlerta = 0;
        var nombreEnAlerta = '';
        for (var a = 0; a < alertas.length; a++) {
            if (alertas[a].tipo === 'PRESUPUESTO_CRITICO') {
                usuariosEnAlerta++;
                if (!nombreEnAlerta && alertas[a].usuario) {
                    nombreEnAlerta = alertas[a].usuario.nombre;
                }
            }
        }
        if (kpiTituloAlerta) kpiTituloAlerta.textContent = 'Entidades en Alerta (≥90%)';
        if (kpiAlertas) kpiAlertas.textContent = usuariosEnAlerta;
        if (kpiDetalleAlerta) {
            kpiDetalleAlerta.textContent = usuariosEnAlerta > 0
                ? (nombreEnAlerta ? nombreEnAlerta + ' en límite' : usuariosEnAlerta + ' entidad en riesgo')
                : 'Todas las entidades en rango';
        }
    } else {
        var estadoPropio = calcularEstadoPresupuestoUsuario(sesionUsuario);
        if (kpiTituloAlerta) kpiTituloAlerta.textContent = 'Consumo de Límite';
        if (kpiAlertas) kpiAlertas.textContent = estadoPropio.porcentajeUso.toFixed(1) + '%';
        if (kpiDetalleAlerta) {
            if (estadoPropio.porcentajeUso >= 90) {
                kpiDetalleAlerta.textContent = 'Nivel crítico de gasto';
                kpiDetalleAlerta.style.color = 'var(--color-peligro)';
            } else if (estadoPropio.porcentajeUso >= 75) {
                kpiDetalleAlerta.textContent = 'Atención: consumo elevado';
                kpiDetalleAlerta.style.color = 'var(--color-advertencia)';
            } else {
                kpiDetalleAlerta.textContent = 'Dentro del rango operativo';
                kpiDetalleAlerta.style.color = '';
            }
        }
    }

    renderizarGraficoSectores(cotizacionesVisibles);
    renderizarBarrasPresupuestoDashboard(usuarios, esGobernacion);
    if (typeof hidratarIconos === 'function') {
        var modDash = document.getElementById('modulo-dashboard');
        if (modDash) hidratarIconos(modDash);
    }
}

function renderizarGraficoSectores(cotizaciones) {
    var contenedor = document.getElementById('graficoSectoresDashboard');
    if (!contenedor) return;

    var totales = calcularTotalesSupervision(cotizaciones);
    var sectores = SECTORES_CATALOGO;
    var maxMonto = 1;

    for (var s = 0; s < sectores.length; s++) {
        var val = totales.porSector[sectores[s]] || 0;
        if (val > maxMonto) maxMonto = val;
    }

    var html = '<div class="grafico-barras">';
    for (var i = 0; i < sectores.length; i++) {
        var sec = sectores[i];
        var monto = totales.porSector[sec] || 0;
        var pct = maxMonto > 0 ? (monto / maxMonto) * 100 : 0;

        html += '<div class="barra-fila">' +
            '<div class="barra-fila__etiqueta">' + sec + '</div>' +
            '<div class="barra-fila__pista">' +
            '<div class="barra-fila__relleno barra-fila__relleno--' + sec.toLowerCase() + '" style="width:' + (monto > 0 ? Math.max(3, pct) : 0) + '%;"></div>' +
            '</div>' +
            '<div class="barra-fila__valor">$' + formatearMoneda(monto) + '</div>' +
            '</div>';
    }
    html += '</div>';

    contenedor.innerHTML = html;
}

function renderizarBarrasPresupuestoDashboard(usuarios, esGobernacion) {
    var contenedor = document.getElementById('semaforosPresupuestoDashboard');
    if (!contenedor) return;

    var html = '';

    if (!esGobernacion) {
        // Vista Ejecutiva Individual: Desglose balanceado de 4 cuadrantes para evitar espacios vacíos
        var st = calcularEstadoPresupuestoUsuario(sesionUsuario);
        var colorClase = st.colorSemaforo; // 'verde', 'amarillo', 'rojo'
        var estadoTexto = colorClase === 'rojo' ? 'Límite Crítico' : (colorClase === 'amarillo' ? 'Precaución' : 'Operativo Óptimo');

        html += '<div class="bloque-semaforo-individual">' +
            '<div class="semaforo-header">' +
            '  <div>' +
            '    <div class="semaforo-header__nombre">' + escaparHtml(sesionUsuario.nombre) + '</div>' +
            '    <span class="badge-sector badge-sector--construcción" style="font-size:0.72rem;">' + escaparHtml(sesionUsuario.perfil) + ' · ' + escaparHtml(sesionUsuario.estado) + '</span>' +
            '  </div>' +
            '  <span class="badge-semaforo badge-semaforo--' + colorClase + '">' + estadoTexto + ' (' + st.porcentajeUso.toFixed(1) + '%)</span>' +
            '</div>' +
            '<div class="barra-progreso" style="margin-top:0.6rem;">' +
            '  <div class="barra-progreso__relleno barra-progreso__relleno--' + colorClase + '" style="width:' + Math.min(100, st.porcentajeUso) + '%;"></div>' +
            '</div>' +
            '<div class="semaforo-metricas-grid" style="margin-top:0.75rem;">' +
            '  <div class="semaforo-metrica-caja">' +
            '    <div class="semaforo-metrica-caja__label">Límite Autorizado</div>' +
            '    <div class="semaforo-metrica-caja__monto">' + usd(st.limite) + '</div>' +
            '  </div>' +
            '  <div class="semaforo-metrica-caja">' +
            '    <div class="semaforo-metrica-caja__label">Gastado Definitivo</div>' +
            '    <div class="semaforo-metrica-caja__monto">' + usd(st.gastado) + '</div>' +
            '  </div>' +
            '  <div class="semaforo-metrica-caja">' +
            '    <div class="semaforo-metrica-caja__label">Comprometido</div>' +
            '    <div class="semaforo-metrica-caja__monto">' + usd(st.comprometido) + '</div>' +
            '  </div>' +
            '  <div class="semaforo-metrica-caja" style="background-color:var(--color-exito-suave);">' +
            '    <div class="semaforo-metrica-caja__label" style="color:var(--color-exito);">Saldo Disponible</div>' +
            '    <div class="semaforo-metrica-caja__monto" style="color:var(--color-exito);">' + usd(st.saldoDisponible) + '</div>' +
            '  </div>' +
            '</div>' +
            '<div class="texto-secundario" style="font-size:0.78rem; margin-top:0.85rem; padding-top:0.5rem; border-top:1px solid var(--color-borde-subtil); display:flex; justify-content:space-between;">' +
            '  <span>Margen de maniobra restante:</span>' +
            '  <strong style="color:var(--color-texto); font-variant-numeric:tabular-nums;">' + (100 - Math.min(100, st.porcentajeUso)).toFixed(1) + '% disponible</strong>' +
            '</div>' +
            '</div>';
    } else {
        // Vista Supervisor Gobernación: lista de todas las entidades con semáforos
        html += '<div class="lista-semaforos-gobernacion">';
        for (var i = 0; i < usuarios.length; i++) {
            var u = usuarios[i];
            if (u.perfil === 'Gobernación') continue;
            var stu = calcularEstadoPresupuestoUsuario(u);

            html += '<div class="bloque-semaforo-usuario">' +
                '<div class="semaforo-header">' +
                '  <span><strong>' + escaparHtml(u.nombre) + '</strong> <small class="texto-secundario">(' + escaparHtml(u.estado) + ' · ' + escaparHtml(u.perfil) + ')</small></span>' +
                '  <span class="badge-semaforo badge-semaforo--' + stu.colorSemaforo + '">' + stu.porcentajeUso.toFixed(1) + '%</span>' +
                '</div>' +
                '<div class="barra-progreso">' +
                '  <div class="barra-progreso__relleno barra-progreso__relleno--' + stu.colorSemaforo + '" style="width:' + Math.min(100, stu.porcentajeUso) + '%;"></div>' +
                '</div>' +
                '<div class="semaforo-metricas-grid">' +
                '  <div class="semaforo-metrica-caja">' +
                '    <div class="semaforo-metrica-caja__label">Límite</div>' +
                '    <div class="semaforo-metrica-caja__monto">' + usd(stu.limite) + '</div>' +
                '  </div>' +
                '  <div class="semaforo-metrica-caja">' +
                '    <div class="semaforo-metrica-caja__label">Gastado</div>' +
                '    <div class="semaforo-metrica-caja__monto">' + usd(stu.gastado) + '</div>' +
                '  </div>' +
                '  <div class="semaforo-metrica-caja">' +
                '    <div class="semaforo-metrica-caja__label">Comprom.</div>' +
                '    <div class="semaforo-metrica-caja__monto">' + usd(stu.comprometido) + '</div>' +
                '  </div>' +
                '  <div class="semaforo-metrica-caja">' +
                '    <div class="semaforo-metrica-caja__label">Disponible</div>' +
                '    <div class="semaforo-metrica-caja__monto">' + usd(stu.saldoDisponible) + '</div>' +
                '  </div>' +
                '</div>' +
                '</div>';
        }
        html += '</div>';
    }

    contenedor.innerHTML = html;
}

// ============================================================
// 15. MÓDULO: HISTORIAL DE COTIZACIONES Y DUPLICACIÓN
// ============================================================

function renderizarModuloHistorial() {
    var cuerpo = document.getElementById('cuerpoTablaHistorial');
    var selectFiltro = document.getElementById('filtroEstadoHistorial');
    if (!cuerpo) return;

    var filtroEstado = selectFiltro ? selectFiltro.value : 'TODAS';
    var cotizaciones = obtenerCotizaciones();
    var esGobernacion = (sesionUsuario.perfil === 'Gobernación');

    cuerpo.innerHTML = '';
    var contador = 0;

    for (var i = 0; i < cotizaciones.length; i++) {
        var c = cotizaciones[i];

        if (!esGobernacion && c.usuarioId !== sesionUsuario.id) {
            continue;
        }

        if (filtroEstado !== 'TODAS' && c.estado !== filtroEstado) {
            continue;
        }

        contador++;
        var tr = document.createElement('tr');
        var claseEstado = 'estado estado--' + c.estado.toLowerCase();

        tr.innerHTML =
            '<td><strong>' + escaparHtml(c.correlativo) + '</strong></td>' +
            '<td>' + escaparHtml(c.fechaCreacion) + '</td>' +
            '<td>' + escaparHtml(c.nombreCliente) + '</td>' +
            '<td>' + escaparHtml(c.ciudadCompra) + '</td>' +
            '<td>' + usd(c.total) + '</td>' +
            '<td><span class="' + claseEstado + '">' + escaparHtml(c.estado) + '</span></td>' +
            '<td>' +
            '<button class="boton boton--secundario boton--sm" onclick="verDocumentoCotizacion(' + c.id + ')">' + icono('ojo', 14) + ' Ver</button> ' +
            '<button class="boton boton--primario boton--sm" onclick="duplicarCotizacionDesdeHistorial(' + c.id + ')" title="Crear una nueva cotización con estos mismos materiales">' + icono('duplicar', 14) + ' Duplicar</button> ' +
            (c.estado === 'BORRADOR' || c.estado === 'ENVIADA' ?
                '<button class="boton boton--peligro boton--sm" onclick="cancelarCotizacionHistorial(' + c.id + ')">' + icono('cerrar', 14) + ' Cancelar</button>' : '') +
            '</td>';
        cuerpo.appendChild(tr);
    }

    if (contador === 0) {
        cuerpo.innerHTML =
            '<tr><td colspan="7">' +
            '  <div class="estado-vacio">' +
            '    <div class="estado-vacio__icono">' + icono('carpeta', 36) + '</div>' +
            '    <div class="estado-vacio__titulo">No se encontraron cotizaciones</div>' +
            '    <div class="estado-vacio__descripcion">No hay registros con los filtros seleccionados o aún no has creado tu primer presupuesto.</div>' +
            '    <button type="button" class="boton boton--primario" onclick="cambiarPestana(\'cotizador\')" style="margin-top:1rem;">' + icono('plus', 14) + ' Iniciar Nueva Cotización</button>' +
            '  </div>' +
            '</td></tr>';
    }
}

/**
 * Duplica los datos de una cotización previa y los abre en el Asistente de Cotización.
 * Respeta rigurosamente la regla de que el usuario no puede cotizar si tiene una abierta.
 * @param {number} id - ID de la cotización a duplicar.
 */
function duplicarCotizacionDesdeHistorial(id) {
    var cotizaciones = obtenerCotizaciones();

    // 1. Verificar si el usuario tiene una cotización abierta
    var disp = verificarDisponibilidadNuevaCotizacion(sesionUsuario.id, cotizaciones);
    if (!disp.puede) {
        mostrarNotificacion('No puede duplicar: ya tiene la cotización ' + disp.cotizacionBloqueante.correlativo + ' en estado ' + disp.cotizacionBloqueante.estado + '.', 'advertencia');
        return;
    }

    // 2. Buscar la cotización objetivo
    var cot = null;
    for (var i = 0; i < cotizaciones.length; i++) {
        if (cotizaciones[i].id === id) {
            cot = cotizaciones[i];
            break;
        }
    }
    if (!cot) return;

    // 3. Cambiar a la pestaña de cotizador
    cambiarPestana('cotizador');

    // 4. Limpiar formulario previo para evitar mezcla de datos
    limpiarFormularioCotizador();

    // 5. Cargar datos en Paso 1
    var inpNombre = document.getElementById('inputNombreObra');
    var selectEstado = document.getElementById('selectEstadoObraCotizador');
    var inpNotas = document.getElementById('inputNotasObra');
    var selectCiudad = document.getElementById('selectCiudadCotizador');

    if (inpNombre) inpNombre.value = 'Copia de ' + (cot.nombreObra || cot.correlativo);
    if (selectEstado) selectEstado.value = cot.estadoObra;
    if (inpNotas) inpNotas.value = 'Duplicada a partir de ' + cot.correlativo;
    if (selectCiudad) selectCiudad.value = cot.ciudadCompra;

    // 6. Cargar cantidades en Paso 2
    for (var j = 0; j < cot.items.length; j++) {
        var it = cot.items[j];
        var inp = document.getElementById('cant_mat_' + it.materialId);
        if (inp) {
            inp.value = it.cantidad;
        }
    }

    // 7. Posicionar en Paso 2 para que el usuario pueda ajustar cantidades si lo desea
    pasoCotizadorActual = 2;
    renderizarPasoCotizador(2);
    actualizarTotalEnVivo();
    guardarBorradorActualEnStorage();

    mostrarNotificacion('Cotización ' + cot.correlativo + ' duplicada exitosamente en el Asistente.', 'exito');
}

function cancelarCotizacionHistorial(id) {
    mostrarModalConfirmacion(
        'Cancelar Cotización',
        '¿Seguro que desea cancelar esta cotización? Esta acción no se puede deshacer.',
        function () {
            var cotizaciones = obtenerCotizaciones();
            for (var i = 0; i < cotizaciones.length; i++) {
                if (cotizaciones[i].id === id) {
                    cotizaciones[i].estado = 'CANCELADA';
                    registrarEnBitacora(sesionUsuario.nombre, 'COTIZACION_CANCELADA', 'Cancelación de ' + cotizaciones[i].correlativo);
                    break;
                }
            }
            guardarCotizaciones(cotizaciones);
            renderizarModuloHistorial();
            mostrarNotificacion('Cotización cancelada.', 'info');
        },
        'Sí, cancelar',
        'Volver'
    );
}

// ============================================================
// 16. MÓDULO: SUPERVISIÓN GLOBAL (SOLO GOBERNACIÓN)
// ============================================================

function renderizarModuloSupervision() {
    var cuerpoRanking = document.getElementById('cuerpoTablaSupervisionRanking');
    var cuerpoPerfiles = document.getElementById('cuerpoTotalesPerfilSupervision');
    var cuerpoEstados = document.getElementById('cuerpoTotalesEstadoSupervision');
    if (!cuerpoRanking) return;

    var usuarios = obtenerUsuarios();
    var cotizaciones = obtenerCotizaciones();

    var ranking = calcularRankingSupervision(usuarios, cotizaciones);

    cuerpoRanking.innerHTML = '';
    for (var i = 0; i < ranking.length; i++) {
        var r = ranking[i];
        var tr = document.createElement('tr');
        tr.innerHTML =
            '<td><strong>#' + (i + 1) + '</strong></td>' +
            '<td>' + escaparHtml(r.nombre) + '</td>' +
            '<td>' + escaparHtml(r.perfil) + '</td>' +
            '<td>' + escaparHtml(r.estado) + '</td>' +
            '<td>' + r.cantCotizaciones + '</td>' +
            '<td>' + usd(r.montoAprobado) + '</td>' +
            '<td>' + usd(r.montoEntregado) + '</td>';
        cuerpoRanking.appendChild(tr);
    }

    var totales = calcularTotalesSupervision(cotizaciones);

    if (cuerpoPerfiles) {
        cuerpoPerfiles.innerHTML = '';
        var perfiles = ['Alcaldía', 'Empresa', 'Constructor', 'Gobernación'];
        for (var p = 0; p < perfiles.length; p++) {
            var perf = perfiles[p];
            var trP = document.createElement('tr');
            trP.innerHTML =
                '<td>' + escaparHtml(perf) + '</td>' +
                '<td><strong>' + usd(totales.porPerfil[perf] || 0) + '</strong></td>';
            cuerpoPerfiles.appendChild(trP);
        }
    }

    if (cuerpoEstados) {
        cuerpoEstados.innerHTML = '';
        for (var estado in totales.porEstado) {
            var trE = document.createElement('tr');
            trE.innerHTML =
                '<td>' + escaparHtml(estado) + '</td>' +
                '<td><strong>' + usd(totales.porEstado[estado]) + '</strong></td>';
            cuerpoEstados.appendChild(trE);
        }
    }
}

// ============================================================
// 17. MÓDULO: EXPORTAR, IMPORTAR Y MODO DEMOSTRACIÓN
// ============================================================

function exportarDatosJSON() {
    var paquete = {
        sistema: 'SICOP-VE',
        version: '2.0',
        fechaExportacion: obtenerFechaActual(),
        usuarios: obtenerUsuarios(),
        materiales: obtenerMateriales(),
        cotizaciones: obtenerCotizaciones(),
        bitacora: obtenerBitacora(),
        tasaBCV: obtenerTasaBCV()
    };

    var contenido = JSON.stringify(paquete, null, 2);
    descargarArchivoBlob(contenido, 'SICOP_VE_RESPALDO_' + Date.now() + '.json', 'application/json');

    registrarEnBitacora(sesionUsuario.nombre, 'RESPALDO_EXPORTADO', 'Descarga de respaldo completo del sistema en JSON.');
    mostrarNotificacion('Respaldo exportado exitosamente en JSON.', 'exito');
}

function exportarCotizacionesCSV() {
    var cotizaciones = obtenerCotizaciones();
    var csv = exportarCotizacionesACSV(cotizaciones);
    descargarArchivoBlob(csv, 'SICOP_VE_COTIZACIONES_' + Date.now() + '.csv', 'text/csv;charset=utf-8;');

    registrarEnBitacora(sesionUsuario.nombre, 'CSV_EXPORTADO', 'Exportación de historial de cotizaciones en formato CSV.');
    mostrarNotificacion('Cotizaciones exportadas exitosamente en CSV.', 'exito');
}

function descargarArchivoBlob(contenido, nombreArchivo, mimeType) {
    var blob = new Blob([contenido], { type: mimeType });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = nombreArchivo;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

function importarDatosJSON(evento) {
    var archivo = evento.target.files[0];
    if (!archivo) return;

    var lector = new FileReader();
    lector.onload = function (e) {
        var texto = e.target.result;
        var validacion = validarRespaldoJSON(texto);

        if (!validacion.valido) {
            mostrarNotificacion('Archivo de respaldo no válido: ' + validacion.error, 'error');
            return;
        }

        mostrarModalConfirmacion(
            'Restaurar Respaldo',
            '¿Está seguro de restaurar este respaldo? Se sobrescribirán los datos actuales.',
            function () {
                var datos = validacion.datos;
                guardarUsuarios(datos.usuarios);
                guardarMateriales(datos.materiales);
                guardarCotizaciones(datos.cotizaciones);
                if (Array.isArray(datos.bitacora)) {
                    escribirStorage(CLAVES_STORAGE.BITACORA, datos.bitacora);
                }
                if (datos.tasaBCV) {
                    guardarTasaBCV(datos.tasaBCV);
                }

                registrarEnBitacora(sesionUsuario ? sesionUsuario.nombre : 'Sistema', 'RESPALDO_IMPORTADO', 'Restauración exitosa de respaldo JSON.');
                location.reload();
            },
            'Sí, restaurar',
            'Cancelar'
        );
    };
    lector.readAsText(archivo);
}

function restablecerFabricaConConfirmacion() {
    mostrarModalConfirmacion(
        'Valores Iniciales de Fábrica',
        '¿ATENCIÓN: Desea borrar todos los cambios y restablecer la demostración de fábrica original?',
        function () {
            restablecerDatosFabrica();
            location.reload();
        },
        'Restablecer',
        'Cancelar'
    );
}

/**
 * Modo Demostración: Carga el conjunto completo de datos de ejemplo para clase.
 */
function ejecutarCargaDatosDemo() {
    var btn = document.getElementById('btnCargarDatosDemo');
    var textoOriginal = btn ? btn.textContent : '';
    if (btn) {
        btn.disabled = true;
        btn.textContent = 'Procesando...';
    }
    cargarDatosDemostracionCompletos();
    mostrarNotificacion('Datos de demostración para exposición cargados exitosamente.', 'exito');
    setTimeout(function () {
        if (btn) {
            btn.disabled = false;
            btn.textContent = textoOriginal;
        }
        location.reload();
    }, 600);
}

/**
 * Modo Demostración: Vacía todo el sistema para empezar desde cero una prueba en vivo.
 */
function ejecutarVaciadoTodoDemo() {
    mostrarModalConfirmacion(
        'Reiniciar Todo el Sistema',
        '¿Desea borrar todas las cotizaciones, materiales y bitácora para empezar una demostración en blanco?',
        function () {
            var btn = document.getElementById('btnVaciarTodoDemo');
            var textoOriginal = btn ? btn.textContent : '';
            if (btn) {
                btn.disabled = true;
                btn.textContent = 'Procesando...';
            }
            vaciarDatosSistema();
            mostrarNotificacion('Sistema reiniciado desde cero.', 'info');
            setTimeout(function () {
                if (btn) {
                    btn.disabled = false;
                    btn.textContent = textoOriginal;
                }
                location.reload();
            }, 600);
        },
        'Sí, borrar todo',
        'Cancelar'
    );
}

// ============================================================
// 18. MÓDULO: BITÁCORA Y ALERTAS TEMPRANAS
// ============================================================

function renderizarModuloBitacora() {
    var cuerpoBitacora = document.getElementById('cuerpoTablaBitacora');
    var contenedorAlertas = document.getElementById('contenedorTarjetasAlertas');

    var usuarios = obtenerUsuarios();
    var cotizaciones = obtenerCotizaciones();
    var bitacora = obtenerBitacora();

    if (contenedorAlertas) {
        var alertas = detectarAlertasSistema(usuarios, cotizaciones);
        contenedorAlertas.innerHTML = '';

        if (alertas.length === 0) {
            contenedorAlertas.innerHTML = '<div class="aviso aviso--exito">No se detectan anomalías ni alertas críticas en el sistema.</div>';
        } else {
            for (var a = 0; a < alertas.length; a++) {
                var al = alertas[a];
                var div = document.createElement('div');
                div.className = 'aviso ' + (al.nivel === 'critico' ? 'aviso--error' : 'aviso--advertencia');
                div.innerHTML = '<strong>' + escaparHtml(al.titulo) + '</strong>: ' + escaparHtml(al.mensaje) + ' <span class="texto-secundario" style="float:right;">' + escaparHtml(al.fecha) + '</span>';
                contenedorAlertas.appendChild(div);
            }
        }
    }

    if (cuerpoBitacora) {
        cuerpoBitacora.innerHTML = '';
        for (var b = 0; b < bitacora.length; b++) {
            var reg = bitacora[b];
            var tr = document.createElement('tr');
            tr.innerHTML =
                '<td>' + escaparHtml(reg.fecha) + '</td>' +
                '<td><strong>' + escaparHtml(reg.usuario) + '</strong></td>' +
                '<td><code>' + escaparHtml(reg.accion) + '</code></td>' +
                '<td>' + escaparHtml(reg.detalle) + '</td>';
            cuerpoBitacora.appendChild(tr);
        }

        if (bitacora.length === 0) {
            cuerpoBitacora.innerHTML =
                '<tr><td colspan="4">' +
                '  <div class="estado-vacio">' +
                '    <div class="estado-vacio__icono">' + icono('escudo', 36) + '</div>' +
                '    <div class="estado-vacio__titulo">Bitácora limpia</div>' +
                '    <div class="estado-vacio__descripcion">No se registran eventos auditados aún.</div>' +
                '  </div>' +
                '</td></tr>';
        }
    }
}

// ============================================================
// 19. CONEXIÓN DE EVENTOS DE INTERFAZ
// ============================================================

function conectarEventosGenerales() {
    // 1. Evento de Login
    var formLogin = document.getElementById('formLogin');
    if (formLogin) {
        formLogin.addEventListener('submit', function (e) {
            e.preventDefault();
            var usuarioInput = document.getElementById('inputUsuarioLogin').value.trim();
            var claveInput = document.getElementById('inputClaveLogin').value.trim();

            var usuarios = obtenerUsuarios();
            var encontrado = null;

            for (var i = 0; i < usuarios.length; i++) {
                if (usuarios[i].usuario === usuarioInput && usuarios[i].clave === claveInput) {
                    encontrado = usuarios[i];
                    break;
                }
            }

            if (encontrado) {
                sesionUsuario = encontrado;
                guardarSesionActual(encontrado);
                registrarEnBitacora(encontrado.nombre, 'INICIO_SESION', 'Ingreso exitoso al sistema.');
                mostrarAplicacion();
            } else {
                mostrarNotificacion('Credenciales inválidas. Compruebe usuario y clave o use el selector de demostración.', 'error');
            }
        });
    }

    // Selector rápido de usuario en login
    var selRapido = document.getElementById('selectorUsuarioRapido');
    if (selRapido) {
        selRapido.addEventListener('change', function () {
            var usrVal = this.value;
            if (!usrVal) return;
            var usuarios = obtenerUsuarios();
            for (var i = 0; i < usuarios.length; i++) {
                if (usuarios[i].usuario === usrVal) {
                    document.getElementById('inputUsuarioLogin').value = usuarios[i].usuario;
                    document.getElementById('inputClaveLogin').value = usuarios[i].clave;
                    break;
                }
            }
        });
    }

    // Botón Cerrar Sesión
    var btnCerrar = document.getElementById('btnCerrarSesion');
    if (btnCerrar) {
        btnCerrar.addEventListener('click', function () {
            if (sesionUsuario) {
                registrarEnBitacora(sesionUsuario.nombre, 'CIERRE_SESION', 'Salida del sistema.');
            }
            cerrarSesionStorage();
            sesionUsuario = null;
            mostrarPantallaLogin();
        });
    }

    // Selector de Moneda Global en el Encabezado
    var selectMoneda = document.getElementById('selectorMonedaGlobal');
    if (selectMoneda) {
        selectMoneda.addEventListener('change', function () {
            cambiarMonedaGlobal(this.value);
        });
    }

    // Botones de navegación de módulos
    var botonesNav = document.querySelectorAll('.nav-btn');
    for (var b = 0; b < botonesNav.length; b++) {
        botonesNav[b].addEventListener('click', function () {
            var modulo = this.getAttribute('data-modulo');
            if (modulo) cambiarPestana(modulo);
        });
    }

    // Calculadora: cambio de tipo de obra y cálculos
    var selTipoCalc = document.getElementById('calcTipoObra');
    if (selTipoCalc) {
        selTipoCalc.addEventListener('change', function () {
            cambiarCamposCalculadora(this.value);
        });
    }
    var btnCalcObra = document.getElementById('btnCalcularObra');
    if (btnCalcObra) {
        btnCalcObra.addEventListener('click', ejecutarCalculoObra);
    }
    var btnTransf = document.getElementById('btnTransferirACotizador');
    if (btnTransf) {
        btnTransf.addEventListener('click', transferirEstimacionACotizador);
    }

    // Asistente: Botón Atrás y Siguiente
    var btnAtrasAsistente = document.getElementById('btnAtrasAsistente');
    if (btnAtrasAsistente) {
        btnAtrasAsistente.addEventListener('click', retrocederPasoCotizador);
    }
    var btnSigAsistente = document.getElementById('btnSiguienteAsistente');
    if (btnSigAsistente) {
        btnSigAsistente.addEventListener('click', avanzarPasoCotizador);
    }

    // Asistente: Banner de borrador guardado
    var btnContBorrador = document.getElementById('btnContinuarBorrador');
    if (btnContBorrador) {
        btnContBorrador.addEventListener('click', continuarBorradorGuardado);
    }
    var btnDescBorrador = document.getElementById('btnDescartarBorradorGuardado');
    if (btnDescBorrador) {
        btnDescBorrador.addEventListener('click', descartarBorradorGuardado);
    }

    // Asistente: Botón para ir a calculadora desde Paso 2
    var btnCalcPaso2 = document.getElementById('btnIrACalculadoraDesdePaso2');
    if (btnCalcPaso2) {
        btnCalcPaso2.addEventListener('click', function () {
            cambiarPestana('calculadora');
        });
    }

    // Asistente: Botones de plantillas de obra
    var botonesPlantillas = document.querySelectorAll('.btn-plantilla');
    for (var p = 0; p < botonesPlantillas.length; p++) {
        botonesPlantillas[p].addEventListener('click', function () {
            var clave = this.getAttribute('data-plantilla');
            if (clave) aplicarPlantillaObra(clave);
        });
    }

    // Asistente: Reactividad en cambio de ciudad, tasa y estado para total en vivo
    var selectCiudad = document.getElementById('selectCiudadCotizador');
    if (selectCiudad) {
        selectCiudad.addEventListener('change', function () {
            actualizarTotalEnVivo();
            programarGuardadoBorrador();
        });
    }
    var inputTasa = document.getElementById('inputTasaBCVCotizador');
    if (inputTasa) {
        inputTasa.addEventListener('input', function () {
            actualizarTotalEnVivo();
            programarGuardadoBorrador();
        });
    }
    var selectEstadoObra = document.getElementById('selectEstadoObraCotizador');
    if (selectEstadoObra) {
        selectEstadoObra.addEventListener('change', function () {
            actualizarTotalEnVivo();
            programarGuardadoBorrador();
        });
    }
    var inputNombreObra = document.getElementById('inputNombreObra');
    if (inputNombreObra) {
        inputNombreObra.addEventListener('input', function () {
            limpiarErrorCampo('inputNombreObra');
            programarGuardadoBorrador();
        });
    }
    var inputNotasObra = document.getElementById('inputNotasObra');
    if (inputNotasObra) {
        inputNotasObra.addEventListener('input', function () {
            programarGuardadoBorrador();
        });
    }

    // Modal Rechazo de Aprobaciones: Cancelar y Confirmar
    var btnCancRechazo = document.getElementById('btnCancelarRechazo');
    if (btnCancRechazo) {
        btnCancRechazo.addEventListener('click', cerrarTodosLosModales);
    }
    var btnConfRechazo = document.getElementById('btnConfirmarRechazo');
    if (btnConfRechazo) {
        btnConfRechazo.addEventListener('click', confirmarRechazoDesdeModal);
    }

    // Asistente Paso 3: Botón ¿Cómo se calculó esto?
    var btnComoSeCalc = document.getElementById('btnComoSeCalculoCotizador');
    if (btnComoSeCalc) {
        btnComoSeCalc.addEventListener('click', function () {
            abrirModalComoSeCalculo();
        });
    }

    // Modal Pedagógico: Cerrar
    var btnCerrarComoSeCalc = document.getElementById('btnCerrarModalComoSeCalculo');
    if (btnCerrarComoSeCalc) {
        btnCerrarComoSeCalc.addEventListener('click', cerrarModalComoSeCalculo);
    }
    var btnEntendidoComoSeCalc = document.getElementById('btnEntendidoModalComoSeCalculo');
    if (btnEntendidoComoSeCalc) {
        btnEntendidoComoSeCalc.addEventListener('click', cerrarModalComoSeCalculo);
    }

    // Modal Confirmación: Conectar Aceptar y Cancelar
    var btnOkModal = document.getElementById('btnAceptarModalConfirmacion');
    if (btnOkModal) {
        btnOkModal.addEventListener('click', function () {
            if (typeof accionConfirmacionModal === 'function') {
                var cb = accionConfirmacionModal;
                cerrarModalConfirmacion();
                cb();
            } else {
                cerrarModalConfirmacion();
            }
        });
    }
    var btnCancelModal = document.getElementById('btnCancelarModalConfirmacion');
    if (btnCancelModal) {
        btnCancelModal.addEventListener('click', cerrarModalConfirmacion);
    }

    // Asistente Paso 4: Botones finales
    var btnGuardarBorrador = document.getElementById('btnGuardarBorrador');
    if (btnGuardarBorrador) {
        btnGuardarBorrador.addEventListener('click', function () {
            guardarCotizacionComo('BORRADOR');
        });
    }
    var btnEnviarGobernacion = document.getElementById('btnEnviarGobernacion');
    if (btnEnviarGobernacion) {
        btnEnviarGobernacion.addEventListener('click', function () {
            guardarCotizacionComo('ENVIADA');
        });
    }
    var btnCancelarCot = document.getElementById('btnCancelarCotizacion');
    if (btnCancelarCot) {
        btnCancelarCot.addEventListener('click', cancelarCotizacionEnEdicion);
    }
    var btnVerDoc = document.getElementById('btnVerDocImprimible');
    if (btnVerDoc) {
        btnVerDoc.addEventListener('click', function () {
            if (cotizacionEnEdicion) {
                documentoActual = cotizacionEnEdicion;
                renderizarDocumentoImprimible(documentoActual);
            }
        });
    }
    var btnShareWA = document.getElementById('btnCompartirWhatsApp');
    if (btnShareWA) {
        btnShareWA.addEventListener('click', compartirDocumentoWhatsApp);
    }

    // Accesibilidad WCAG 2.1 AA: Escape para cerrar modales y focus trap para navegación por teclado
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' || e.keyCode === 27) {
            cerrarTodosLosModales();
        }
        if (e.key === 'Tab' || e.keyCode === 9) {
            var modalActivo = document.querySelector('.modal-fondo:not(.oculto), .vista-imprimible:not(.oculto)');
            if (!modalActivo) return;
            var interactivos = modalActivo.querySelectorAll('button:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])');
            if (!interactivos.length) return;
            var primero = interactivos[0];
            var ultimo = interactivos[interactivos.length - 1];
            if (e.shiftKey) {
                if (document.activeElement === primero) {
                    e.preventDefault();
                    ultimo.focus();
                }
            } else {
                if (document.activeElement === ultimo) {
                    e.preventDefault();
                    primero.focus();
                }
            }
        }
    });

    // Filtro de historial
    var filtroHistorial = document.getElementById('filtroEstadoHistorial');
    if (filtroHistorial) {
        filtroHistorial.addEventListener('change', renderizarModuloHistorial);
    }

    // Importación de archivo JSON
    var inputImportar = document.getElementById('inputImportarJSON');
    if (inputImportar) {
        inputImportar.addEventListener('change', importarDatosJSON);
    }

    // Modo Demostración en Respaldo
    var btnCargarDemo = document.getElementById('btnCargarDatosDemo');
    if (btnCargarDemo) {
        btnCargarDemo.addEventListener('click', ejecutarCargaDatosDemo);
    }
    var btnVaciarDemo = document.getElementById('btnVaciarTodoDemo');
    if (btnVaciarDemo) {
        btnVaciarDemo.addEventListener('click', ejecutarVaciadoTodoDemo);
    }

    // Botón Alternar Tema Claro / Oscuro
    var btnTema = document.getElementById('btnAlternarTema');
    if (btnTema) {
        btnTema.addEventListener('click', alternarTema);
    }

    // Botón Menú Móvil (Hamburguesa) y Overlay
    var btnMenu = document.getElementById('btnMenuMovil');
    var overlay = document.getElementById('sidebarOverlay');
    if (btnMenu) {
        btnMenu.addEventListener('click', function () {
            var sidebar = document.getElementById('sidebarApp');
            if (sidebar) sidebar.classList.toggle('abierta');
            if (overlay) overlay.classList.toggle('activa');
        });
    }
    if (overlay) {
        overlay.addEventListener('click', function () {
            var sidebar = document.getElementById('sidebarApp');
            if (sidebar) sidebar.classList.remove('abierta');
            overlay.classList.remove('activa');
        });
    }
}

// Iniciar al cargar el documento
document.addEventListener('DOMContentLoaded', inicializarInterfaz);
