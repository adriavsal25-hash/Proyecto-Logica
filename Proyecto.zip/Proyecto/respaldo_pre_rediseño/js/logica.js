/* ============================================================
   SICOP-VE — Capa de Lógica de Negocio Pura (js/logica.js)
   Proyecto Final: Lógica y Programación I
   
   REGLA ESTRICTA DE DISEÑO:
   Este archivo NO interactúa con el DOM (sin document.getElementById,
   sin alertas, sin elementos HTML). Contiene únicamente funciones puras,
   algoritmos, cálculos matemáticos y validaciones de reglas de negocio.
   ============================================================ */

// ============================================================
// 1. FUNCIONES AUXILIARES DE FORMATO Y FECHA
// ============================================================

/**
 * Formatea un número en formato venezolano estándar:
 * - Separador de miles: punto (.)
 * - Separador de decimales: coma (,)
 * - Ejemplo: 1234.56 -> "1.234,56"
 * 
 * Si se especifica el parámetro 'moneda', antepone el símbolo respectivo:
 * - 'USD' -> "$1.234,56"
 * - 'Bs'  -> "Bs. 1.234,56"
 * 
 * @param {number} numero - Monto a formatear.
 * @param {string} [moneda] - Opcional ('USD' o 'Bs').
 * @param {number} [tasaBCV] - Tasa opcional para convertir de USD a Bs en vivo.
 * @returns {string} Texto formateado con dos decimales y separadores venezolanos.
 */
function formatearMoneda(numero, moneda, tasaBCV) {
    var valor = Number(numero);
    if (isNaN(valor)) valor = 0;
    if (moneda === 'Bs' && tasaBCV && !isNaN(Number(tasaBCV)) && Number(tasaBCV) > 0) {
        valor = valor * Number(tasaBCV);
    }
    var signo = valor < 0 ? '-' : '';
    valor = Math.abs(valor);
    var partes = valor.toFixed(2).split('.');
    var entero = partes[0].replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    var cifra = entero + ',' + partes[1];
    if (moneda === 'USD' || moneda === '$') return signo + '$' + cifra;
    if (moneda === 'Bs' || moneda === 'VES') return signo + 'Bs. ' + cifra;
    return signo + cifra;
}

/**
 * Funciones auxiliares centralizadas para formateo monetario estándar.
 */
function usd(n) { return formatearMoneda(n, 'USD'); }
function bs(n) { return formatearMoneda(n, 'Bs'); }
function bsDesdeUSD(n, tasa) { return formatearMoneda(n, 'Bs', tasa); }

/**
 * Valida los datos iniciales de la obra en el Paso 1 del asistente de cotización.
 * @param {string} nombreObra - Nombre descriptivo de la obra.
 * @param {string} estadoObra - Estado geográfico de destino.
 * @returns {Object} { valido: boolean, error?: string, campo?: string }
 */
function validarPasoObra(nombreObra, estadoObra) {
    if (!nombreObra || typeof nombreObra !== 'string' || nombreObra.trim().length < 4) {
        return {
            valido: false,
            campo: 'nombreObra',
            error: 'El nombre de la obra debe tener al menos 4 caracteres. Ejemplo: "Reparación Escuela San José".'
        };
    }
    if (!estadoObra || !FACTORES_FLETE[estadoObra]) {
        return {
            valido: false,
            campo: 'estadoObra',
            error: 'Seleccione un estado de destino válido para calcular el flete terrestre.'
        };
    }
    return { valido: true };
}

/**
 * Valida un campo individual de cantidad de material con mensaje claro y sugerencia concreta.
 * @param {*} valor - Valor ingresado en el input.
 * @param {string} nombreMaterial - Nombre del material para contextualizar el error.
 * @returns {Object} { valido: boolean, cantidad: number, error?: string }
 */
function validarCampoCantidad(valor, nombreMaterial) {
    var str = String(valor === undefined || valor === null ? '' : valor).trim();
    if (str === '') {
        return { valido: true, cantidad: 0 };
    }
    var num = Number(str);
    if (isNaN(num)) {
        return {
            valido: false,
            cantidad: 0,
            error: 'Escribe solo números, sin letras para "' + nombreMaterial + '". Ejemplo: 10.'
        };
    }
    if (num < 0) {
        return {
            valido: false,
            cantidad: 0,
            error: 'La cantidad para "' + nombreMaterial + '" no puede ser negativa. Debe ser mayor que cero. Prueba con 10.'
        };
    }
    if (num !== Math.floor(num)) {
        return {
            valido: false,
            cantidad: 0,
            error: 'La cantidad para "' + nombreMaterial + '" debe ser un número entero, sin decimales.'
        };
    }
    return { valido: true, cantidad: num };
}

/**
 * Retorna la fecha y hora actual en formato estándar DD/MM/AAAA HH:MM.
 * @returns {string} Fecha formateada.
 */
function obtenerFechaActual() {
    var ahora = new Date();
    var dia = String(ahora.getDate()).padStart(2, '0');
    var mes = String(ahora.getMonth() + 1).padStart(2, '0');
    var anio = ahora.getFullYear();
    var horas = String(ahora.getHours()).padStart(2, '0');
    var minutos = String(ahora.getMinutes()).padStart(2, '0');
    return dia + '/' + mes + '/' + anio + ' ' + horas + ':' + minutos;
}

/**
 * Calcula la diferencia en días entre una fecha dada (DD/MM/AAAA) y la fecha de hoy.
 * @param {string} fechaTexto - Cadena de fecha en formato "DD/MM/AAAA...".
 * @returns {number} Número de días transcurridos.
 */
function calcularDiasTranscurridos(fechaTexto) {
    if (!fechaTexto || typeof fechaTexto !== 'string') {
        return 0;
    }
    var partesFecha = fechaTexto.split(' ')[0].split('/');
    if (partesFecha.length < 3) {
        return 0;
    }
    var dia = parseInt(partesFecha[0], 10);
    var mes = parseInt(partesFecha[1], 10) - 1;
    var anio = parseInt(partesFecha[2], 10);

    var fechaOrigen = new Date(anio, mes, dia);
    var hoy = new Date();
    var diferenciaMilisegundos = hoy.getTime() - fechaOrigen.getTime();
    return Math.floor(diferenciaMilisegundos / (1000 * 60 * 60 * 24));
}

// ============================================================
// 2. ALGORITMO DE ORDENAMIENTO BURBUJA MANUAL (SIN sort())
// ============================================================

/**
 * Ordena un arreglo de objetos según una propiedad numérica o alfabética.
 * Algoritmo clásico de intercambio de burbuja implementado a mano.
 * @param {Array<Object>} arreglo - Arreglo a ordenar.
 * @param {string} propiedad - Nombre de la propiedad del objeto a comparar.
 * @param {boolean} ascendente - true: menor a mayor, false: mayor a menor.
 * @returns {Array<Object>} Nuevo arreglo ordenado (no muta el original).
 */
function ordenarBurbuja(arreglo, propiedad, ascendente) {
    if (!Array.isArray(arreglo)) {
        return [];
    }

    // Se realiza una copia superficial para no alterar el arreglo original
    var copia = [];
    for (var k = 0; k < arreglo.length; k++) {
        copia.push(arreglo[k]);
    }

    var n = copia.length;
    var huboIntercambio;

    // Ciclo exterior: pasadas por el arreglo
    for (var i = 0; i < n - 1; i++) {
        huboIntercambio = false;

        // Ciclo interior: comparaciones adyacentes
        for (var j = 0; j < n - 1 - i; j++) {
            var valA = copia[j][propiedad];
            var valB = copia[j + 1][propiedad];

            var debeIntercambiar = false;
            if (ascendente) {
                if (valA > valB) {
                    debeIntercambiar = true;
                }
            } else {
                if (valA < valB) {
                    debeIntercambiar = true;
                }
            }

            if (debeIntercambiar) {
                var temporal = copia[j];
                copia[j] = copia[j + 1];
                copia[j + 1] = temporal;
                huboIntercambio = true;
            }
        }

        // Optimización: si en una pasada no hubo intercambios, la lista ya está ordenada
        if (!huboIntercambio) {
            break;
        }
    }

    return copia;
}

/**
 * Obtiene la ciudad de compra más económica disponible usando burbuja.
 * @param {Array<Object>} ciudades - Lista de ciudades con factor de precio.
 * @returns {Object} La ciudad con menor factor de costo.
 */
function obtenerCiudadMasBarata(ciudades) {
    var ciudadesOrdenadas = ordenarBurbuja(ciudades, 'factor', true);
    return ciudadesOrdenadas[0];
}

// ============================================================
// 3. MÓDULO 1: ESTIMADOR / CALCULADORA DE MATERIALES
// ============================================================

/**
 * Aplica el margen de desperdicio editable a una cantidad base y redondea hacia arriba.
 * @param {number} cantidadBase - Cantidad teórica neta.
 * @param {number} porcentajeDesperdicio - Margen en % (por ej. 10 para 10%).
 * @returns {number} Cantidad ajustada redondeada con Math.ceil.
 */
function aplicarDesperdicio(cantidadBase, porcentajeDesperdicio) {
    var pct = Number(porcentajeDesperdicio);
    if (isNaN(pct) || pct < 0) {
        pct = 10;
    }
    return Math.ceil(cantidadBase * (1 + (pct / 100)));
}

/**
 * Estima los materiales requeridos para levantar una pared de bloques.
 * Reglas:
 * - Área = largo * alto (m²)
 * - Bloques base = m² * 12.5 unidades
 * - Cemento base = m² * 0.20 sacos de pega
 * @param {number} largo - Longitud en metros.
 * @param {number} alto - Altura en metros.
 * @param {number} desperdicioPct - Porcentaje de desperdicio (defecto 10%).
 * @returns {Object} Estimación calculada.
 */
function calcularMaterialesPared(largo, alto, desperdicioPct) {
    var l = Number(largo);
    var h = Number(alto);
    if (isNaN(l) || l <= 0 || isNaN(h) || h <= 0) {
        return { valido: false, error: 'Dimensiones de pared inválidas (deben ser mayores a 0).' };
    }

    var area = l * h;
    var bloquesBase = area * 12.5;
    var cementoBase = area * 0.20;

    var bloquesFinal = aplicarDesperdicio(bloquesBase, desperdicioPct);
    var cementoFinal = aplicarDesperdicio(cementoBase, desperdicioPct);

    return {
        valido: true,
        tipo: 'Pared de Bloques',
        areaM2: area,
        desperdicioPct: desperdicioPct,
        resultados: [
            { nombreBusqueda: 'Bloque', cantidad: bloquesFinal, unidad: 'Unidades', detalle: '12.5 bloques/m²' },
            { nombreBusqueda: 'Cemento', cantidad: cementoFinal, unidad: 'Sacos 42.5kg', detalle: '0.20 sacos/m² (pega)' }
        ]
    };
}

/**
 * Estima los materiales para una losa de concreto armado.
 * Reglas:
 * - Volumen = largo * ancho * espesor (m³)
 * - Cemento base = m³ * 7 sacos
 * - Cabilla base = (largo * ancho) * cabillaPorM2
 * @param {number} largo - Largo en metros.
 * @param {number} ancho - Ancho en metros.
 * @param {number} espesor - Espesor en metros (ej: 0.15 para 15 cm).
 * @param {number} cabillaPorM2 - Barras de cabilla por m² (editable, ej: 1.2).
 * @param {number} desperdicioPct - Margen de desperdicio.
 * @returns {Object} Estimación calculada.
 */
function calcularMaterialesLosa(largo, ancho, espesor, cabillaPorM2, desperdicioPct) {
    var l = Number(largo);
    var a = Number(ancho);
    var e = Number(espesor);
    var cPorM2 = Number(cabillaPorM2);

    if (isNaN(l) || l <= 0 || isNaN(a) || a <= 0 || isNaN(e) || e <= 0) {
        return { valido: false, error: 'Dimensiones de losa inválidas (deben ser mayores a 0).' };
    }
    if (isNaN(cPorM2) || cPorM2 < 0) {
        cPorM2 = 1.2;
    }

    var area = l * a;
    var volumen = area * e;
    var cementoBase = volumen * 7.0;
    var cabillasBase = area * cPorM2;

    var cementoFinal = aplicarDesperdicio(cementoBase, desperdicioPct);
    var cabillasFinal = aplicarDesperdicio(cabillasBase, desperdicioPct);

    return {
        valido: true,
        tipo: 'Losa de Concreto',
        areaM2: area,
        volumenM3: volumen,
        desperdicioPct: desperdicioPct,
        resultados: [
            { nombreBusqueda: 'Cemento', cantidad: cementoFinal, unidad: 'Sacos 42.5kg', detalle: '7 sacos/m³' },
            { nombreBusqueda: 'Cabilla', cantidad: cabillasFinal, unidad: 'Barras 12m', detalle: cPorM2 + ' barras/m²' }
        ]
    };
}

/**
 * Estima los tubos necesarios para un tramo de tubería.
 * Cada tubo estándar mide 6 metros.
 * @param {number} metrosLineales - Metros lineales de recorrido.
 * @param {number} desperdicioPct - Desperdicio.
 * @returns {Object} Estimación calculada.
 */
function calcularMaterialesTuberia(metrosLineales, desperdicioPct) {
    var m = Number(metrosLineales);
    if (isNaN(m) || m <= 0) {
        return { valido: false, error: 'Metros de tramo inválidos (debe ser mayor a 0).' };
    }

    var tubosBase = m / 6.0;
    var tubosFinal = aplicarDesperdicio(tubosBase, desperdicioPct);

    return {
        valido: true,
        tipo: 'Instalación de Tubería',
        metrosLineales: m,
        desperdicioPct: desperdicioPct,
        resultados: [
            { nombreBusqueda: 'Tubería', cantidad: tubosFinal, unidad: 'Tubos 6m', detalle: '6 m por tramo' }
        ]
    };
}

// ============================================================
// 4. MÓDULO 2: MOTOR DE CÁLCULO DE COTIZACIÓN
// ============================================================

/**
 * Valida un conjunto de cantidades ingresadas por el usuario.
 * @param {Array<Object>} materialesCatalogo - Lista completa de materiales activos.
 * @param {Object} mapaCantidades - Objeto { [materialId]: cantidad }.
 * @returns {Object} { valido: boolean, error?: string, itemsValidos?: Array }
 */
function validarCantidadesCotizacion(materialesCatalogo, mapaCantidades) {
    var items = [];
    var sumaCantidades = 0;

    for (var i = 0; i < materialesCatalogo.length; i++) {
        var mat = materialesCatalogo[i];
        if (!mat.activo) {
            continue;
        }

        var valIngresado = mapaCantidades[mat.id];
        // Si no está definido o es string vacío, se asume 0
        if (valIngresado === undefined || valIngresado === null || String(valIngresado).trim() === '') {
            continue;
        }

        var resCampo = validarCampoCantidad(valIngresado, mat.nombre);
        if (!resCampo.valido) {
            return {
                valido: false,
                materialId: mat.id,
                error: resCampo.error
            };
        }

        if (resCampo.cantidad > 0) {
            items.push({
                materialId: mat.id,
                nombre: mat.nombre,
                unidad: mat.unidad,
                sector: mat.sector,
                precioBase: mat.precioBase,
                cantidad: resCampo.cantidad
            });
            sumaCantidades += resCampo.cantidad;
        }
    }

    if (items.length === 0 || sumaCantidades === 0) {
        return { valido: false, error: 'Debe ingresar al menos un material con cantidad mayor a cero.' };
    }

    return { valido: true, items: items };
}

/**
 * Realiza el cálculo matemático completo de una cotización conforme a la normativa:
 * 1. Subtotal = Suma(cantidad * precioBase * factorCiudad)
 * 2. Flete = Subtotal * (factorFlete - 1)
 * 3. Descuento = (Subtotal + Flete) * porcentajeDescuentoPerfil
 * 4. Neto = (Subtotal + Flete) - Descuento
 * 5. Contingencia = Neto * 0.05
 * 6. IVA = (Neto + Contingencia) * 0.16
 * 7. Total USD = Neto + Contingencia + IVA
 * 8. Total Bs = Total USD * tasaBCV
 *
 * @param {Array<Object>} itemsValidados - Materiales con cantidad y precioBase.
 * @param {Object} ciudadCompra - Ciudad seleccionada (por defecto la más barata).
 * @param {Object} usuario - Usuario solicitante (perfil y estado).
 * @param {number} tasaCambio - Tasa referencial en Bs./USD.
 * @returns {Object} Desglose detallado del presupuesto.
 */
function calcularPresupuestoCotizacion(itemsValidados, ciudadCompra, usuario, tasaCambio) {
    var factorCiudad = ciudadCompra.factor;
    var factorFlete = FACTORES_FLETE[usuario.estado] || 1.00;
    var pctDescuento = DESCUENTOS_POR_PERFIL[usuario.perfil] || 0.00;

    var subtotal = 0;
    var itemsConPrecio = [];

    for (var i = 0; i < itemsValidados.length; i++) {
        var itm = itemsValidados[i];
        // Precio ajustado por el factor de la ciudad
        var precioUnitarioAjustado = itm.precioBase * factorCiudad;
        var totalLinea = itm.cantidad * precioUnitarioAjustado;
        subtotal += totalLinea;

        itemsConPrecio.push({
            materialId: itm.materialId,
            nombre: itm.nombre,
            unidad: itm.unidad,
            sector: itm.sector,
            cantidad: itm.cantidad,
            precioUnitario: precioUnitarioAjustado,
            total: totalLinea
        });
    }

    // Regla 2: Flete
    var flete = subtotal * (factorFlete - 1.00);

    // Regla 3: Descuento institucional por perfil
    var baseDescuento = subtotal + flete;
    var descuento = baseDescuento * pctDescuento;

    // Regla 4: Monto Neto
    var neto = baseDescuento - descuento;

    // Regla 5: Contingencia técnica (5%)
    var contingencia = neto * CONTINGENCIA;

    // Regla 6: IVA (16% sobre neto + contingencia)
    var baseImponible = neto + contingencia;
    var iva = baseImponible * IVA;

    // Regla 7: Total final en USD
    var totalUSD = baseImponible + iva;

    // Regla 8: Conversión a Bolívares
    var tasa = Number(tasaCambio);
    if (isNaN(tasa) || tasa <= 0) {
        tasa = TASA_BCV_INICIAL;
    }
    var totalBs = totalUSD * tasa;

    return {
        ciudadCompra: ciudadCompra.nombre,
        factorCiudad: factorCiudad,
        estadoDestino: usuario.estado,
        factorFlete: factorFlete,
        perfilUsuario: usuario.perfil,
        descuentoPct: pctDescuento,
        items: itemsConPrecio,
        subtotal: subtotal,
        flete: flete,
        descuento: descuento,
        neto: neto,
        contingencia: contingencia,
        iva: iva,
        total: totalUSD,
        tasaBCV: tasa,
        totalBs: totalBs
    };
}

// ============================================================
// 5. MÓDULO 5: CONTROL PRESUPUESTARIO Y REGLAS DE FLUJO
// ============================================================

/**
 * REGLA ESTRICTA: Un usuario no puede iniciar una nueva cotización
 * si actualmente posee alguna en estado 'BORRADOR' o 'ENVIADA'.
 * Queda liberado si sus cotizaciones están en APROBADA, RECHAZADA, ENTREGADA o CANCELADA.
 * @param {number} usuarioId - ID del usuario.
 * @param {Array<Object>} todasCotizaciones - Colección de cotizaciones.
 * @returns {Object} { puede: boolean, cotizacionBloqueante?: Object }
 */
function verificarDisponibilidadNuevaCotizacion(usuarioId, todasCotizaciones) {
    for (var i = 0; i < todasCotizaciones.length; i++) {
        var cot = todasCotizaciones[i];
        if (cot.usuarioId === usuarioId) {
            if (cot.estado === 'BORRADOR' || cot.estado === 'ENVIADA') {
                return {
                    puede: false,
                    cotizacionBloqueante: cot
                };
            }
        }
    }
    return { puede: true };
}

/**
 * Calcula el semáforo y estado de ejecución presupuestaria de un usuario.
 * Límite de gasto:
 * - Alcaldía / Gobernación: Presupuesto institucional asignado.
 * - Empresa / Constructor: Cupo = Ingreso mensual * multiplicador de nivel.
 * Semáforo:
 * - < 60%: Normal (Verde)
 * - 60% a < 90%: Alerta (Ámbar)
 * - >= 90%: Crítico (Rojo)
 *
 * @param {Object} usuario - Objeto usuario.
 * @returns {Object} Resumen presupuestario con semáforo y fondos disponibles.
 */
function calcularEstadoPresupuestoUsuario(usuario) {
    var limite = usuario.limiteGasto;
    // Si no está fijado explícitamente, se calcula por perfil
    if (limite === undefined || limite === null) {
        if (usuario.perfil === 'Empresa' || usuario.perfil === 'Constructor') {
            var mult = MULTIPLICADORES_NIVEL[usuario.nivel] || 1.5;
            limite = (usuario.ingresoMensual || 0) * mult;
        } else {
            limite = usuario.presupuestoMensual || 0;
        }
    }

    var gastado = Number(usuario.gastado) || 0;
    var comprometido = Number(usuario.comprometido) || 0;
    var totalComprometidoYGastado = gastado + comprometido;
    var saldoDisponible = limite - totalComprometidoYGastado;

    var porcentajeUso = limite > 0 ? (totalComprometidoYGastado / limite) * 100 : 0;

    var semaforo = 'normal';
    var colorSemaforo = 'verde';
    var textoSemaforo = 'Presupuesto Saludable';

    if (porcentajeUso >= 90) {
        semaforo = 'critico';
        colorSemaforo = 'rojo';
        textoSemaforo = 'Nivel Crítico de Consumo';
    } else if (porcentajeUso >= 60) {
        semaforo = 'alerta';
        colorSemaforo = 'ambar';
        textoSemaforo = 'Alerta de Presupuesto';
    }

    return {
        usuarioId: usuario.id,
        nombre: usuario.nombre,
        perfil: usuario.perfil,
        limite: limite,
        gastado: gastado,
        comprometido: comprometido,
        saldoDisponible: saldoDisponible,
        porcentajeUso: Math.min(100, Math.max(0, porcentajeUso)),
        semaforo: semaforo,
        colorSemaforo: colorSemaforo,
        textoSemaforo: textoSemaforo
    };
}

/**
 * Evalúa y procesa la aprobación de una cotización por parte de la Gobernación.
 * Regla de aprobación:
 * Verifica que Total Cotización <= (Límite - Gastado - Comprometido).
 * Si alcanza: suma a 'comprometido' y pasa a APROBADA.
 * Si no alcanza: RECHAZA la aprobación y calcula el déficit.
 *
 * @param {Object} cotizacion - Cotización a evaluar.
 * @param {Object} usuarioSolicitante - Usuario dueño de la cotización.
 * @returns {Object} Resultado de la evaluación.
 */
function evaluarAprobacionCotizacion(cotizacion, usuarioSolicitante) {
    var estadoPto = calcularEstadoPresupuestoUsuario(usuarioSolicitante);
    var montoRequerido = cotizacion.total;

    if (montoRequerido <= estadoPto.saldoDisponible) {
        return {
            aprobable: true,
            saldoDisponibleActual: estadoPto.saldoDisponible,
            nuevoSaldoEstimado: estadoPto.saldoDisponible - montoRequerido,
            nuevoComprometidoEstimado: estadoPto.comprometido + montoRequerido
        };
    } else {
        var faltante = montoRequerido - estadoPto.saldoDisponible;
        return {
            aprobable: false,
            saldoDisponibleActual: estadoPto.saldoDisponible,
            montoRequerido: montoRequerido,
            faltante: faltante,
            motivo: 'Fondos insuficientes. El monto requerido ($' + formatearMoneda(montoRequerido) +
                    ') supera el saldo disponible del usuario ($' + formatearMoneda(estadoPto.saldoDisponible) +
                    '). Déficit presupuestario: $' + formatearMoneda(faltante) + '.'
        };
    }
}

// ============================================================
// 6. MÓDULO 4: REGLAS DEL CATÁLOGO EDITABLE (GOBERNACIÓN)
// ============================================================

/**
 * Valida la creación o actualización de un material en el catálogo.
 * Reglas:
 * - Precio base > 0
 * - Nombre no repetido (distinto a sí mismo si se está editando)
 * - Sector válido
 * @param {Object} material - Objeto material a validar.
 * @param {Array<Object>} catalogoActual - Catálogo de materiales existentes.
 * @param {number} [idIgnorar] - ID del material que se está editando (opcional).
 * @returns {Object} { valido: boolean, error?: string }
 */
function validarMaterialCatalogo(material, catalogoActual, idIgnorar) {
    if (!material.nombre || material.nombre.trim().length < 3) {
        return { valido: false, error: 'El nombre del material debe tener al menos 3 caracteres.' };
    }

    var precio = Number(material.precioBase);
    if (isNaN(precio) || precio <= 0) {
        return { valido: false, error: 'El precio base debe ser un número mayor a cero.' };
    }

    if (!material.unidad || material.unidad.trim() === '') {
        return { valido: false, error: 'Debe especificar la unidad de medida.' };
    }

    // Verificar nombre único
    var nombreNormalizado = material.nombre.trim().toLowerCase();
    for (var i = 0; i < catalogoActual.length; i++) {
        var m = catalogoActual[i];
        if (idIgnorar && m.id === idIgnorar) {
            continue;
        }
        if (m.nombre.trim().toLowerCase() === nombreNormalizado) {
            return { valido: false, error: 'Ya existe un material registrado con el nombre "' + material.nombre + '".' };
        }
    }

    return { valido: true };
}

// ============================================================
// 7. MÓDULO 9: SUPERVISIÓN Y RANKINGS (ALGORITMO BURBUJA)
// ============================================================

/**
 * Genera el ranking de usuarios por monto aprobado de mayor a menor,
 * utilizando el algoritmo de ordenamiento burbuja escrito a mano.
 *
 * @param {Array<Object>} usuarios - Lista de usuarios.
 * @param {Array<Object>} cotizaciones - Todas las cotizaciones registradas.
 * @returns {Array<Object>} Lista de usuarios ordenada descendentemente por monto aprobado.
 */
function calcularRankingSupervision(usuarios, cotizaciones) {
    var resumenUsuarios = [];

    for (var i = 0; i < usuarios.length; i++) {
        var u = usuarios[i];
        var totalAprobado = 0;
        var totalEntregado = 0;
        var cantCotizaciones = 0;

        for (var j = 0; j < cotizaciones.length; j++) {
            var c = cotizaciones[j];
            if (c.usuarioId === u.id) {
                cantCotizaciones++;
                if (c.estado === 'APROBADA' || c.estado === 'ENTREGADA') {
                    totalAprobado += c.total;
                }
                if (c.estado === 'ENTREGADA') {
                    totalEntregado += c.total;
                }
            }
        }

        resumenUsuarios.push({
            id: u.id,
            nombre: u.nombre,
            perfil: u.perfil,
            estado: u.estado,
            cantCotizaciones: cantCotizaciones,
            montoAprobado: totalAprobado,
            montoEntregado: totalEntregado,
            comprometido: u.comprometido || 0,
            gastado: u.gastado || 0,
            limiteGasto: u.limiteGasto || 0
        });
    }

    // Ordenamiento descendente por montoAprobado con burbuja
    return ordenarBurbuja(resumenUsuarios, 'montoAprobado', false);
}

/**
 * Consolida los totales de inversión aprobada por perfil y por estado geográfico.
 * @param {Array<Object>} cotizaciones - Colección de cotizaciones.
 * @returns {Object} { porPerfil: Object, porEstado: Object, porSector: Object }
 */
function calcularTotalesSupervision(cotizaciones) {
    var porPerfil = { 'Alcaldía': 0, 'Empresa': 0, 'Constructor': 0, 'Gobernación': 0 };
    var porEstado = {};
    var porSector = { 'Construcción': 0, 'Energía': 0, 'Agua': 0, 'Vialidad': 0 };

    for (var i = 0; i < cotizaciones.length; i++) {
        var c = cotizaciones[i];
        // Solo contabilizamos cotizaciones vigentes (APROBADA o ENTREGADA)
        if (c.estado === 'APROBADA' || c.estado === 'ENTREGADA') {
            if (porPerfil[c.perfil] !== undefined) {
                porPerfil[c.perfil] += c.total;
            }

            if (!porEstado[c.estadoObra]) {
                porEstado[c.estadoObra] = 0;
            }
            porEstado[c.estadoObra] += c.total;

            // Desglose por sector
            if (Array.isArray(c.items)) {
                for (var k = 0; k < c.items.length; k++) {
                    var itm = c.items[k];
                    var sec = itm.sector || 'Construcción';
                    if (porSector[sec] !== undefined) {
                        porSector[sec] += itm.total;
                    }
                }
            }
        }
    }

    return {
        porPerfil: porPerfil,
        porEstado: porEstado,
        porSector: porSector
    };
}

// ============================================================
// 8. MÓDULO 10: GENERACIÓN DE ENLACE WHATSAPP
// ============================================================

/**
 * Genera el enlace oficial de WhatsApp Web/App (wa.me) con el resumen formal.
 * @param {Object} cotizacion - Cotización a compartir.
 * @returns {string} URL formateada con mensaje predeterminado codificado.
 */
function generarEnlaceWhatsApp(cotizacion) {
    var mensaje = '🏗️ *SICOP-VE | Resumen de Cotización*\n\n' +
        '📄 *N° Documento:* ' + cotizacion.correlativo + '\n' +
        '👤 *Cliente:* ' + cotizacion.nombreCliente + ' (' + cotizacion.perfil + ')\n' +
        '📍 *Destino:* ' + cotizacion.estadoObra + '\n' +
        '🛒 *Ciudad de Compra:* ' + cotizacion.ciudadCompra + '\n' +
        '📅 *Emisión:* ' + cotizacion.fechaCreacion + '\n' +
        '⏳ *Vigencia:* ' + cotizacion.validezDias + ' días hábiles\n' +
        '📌 *Estado Actual:* ' + cotizacion.estado + '\n\n' +
        '💰 *TOTAL USD:* $' + formatearMoneda(cotizacion.total) + '\n' +
        '🇻🇪 *TOTAL BS:* Bs. ' + formatearMoneda(cotizacion.totalBs) + ' (Tasa: ' + cotizacion.tasaBCV + ')\n\n' +
        '_Emitido por SICOP-VE: Sistema de Control Presupuestario para Obras en Venezuela._';

    return 'https://wa.me/?text=' + encodeURIComponent(mensaje);
}

// ============================================================
// 9. MÓDULO 11: EXPORTACIÓN A CSV Y VALIDACIÓN DE IMPORTACIÓN
// ============================================================

/**
 * Transforma la lista de cotizaciones en una cadena con formato CSV (valores separados por coma).
 * @param {Array<Object>} cotizaciones - Arreglo de cotizaciones.
 * @returns {string} Contenido CSV con encabezados.
 */
function exportarCotizacionesACSV(cotizaciones) {
    var encabezados = [
        'Correlativo',
        'Fecha',
        'Cliente',
        'Perfil',
        'Estado_Obra',
        'Ciudad_Compra',
        'Estado',
        'Subtotal_USD',
        'Flete_USD',
        'Descuento_USD',
        'IVA_USD',
        'Total_USD',
        'Tasa_BCV',
        'Total_Bs'
    ];

    var filas = [encabezados.join(',')];

    for (var i = 0; i < cotizaciones.length; i++) {
        var c = cotizaciones[i];
        var fila = [
            '"' + c.correlativo + '"',
            '"' + c.fechaCreacion + '"',
            '"' + c.nombreCliente.replace(/"/g, '""') + '"',
            '"' + c.perfil + '"',
            '"' + c.estadoObra + '"',
            '"' + c.ciudadCompra + '"',
            '"' + c.estado + '"',
            c.subtotal.toFixed(2),
            c.flete.toFixed(2),
            c.descuento.toFixed(2),
            c.iva.toFixed(2),
            c.total.toFixed(2),
            c.tasaBCV.toFixed(2),
            c.totalBs.toFixed(2)
        ];
        filas.push(fila.join(','));
    }

    return filas.join('\r\n');
}

/**
 * Valida la integridad de un archivo de respaldo JSON antes de restaurar datos.
 * @param {string} contenidoJSON - Texto del archivo JSON cargado.
 * @returns {Object} { valido: boolean, error?: string, datos?: Object }
 */
function validarRespaldoJSON(contenidoJSON) {
    try {
        var datos = JSON.parse(contenidoJSON);
        if (!datos || typeof datos !== 'object') return { valido: false, error: 'El archivo JSON no tiene una estructura de objeto válida.' };
        if (!Array.isArray(datos.usuarios) || datos.usuarios.length === 0) return { valido: false, error: 'El respaldo no contiene usuarios válidos.' };
        if (!Array.isArray(datos.materiales) || datos.materiales.length === 0) return { valido: false, error: 'El respaldo no contiene materiales válidos.' };
        if (!Array.isArray(datos.cotizaciones)) return { valido: false, error: 'El respaldo no contiene la colección de cotizaciones.' };
        var u = datos.usuarios[0];
        if (!u.id || !u.usuario || !u.clave || !u.nombre || !u.perfil) return { valido: false, error: 'Los usuarios del respaldo no tienen la estructura esperada (id, usuario, clave, nombre, perfil).' };
        var m = datos.materiales[0];
        if (!m.id || !m.nombre || typeof m.precioBase !== 'number') return { valido: false, error: 'Los materiales del respaldo no tienen la estructura esperada (id, nombre, precioBase).' };
        for (var i = 0; i < datos.cotizaciones.length; i++) {
            var c = datos.cotizaciones[i];
            if (!c.id || !c.correlativo || !c.estado || typeof c.total !== 'number') return { valido: false, error: 'La cotización #' + (i + 1) + ' del respaldo no tiene los campos obligatorios.' };
        }
        return { valido: true, datos: datos };
    } catch (e) {
        return { valido: false, error: 'Error al interpretar el archivo JSON: ' + e.message };
    }
}

// ============================================================
// 10. MÓDULO 12: DETECCIÓN DE ALERTAS TEMPRANAS
// ============================================================

/**
 * Identifica alertas críticas en el sistema:
 * 1. Usuarios con más del 90% de su límite presupuestario consumido.
 * 2. Cotizaciones en estado 'ENVIADA' con más de 5 días hábiles esperando revisión.
 *
 * @param {Array<Object>} usuarios - Lista de usuarios.
 * @param {Array<Object>} cotizaciones - Lista de cotizaciones.
 * @returns {Array<Object>} Lista de alertas detectadas.
 */
function detectarAlertasSistema(usuarios, cotizaciones) {
    var alertas = [];

    // Alerta de usuarios con sobregiro o límite crítico
    for (var i = 0; i < usuarios.length; i++) {
        var u = usuarios[i];
        var st = calcularEstadoPresupuestoUsuario(u);
        if (st.porcentajeUso >= 90) {
            alertas.push({
                tipo: 'PRESUPUESTO_CRITICO',
                nivel: 'critico',
                titulo: 'Presupuesto Crítico: ' + u.nombre,
                mensaje: 'Ha consumido el ' + st.porcentajeUso.toFixed(1) + '% de su límite ($' +
                         formatearMoneda(st.gastado + st.comprometido) + ' de $' + formatearMoneda(st.limite) + ').',
                usuario: u,
                fecha: obtenerFechaActual()
            });
        }
    }

    // Alerta de cotizaciones pendientes por más de 5 días
    for (var j = 0; j < cotizaciones.length; j++) {
        var c = cotizaciones[j];
        if (c.estado === 'ENVIADA') {
            var dias = calcularDiasTranscurridos(c.fechaCreacion);
            if (dias >= 5) {
                alertas.push({
                    tipo: 'COTIZACION_DEMORADA',
                    nivel: 'alerta',
                    titulo: 'Revisión Pendiente: ' + c.correlativo,
                    mensaje: 'La cotización de ' + c.nombreCliente + ' lleva ' + dias + ' días esperando aprobación.',
                    fecha: c.fechaCreacion
                });
            }
        }
    }

    return alertas;
}

// ============================================================
// 11. DESGLOSE PEDAGÓGICO DE CÁLCULO DOCENTE
// ============================================================

/**
 * Desglosa la explicación matemática paso a paso de una cotización para fines docentes.
 * Muestra las fórmulas con los números reales aplicados en cada renglón.
 * @param {Object} cotizacion - Cotización completa con todos sus campos calculados.
 * @returns {Array<Object>} Lista de pasos pedagógicos con fórmulas y valores reales.
 */
function desglosarPasosCalculoPedagogico(cotizacion) {
    var p = [];

    // Paso 1: Subtotal
    p.push({
        paso: 1,
        titulo: 'Subtotal con Factor de Ciudad Proveedora',
        formula: 'Subtotal = Σ (Cantidad × Precio Base × Factor Ciudad)',
        detalle: 'Comprado en ' + cotizacion.ciudadCompra + ' con factor regional de ' + cotizacion.factorCiudad.toFixed(2) + '.',
        resultado: '$' + formatearMoneda(cotizacion.subtotal)
    });

    // Paso 2: Flete
    var fletePct = ((cotizacion.factorFlete - 1) * 100).toFixed(0);
    p.push({
        paso: 2,
        titulo: 'Flete Terrestre hacia Estado ' + cotizacion.estadoObra,
        formula: 'Flete = Subtotal × (Factor Flete - 1.00) = $' + formatearMoneda(cotizacion.subtotal) + ' × (' + cotizacion.factorFlete.toFixed(2) + ' - 1.00)',
        detalle: 'Recargo logístico por destino (' + cotizacion.estadoObra + '): ' + fletePct + '%.',
        resultado: '$' + formatearMoneda(cotizacion.flete)
    });

    // Paso 3: Descuento
    var descPct = (cotizacion.descuentoPct * 100).toFixed(0);
    p.push({
        paso: 3,
        titulo: 'Descuento Institucional (' + cotizacion.perfil + ')',
        formula: 'Descuento = (Subtotal + Flete) × ' + descPct + '% = ($' + formatearMoneda(cotizacion.subtotal) + ' + $' + formatearMoneda(cotizacion.flete) + ') × ' + cotizacion.descuentoPct,
        detalle: 'Beneficio fiscal institucional según el perfil (' + cotizacion.perfil + '): ' + descPct + '%.',
        resultado: '-$' + formatearMoneda(cotizacion.descuento)
    });

    // Paso 4: Monto Neto
    p.push({
        paso: 4,
        titulo: 'Monto Neto Imponible',
        formula: 'Neto = (Subtotal + Flete) - Descuento',
        detalle: 'Monto base de operación antes de imprevistos e impuestos.',
        resultado: '$' + formatearMoneda(cotizacion.neto)
    });

    // Paso 5: Contingencia
    p.push({
        paso: 5,
        titulo: 'Margen de Contingencia Técnica (5%)',
        formula: 'Contingencia = Neto × 5% = $' + formatearMoneda(cotizacion.neto) + ' × 0.05',
        detalle: 'Reserva legal técnica para variaciones y fluctuaciones de obra en Venezuela.',
        resultado: '$' + formatearMoneda(cotizacion.contingencia)
    });

    // Paso 6: IVA
    p.push({
        paso: 6,
        titulo: 'I.V.A. Ley Tributaria (16%)',
        formula: 'IVA = (Neto + Contingencia) × 16% = ($' + formatearMoneda(cotizacion.neto) + ' + $' + formatearMoneda(cotizacion.contingencia) + ') × 0.16',
        detalle: 'Alícuota general vigente del Impuesto al Valor Agregado.',
        resultado: '$' + formatearMoneda(cotizacion.iva)
    });

    // Paso 7: Total Final y Conversión
    p.push({
        paso: 7,
        titulo: 'Total General en Divisas y Bolívares',
        formula: 'Total USD = Neto + Contingencia + IVA | Total Bs. = Total USD × Tasa BCV',
        detalle: 'Tasa oficial referencial aplicada: ' + cotizacion.tasaBCV.toFixed(2) + ' Bs./USD.',
        resultado: '$' + formatearMoneda(cotizacion.total) + ' USD  =  Bs. ' + formatearMoneda(cotizacion.totalBs)
    });

    return p;
}

/**
 * Sanitiza texto para prevenir inyecciones XSS en el DOM.
 * @param {*} str - Texto a escapar.
 * @returns {string} Texto seguro para HTML.
 */
function escaparHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

