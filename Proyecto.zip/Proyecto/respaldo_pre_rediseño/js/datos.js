/* ============================================================
   SICOP-VE — Capa de Datos (js/datos.js)
   Proyecto Final: Lógica y Programación I
   
   Responsabilidad:
   - Constantes fijas del negocio (IVA, contingencia, factores de flete, etc.)
   - Datos iniciales de demostración (usuarios, materiales, ciudades)
   - Funciones auxiliares para interactuar con localStorage
   ============================================================ */

// ============================================================
// 1. CONSTANTES DEL NEGOCIO
// ============================================================

/** Porcentaje de Impuesto al Valor Agregado (16%) */
var IVA = 0.16;

/** Porcentaje de contingencia sobre el monto neto (5%) */
var CONTINGENCIA = 0.05;

/** Días de validez legal de una cotización emitida */
var DIAS_VIGENCIA_COTIZACION = 15;

/** Tasa de cambio oficial referencial inicial (Bs./USD) */
var TASA_BCV_INICIAL = 36.50;

/** Descuento según el perfil del usuario solicitante */
var DESCUENTOS_POR_PERFIL = {
    'Alcaldía': 0.04,
    'Gobernación': 0.04,
    'Empresa': 0.02,
    'Constructor': 0.00
};

/**
 * Factores de flete terrestre según el estado destino de la obra.
 * Flete = Subtotal * (factor - 1)
 */
var FACTORES_FLETE = {
    'Distrito Capital': 1.00,
    'Miranda':          1.03,
    'Carabobo':         1.04,
    'Lara':             1.06,
    'Zulia':            1.08,
    'Mérida':           1.12,
    'Amazonas':         1.25
};

/**
 * Ciudades de compra y sus factores de costo relativo.
 */
var CIUDADES_BASE = [
    { nombre: 'Caracas',       factor: 1.05 },
    { nombre: 'Valencia',      factor: 0.95 },
    { nombre: 'Maracay',       factor: 0.97 },
    { nombre: 'Barquisimeto',  factor: 1.00 },
    { nombre: 'Maracaibo',     factor: 1.04 },
    { nombre: 'Puerto Ordaz',  factor: 0.90 }
];

/**
 * Multiplicadores para calcular cupo de financiamiento/límite de crédito:
 * Cupo = Ingreso mensual * multiplicador
 */
var MULTIPLICADORES_NIVEL = {
    1: 1.5,
    2: 2.5,
    3: 4.0,
    4: 6.0,
    5: 9.0
};

/** Sectores de infraestructura disponibles en el catálogo */
var SECTORES_CATALOGO = ['Construcción', 'Energía', 'Agua', 'Vialidad'];

/**
 * Plantillas preconfiguradas con materiales típicos para obras comunes en Venezuela.
 * Los valores son referenciales y totalmente editables por el usuario.
 */
var PLANTILLAS_OBRA = {
    'casa_pequena': {
        clave: 'casa_pequena',
        nombre: 'Casa pequeña',
        iconoId: 'casa',
        descripcion: 'Construcción básica de vivienda de 50 m² (bloques, cemento, cabilla y tubería).',
        cantidades: {
            1: 40,  // Cemento (sacos)
            2: 20,  // Cabilla (barras)
            3: 350, // Bloques (unidades)
            4: 50,  // Cable eléctrico (metros)
            7: 10   // Tubería PVC (tubos)
        },
        materiales: [
            { materialId: 1, cantidad: 40 },
            { materialId: 2, cantidad: 20 },
            { materialId: 3, cantidad: 350 },
            { materialId: 4, cantidad: 50 },
            { materialId: 7, cantidad: 10 }
        ]
    },
    'cerca_perimetral': {
        clave: 'cerca_perimetral',
        nombre: 'Cerca perimetral',
        iconoId: 'muro',
        descripcion: 'Cerramiento de linderos con bloques y vigas de corona (bloques, cemento y cabilla).',
        cantidades: {
            1: 45,  // Cemento
            2: 25,  // Cabilla
            3: 600  // Bloques
        },
        materiales: [
            { materialId: 1, cantidad: 45 },
            { materialId: 2, cantidad: 25 },
            { materialId: 3, cantidad: 600 }
        ]
    },
    'rehabilitar_calle': {
        clave: 'rehabilitar_calle',
        nombre: 'Rehabilitar una calle',
        iconoId: 'calle',
        descripcion: 'Bacheo, repavimentación y drenajes menores (asfalto, luminarias y tuberías).',
        cantidades: {
            8: 25, // Asfalto
            5: 8,  // Luminarias LED
            7: 12  // Tubería PVC
        },
        materiales: [
            { materialId: 8, cantidad: 25 },
            { materialId: 5, cantidad: 8 },
            { materialId: 7, cantidad: 12 }
        ]
    },
    'alumbrado_publico': {
        clave: 'alumbrado_publico',
        nombre: 'Alumbrado público',
        iconoId: 'luz',
        descripcion: 'Electrificación e iluminación vial eficiente (luminarias, cableado y paneles solares).',
        cantidades: {
            4: 350, // Cable eléctrico
            5: 20,  // Luminarias LED
            6: 10   // Paneles solares
        },
        materiales: [
            { materialId: 4, cantidad: 350 },
            { materialId: 5, cantidad: 20 },
            { materialId: 6, cantidad: 10 }
        ]
    },
    'sistema_agua': {
        clave: 'sistema_agua',
        nombre: 'Sistema de agua',
        iconoId: 'agua',
        descripcion: 'Aducción y red de distribución de agua potable (tuberías PVC y obras de concreto).',
        cantidades: {
            1: 30, // Cemento
            7: 50  // Tubería PVC
        },
        materiales: [
            { materialId: 1, cantidad: 30 },
            { materialId: 7, cantidad: 50 }
        ]
    }
};

// ============================================================
// 2. DATOS INICIALES DE DEMOSTRACIÓN
// ============================================================

/**
 * 6 usuarios representativos con perfiles, estados, niveles y credenciales.
 * ACLARATORIA DIDÁCTICA: En producción las contraseñas se almacenan con
 * funciones hash y salting en un servidor seguro; este arreglo es solo
 * para fines pedagógicos y de defensa académica.
 */
var USUARIOS_INICIALES = [
    {
        id: 1,
        usuario: 'alcaldia_libertador',
        clave: '1234',
        nombre: 'María González',
        perfil: 'Alcaldía',
        estado: 'Distrito Capital',
        ingresoMensual: 35000.00,
        nivel: 3,
        limiteGasto: 35000.00, // Presupuesto asignado
        gastado: 8500.00,
        comprometido: 4200.00
    },
    {
        id: 2,
        usuario: 'constructora_valencia',
        clave: '1234',
        nombre: 'Carlos Rodríguez',
        perfil: 'Empresa',
        estado: 'Carabobo',
        ingresoMensual: 6000.00,
        nivel: 4,
        limiteGasto: 36000.00, // 6000 * 6.0
        gastado: 14500.00,
        comprometido: 6800.00
    },
    {
        id: 3,
        usuario: 'maestro_martinez',
        clave: '1234',
        nombre: 'José Martínez',
        perfil: 'Constructor',
        estado: 'Zulia',
        ingresoMensual: 2200.00,
        nivel: 2,
        limiteGasto: 5500.00, // 2200 * 2.5
        gastado: 1200.00,
        comprometido: 0.00
    },
    {
        id: 4,
        usuario: 'gobernacion_miranda',
        clave: 'admin123',
        nombre: 'Ing. Ana Pérez',
        perfil: 'Gobernación', // Supervisor / Aprobador
        estado: 'Miranda',
        ingresoMensual: 90000.00,
        nivel: 5,
        limiteGasto: 90000.00,
        gastado: 32000.00,
        comprometido: 15400.00
    },
    {
        id: 5,
        usuario: 'vialidad_merida',
        clave: '1234',
        nombre: 'Luis Hernández',
        perfil: 'Empresa',
        estado: 'Mérida',
        ingresoMensual: 4500.00,
        nivel: 1,
        limiteGasto: 6750.00, // 4500 * 1.5
        gastado: 5800.00,
        comprometido: 400.00 // Supera el 90% (Alerta crítica)
    },
    {
        id: 6,
        usuario: 'alcaldia_iribarren',
        clave: '1234',
        nombre: 'Pedro Castillo',
        perfil: 'Alcaldía',
        estado: 'Lara',
        ingresoMensual: 20000.00,
        nivel: 2,
        limiteGasto: 20000.00,
        gastado: 7000.00,
        comprometido: 2500.00
    }
];

/**
 * Catálogo base de materiales con sectores e historial de auditoría de precio.
 */
var MATERIALES_INICIALES = [
    {
        id: 1,
        nombre: 'Cemento Portland Tipo I',
        sector: 'Construcción',
        unidad: 'Saco 42.5 kg',
        precioBase: 8.50,
        pesoKg: 42.5,
        activo: true,
        historialPrecios: [
            { fecha: '15/09/2024 10:00', precioAnterior: 8.00, precioNuevo: 8.50, usuario: 'Ing. Ana Pérez' }
        ]
    },
    {
        id: 2,
        nombre: 'Cabilla Estriada 1/2 pulgada',
        sector: 'Construcción',
        unidad: 'Barra 12m',
        precioBase: 12.00,
        pesoKg: 11.9,
        activo: true,
        historialPrecios: []
    },
    {
        id: 3,
        nombre: 'Bloque de Arcilla 15cm',
        sector: 'Construcción',
        unidad: 'Unidad',
        precioBase: 0.85,
        pesoKg: 6.5,
        activo: true,
        historialPrecios: []
    },
    {
        id: 4,
        nombre: 'Cable Eléctrico THW #12',
        sector: 'Energía',
        unidad: 'Metro',
        precioBase: 2.30,
        pesoKg: 0.05,
        activo: true,
        historialPrecios: []
    },
    {
        id: 5,
        nombre: 'Luminaria LED Vial 100W',
        sector: 'Energía',
        unidad: 'Unidad',
        precioBase: 45.00,
        pesoKg: 2.8,
        activo: true,
        historialPrecios: []
    },
    {
        id: 6,
        nombre: 'Panel Solar Monocristalino 450W',
        sector: 'Energía',
        unidad: 'Unidad',
        precioBase: 180.00,
        pesoKg: 21.0,
        activo: true,
        historialPrecios: []
    },
    {
        id: 7,
        nombre: 'Tubería PVC Presión 2 pulgadas',
        sector: 'Agua',
        unidad: 'Tubo 6m',
        precioBase: 14.50,
        pesoKg: 3.2,
        activo: true,
        historialPrecios: []
    },
    {
        id: 8,
        nombre: 'Mezcla Asfáltica en Caliente',
        sector: 'Vialidad',
        unidad: 'Tonelada',
        precioBase: 95.00,
        pesoKg: 1000.0,
        activo: true,
        historialPrecios: []
    }
];

/**
 * Cotizaciones iniciales para demostrar histórico y estados del flujo.
 */
var COTIZACIONES_INICIALES = [
    {
        id: 1,
        correlativo: 'COT-0001',
        usuarioId: 1,
        nombreCliente: 'María González',
        perfil: 'Alcaldía',
        estadoObra: 'Distrito Capital',
        ciudadCompra: 'Puerto Ordaz',
        factorCiudad: 0.90,
        factorFlete: 1.00,
        descuentoPct: 0.04,
        fechaCreacion: '20/10/2024 09:30',
        validezDias: 15,
        estado: 'ENTREGADA',
        items: [
            { materialId: 1, nombre: 'Cemento Portland Tipo I', cantidad: 300, precioUnitario: 7.65, total: 2295.00, sector: 'Construcción' },
            { materialId: 3, nombre: 'Bloque de Arcilla 15cm', cantidad: 2000, precioUnitario: 0.765, total: 1530.00, sector: 'Construcción' }
        ],
        subtotal: 3825.00,
        flete: 0.00,
        descuento: 153.00,
        neto: 3672.00,
        contingencia: 183.60,
        iva: 616.90,
        total: 4472.50,
        tasaBCV: 36.50,
        totalBs: 163246.25,
        motivoRechazo: ''
    },
    {
        id: 2,
        correlativo: 'COT-0002',
        usuarioId: 2,
        nombreCliente: 'Carlos Rodríguez',
        perfil: 'Empresa',
        estadoObra: 'Carabobo',
        ciudadCompra: 'Puerto Ordaz',
        factorCiudad: 0.90,
        factorFlete: 1.04,
        descuentoPct: 0.02,
        fechaCreacion: '28/10/2024 14:15',
        validezDias: 15,
        estado: 'APROBADA',
        items: [
            { materialId: 2, nombre: 'Cabilla Estriada 1/2 pulgada', cantidad: 250, precioUnitario: 10.80, total: 2700.00, sector: 'Construcción' },
            { materialId: 7, nombre: 'Tubería PVC Presión 2 pulgadas', cantidad: 80, precioUnitario: 13.05, total: 1044.00, sector: 'Agua' }
        ],
        subtotal: 3744.00,
        flete: 149.76,
        descuento: 77.88,
        neto: 3815.88,
        contingencia: 190.79,
        iva: 641.07,
        total: 4647.74,
        tasaBCV: 36.50,
        totalBs: 169642.51,
        motivoRechazo: ''
    },
    {
        id: 3,
        correlativo: 'COT-0003',
        usuarioId: 6,
        nombreCliente: 'Pedro Castillo',
        perfil: 'Alcaldía',
        estadoObra: 'Lara',
        ciudadCompra: 'Puerto Ordaz',
        factorCiudad: 0.90,
        factorFlete: 1.06,
        descuentoPct: 0.04,
        fechaCreacion: '01/11/2024 11:00',
        validezDias: 15,
        estado: 'ENVIADA',
        items: [
            { materialId: 5, nombre: 'Luminaria LED Vial 100W', cantidad: 40, precioUnitario: 40.50, total: 1620.00, sector: 'Energía' }
        ],
        subtotal: 1620.00,
        flete: 97.20,
        descuento: 68.69,
        neto: 1648.51,
        contingencia: 82.43,
        iva: 276.95,
        total: 2007.89,
        tasaBCV: 36.50,
        totalBs: 73288.00,
        motivoRechazo: ''
    }
];

/**
 * Bitácora inicial de auditoría.
 */
var BITACORA_INICIAL = [
    { fecha: '20/10/2024 09:30', usuario: 'María González', accion: 'COTIZACIÓN_CREADA', detalle: 'Creación de cotización COT-0001' },
    { fecha: '20/10/2024 11:00', usuario: 'Ing. Ana Pérez', accion: 'COTIZACIÓN_APROBADA', detalle: 'Aprobación de COT-0001 por USD 4,472.50' },
    { fecha: '22/10/2024 16:00', usuario: 'Ing. Ana Pérez', accion: 'COTIZACIÓN_ENTREGADA', detalle: 'Entrega final de COT-0001. Fondos transferidos a gastado.' },
    { fecha: '28/10/2024 14:15', usuario: 'Carlos Rodríguez', accion: 'COTIZACIÓN_CREADA', detalle: 'Creación de cotización COT-0002' },
    { fecha: '29/10/2024 10:20', usuario: 'Ing. Ana Pérez', accion: 'COTIZACIÓN_APROBADA', detalle: 'Aprobación de COT-0002 por USD 4,647.74' }
];

// ============================================================
// 3. FUNCIONES DE PERSISTENCIA (LOCALSTORAGE)
// ============================================================

var CLAVES_STORAGE = {
    USUARIOS: 'sicop_usuarios_v2',
    MATERIALES: 'sicop_materiales_v2',
    COTIZACIONES: 'sicop_cotizaciones_v2',
    BITACORA: 'sicop_bitacora_v2',
    SESION: 'sicop_sesion_v2',
    TASA: 'sicop_tasa_bcv_v2',
    CONTADOR: 'sicop_contador_correlativo_v2',
    BORRADOR_ASISTENTE: 'sicop_borrador_asistente_v2',
    MONEDA: 'sicop_moneda_activa_v2'
};

/**
 * Lee una colección de localStorage o inicializa con el valor por defecto.
 */
function leerStorage(clave, valorPorDefecto) {
    try {
        var valorGuardado = localStorage.getItem(clave);
        if (valorGuardado !== null) {
            return JSON.parse(valorGuardado);
        }
    } catch (error) {
        console.warn('Error leyendo de localStorage:', error);
    }
    return valorPorDefecto;
}

/**
 * Escribe una colección en localStorage.
 */
function escribirStorage(clave, valor) {
    try {
        localStorage.setItem(clave, JSON.stringify(valor));
    } catch (error) {
        console.error('Error escribiendo en localStorage:', error);
    }
}

/**
 * Obtiene la lista actual de usuarios.
 */
function obtenerUsuarios() {
    return leerStorage(CLAVES_STORAGE.USUARIOS, USUARIOS_INICIALES);
}

/**
 * Guarda la lista actualizada de usuarios.
 */
function guardarUsuarios(usuarios) {
    escribirStorage(CLAVES_STORAGE.USUARIOS, usuarios);
}

/**
 * Obtiene el catálogo de materiales.
 */
function obtenerMateriales() {
    return leerStorage(CLAVES_STORAGE.MATERIALES, MATERIALES_INICIALES);
}

/**
 * Guarda el catálogo de materiales.
 */
function guardarMateriales(materiales) {
    escribirStorage(CLAVES_STORAGE.MATERIALES, materiales);
}

/**
 * Obtiene todas las cotizaciones.
 */
function obtenerCotizaciones() {
    return leerStorage(CLAVES_STORAGE.COTIZACIONES, COTIZACIONES_INICIALES);
}

/**
 * Guarda la lista de cotizaciones.
 */
function guardarCotizaciones(cotizaciones) {
    escribirStorage(CLAVES_STORAGE.COTIZACIONES, cotizaciones);
}

/**
 * Obtiene el registro de auditoría / bitácora.
 */
function obtenerBitacora() {
    return leerStorage(CLAVES_STORAGE.BITACORA, BITACORA_INICIAL);
}

/**
 * Agrega una nueva entrada a la bitácora de auditoría.
 */
function registrarEnBitacora(usuarioNombre, accion, detalle) {
    var bitacora = obtenerBitacora();
    var nuevaEntrada = {
        fecha: obtenerFechaActual(),
        usuario: usuarioNombre || 'Sistema',
        accion: accion,
        detalle: detalle
    };
    bitacora.unshift(nuevaEntrada); // Insertar al inicio (cronológico descendente)
    // Limitar a los últimos 200 eventos para controlar memoria
    if (bitacora.length > 200) {
        bitacora.pop();
    }
    escribirStorage(CLAVES_STORAGE.BITACORA, bitacora);
}

/**
 * Obtiene la sesión del usuario conectado actualmente (o null).
 */
function obtenerSesionActual() {
    return leerStorage(CLAVES_STORAGE.SESION, null);
}

/**
 * Guarda la sesión del usuario activo.
 */
function guardarSesionActual(usuario) {
    escribirStorage(CLAVES_STORAGE.SESION, usuario);
}

/**
 * Cierra la sesión activa.
 */
function cerrarSesionStorage() {
    localStorage.removeItem(CLAVES_STORAGE.SESION);
}

/**
 * Obtiene la tasa de cambio vigente.
 */
function obtenerTasaBCV() {
    var tasa = localStorage.getItem(CLAVES_STORAGE.TASA);
    if (tasa !== null && !isNaN(parseFloat(tasa))) {
        return parseFloat(tasa);
    }
    return TASA_BCV_INICIAL;
}

/**
 * Guarda una nueva tasa de cambio.
 */
function guardarTasaBCV(tasa) {
    localStorage.setItem(CLAVES_STORAGE.TASA, String(tasa));
}

/**
 * Obtiene el siguiente número correlativo de cotización (COT-XXXX).
 */
function generarSiguienteCorrelativo() {
    var contador = parseInt(localStorage.getItem(CLAVES_STORAGE.CONTADOR) || '3');
    contador++;
    localStorage.setItem(CLAVES_STORAGE.CONTADOR, String(contador));
    var numeroTexto = String(contador);
    while (numeroTexto.length < 4) {
        numeroTexto = '0' + numeroTexto;
    }
    return 'COT-' + numeroTexto;
}

/**
 * Restaura todos los datos al estado de fábrica de la demostración.
 */
function restablecerDatosFabrica() {
    localStorage.removeItem(CLAVES_STORAGE.USUARIOS);
    localStorage.removeItem(CLAVES_STORAGE.MATERIALES);
    localStorage.removeItem(CLAVES_STORAGE.COTIZACIONES);
    localStorage.removeItem(CLAVES_STORAGE.BITACORA);
    localStorage.removeItem(CLAVES_STORAGE.CONTADOR);
    localStorage.removeItem(CLAVES_STORAGE.TASA);
    localStorage.removeItem(CLAVES_STORAGE.SESION);
    localStorage.removeItem(CLAVES_STORAGE.BORRADOR_ASISTENTE);
    localStorage.removeItem(CLAVES_STORAGE.MONEDA);
}

/**
 * Obtiene el borrador en progreso del asistente de cotización para un usuario específico.
 */
function obtenerBorradorAsistente(usuarioId) {
    var todos = leerStorage(CLAVES_STORAGE.BORRADOR_ASISTENTE, {});
    if (!usuarioId) return null;
    return todos[usuarioId] || null;
}

/**
 * Guarda el borrador en progreso del asistente de cotización por usuario en localStorage.
 */
function guardarBorradorAsistente(usuarioId, borrador) {
    if (!usuarioId) return;
    var todos = leerStorage(CLAVES_STORAGE.BORRADOR_ASISTENTE, {});
    todos[usuarioId] = borrador;
    escribirStorage(CLAVES_STORAGE.BORRADOR_ASISTENTE, todos);
}

/**
 * Elimina el borrador guardado del asistente para un usuario (o todos si no se pasa id).
 */
function limpiarBorradorAsistente(usuarioId) {
    var todos = leerStorage(CLAVES_STORAGE.BORRADOR_ASISTENTE, {});
    if (usuarioId) { delete todos[usuarioId]; } else { todos = {}; }
    escribirStorage(CLAVES_STORAGE.BORRADOR_ASISTENTE, todos);
}

/**
 * Obtiene la moneda activa de visualización ('USD' o 'Bs').
 */
function obtenerMonedaActiva() {
    return localStorage.getItem(CLAVES_STORAGE.MONEDA) || 'USD';
}

/**
 * Guarda la moneda activa de visualización.
 */
function guardarMonedaActiva(moneda) {
    localStorage.setItem(CLAVES_STORAGE.MONEDA, moneda);
}

/**
 * Carga un juego completo de datos de demostración para exposiciones en clase.
 */
function cargarDatosDemostracionCompletos() {
    escribirStorage(CLAVES_STORAGE.USUARIOS, USUARIOS_INICIALES);
    escribirStorage(CLAVES_STORAGE.MATERIALES, MATERIALES_INICIALES);
    escribirStorage(CLAVES_STORAGE.COTIZACIONES, COTIZACIONES_INICIALES);
    escribirStorage(CLAVES_STORAGE.BITACORA, BITACORA_INICIAL);
    localStorage.setItem(CLAVES_STORAGE.CONTADOR, '3');
    localStorage.setItem(CLAVES_STORAGE.TASA, String(TASA_BCV_INICIAL));
    localStorage.removeItem(CLAVES_STORAGE.BORRADOR_ASISTENTE);
}

/**
 * Vacía completamente las cotizaciones y bitácora para empezar de cero una demostración limpia.
 */
function vaciarDatosSistema() {
    escribirStorage(CLAVES_STORAGE.COTIZACIONES, []);
    escribirStorage(CLAVES_STORAGE.BITACORA, [
        { fecha: obtenerFechaActual(), usuario: 'Sistema', accion: 'SISTEMA_REINICIADO', detalle: 'Reinicio total de datos para nueva demostración.' }
    ]);
    localStorage.removeItem(CLAVES_STORAGE.BORRADOR_ASISTENTE);
    localStorage.setItem(CLAVES_STORAGE.CONTADOR, '0');

    // Restablecer saldo comprometido y gastado de los usuarios
    var usuarios = obtenerUsuarios();
    for (var i = 0; i < usuarios.length; i++) {
        usuarios[i].gastado = 0;
        usuarios[i].comprometido = 0;
    }
    guardarUsuarios(usuarios);
}

